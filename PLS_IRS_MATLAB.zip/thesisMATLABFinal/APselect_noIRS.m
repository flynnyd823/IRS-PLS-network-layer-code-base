function [selectedAP] = APselect_noIRS(d_k_u,d_k_exy,lambda,sigma,N0,W,ptmax,pjmax,Gk,GSTA)

%Determine the access point connections based on signal to noise advantage
%over average eavesdropper area (including the mutual interference on same
%channel).
%
%Inputs: 
%AP to user distances (numAP x 1) [m], 
%eavesdropper to AP distances (numAP x eX x eY) [m],
%carrier wavelength [m], 
%noise floor [watt], 
%Channel bandwidth [Hz], 
%transmit power [watt], 
%max jamming power [watt], 
%gain of transmitter [lin.], 
%gain of receivers [lin.].
% 
%Outputs:
%Return recommended AP connection index.

numAP=size(d_k_u,1);

X=size(d_k_exy,2);
Y=size(d_k_exy,3);

%find all channel coefficients between user to AP and eaves to AP

if numAP>1
    phi_k_u=(2*pi/lambda)*d_k_u;
    phi_k_exy=(2*pi/lambda).*d_k_exy;
    
    a_k_u = sqrt(Gk*GSTA)*lambda.*(exp(-1i.*(phi_k_u)))./d_k_u; 
    a_k_exy = sqrt(Gk*GSTA)*lambda.*(exp(-1i.*(phi_k_exy)))./d_k_exy;
    
    %all AP
    A_k_u=abs(a_k_u).^2;
    A_k_exy=abs(a_k_exy).^2;
    
    %jamming effect
    A_j_u=ones(numAP,1);
    A_j_exy=ones(numAP,X,Y);
    
    for kconnected = 1:numAP
        for kinterference=1:numAP
            if kinterference~=kconnected
                A_j_u(kconnected)=A_j_u(kconnected)+A_k_u(kinterference);
                A_j_exy(kconnected)=A_j_exy(kconnected)+A_k_exy(kinterference);
            end
        end
    end
    
    %normalized noise term
    Npi=16*(pi^2)*W*N0;
    
    %calculate SINR
    SINRu = repmat(ptmax.*A_k_u./(Npi+pjmax.*A_j_u),[1,X,Y]);
    SINRexy = ptmax.*A_k_exy./(Npi+pjmax.*A_j_exy);
   
    %calculate the objective function
    obj=squeeze(sum(sum(log2(((ones(1,X,Y)+SINRu)./((ones(1,X,Y)+SINRexy).^(sigma)))),2),3)); %k   
    
    [~,I]=max(obj);
    %take the index (best AP)
    selectedAP=I;
    
else
    selectedAP=1;
end


end


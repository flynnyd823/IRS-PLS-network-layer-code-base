%use this code to visualize what is occuring in a given environment. This code generates IRS beamforming
%colour maps, IRS phase shift maps, power levels from the AP and SINR for
%any given location in the environment

%simulation constraints:
%Na>1
%Nb>1
%number of users = 1

close all;

%% network operating parameters

%Carrier frequency [Hz]
f=2.4*10^9;
%speed of light [constant]
c=3*10^8;
%wavelength [m]
lambda = c/f;

%transmit power [watts]
ptmax = 1;

%maximum jammer power [watts]
pjmax = 1;

%transmit gain and receiver gain [Linear.]
Gk=1;
GSTA=1;

%noise floor [Watt]
N0 = 10^-12;

%bandwidth [Hz]
W = 20*10^6;

%security bias
sigma=1;

%% IRS parameters

%IRS dimensions [element]
Na=20;
Nb=20;

%element size [m]
Le=lambda/2;

%far field (rayleigh distance) where simple channel gain model appLeed [m]
farfieldrayleight=2*(Le*max(Na,Nb))^2/lambda;
farfieldrelax = 3*sqrt(Na*Nb*Le^2);

%% environment set up

%load the example scenario
exampleScenario;

%{
%this code for a random environment
    Sx=80;
    Sy=80;
    numIRS=2;
    numAP=2;
    percentEve=25;

    %proximity conditions
    minDistanceAP = 10; %metres
    minDistanceIRS=10; %metres
    minDistanceAPB=10; %metres
    minDistanceUB=farfieldrelax; %metres

    %[eveArea, STAxy, APxy, IRSxy,orientationIRS] = generate_random_scen(Sx,Sy,percentEve,numAP,numIRS,minDistanceAPB,minDistanceUB,minDistanceAP,minDistanceIRS);
%}

%% resolution

%RESOLUTION of images
photoRes=1; %data points calculated / metre. increase for higher resolution
Nx = Sx*photoRes;
Ny = round(Nx*Sy/Sx);
dx = Sx/Nx;
xa = (0:Nx)*dx;
dy = Sy/Ny;
ya = (0:Ny)*dy;
eveRes=1; %for EASOR calculation, increase for higher resolution

%calculate phase discrepancy to occur over surface of IRS (validity of path
%loss model) [degrees]
phaseDiscrepancy=(pi/4)*(Le*max(Na,Nb))^2/(lambda*20)*180/pi;

%% algorithms
[d_m_u, d_m_k, d_m_exy, d_mn_u ,d_mn_k ,d_mn_exy ,d_k_u ,d_k_exy, angleIncidence]=quickCompute_d(APxy,STAxy,eveArea,IRSxy,orientationIRS,Na,Nb,Le);
    
transmitAP=APselect_noIRS(d_k_u,d_k_exy,lambda,sigma,N0,W,ptmax,pjmax,Gk,GSTA);
fprintf('Transmit AP %d', transmitAP);
fprintf('\n');

[phiAligned, I] = optimise_IRS_Align(d_m_u, d_m_k, d_m_exy, d_mn_u ,d_mn_k ,d_mn_exy ,d_k_u ,d_k_exy, angleIncidence,lambda,Na,Nb,Le,W,N0,pjmax,ptmax,transmitAP,sigma,Gk,GSTA);

fprintf("With IRS associations \n");
disp(I);

[p_k]=FJpower(d_m_u, d_m_k, d_m_exy, d_mn_u ,d_mn_k ,d_mn_exy ,d_k_u ,d_k_exy,angleIncidence,phiAligned,ptmax,transmitAP, Le,lambda,W,sigma,N0,pjmax,Gk,GSTA);

fprintf('transmit Powers \n');
disp(p_k);

APs=APxy(transmitAP,:);

%% channels and mapping

hLOS_single=simulate_LOS_single(APs,STAxy,lambda,ptmax,Gk,GSTA);
hIRS = simulate_IRS_single(phiAligned,APs,STAxy,IRSxy,orientationIRS,lambda,Na,Nb,Le,ptmax,Gk,GSTA);

%calculate combined channel responses
hLOSIRS_s=hLOS_single+hIRS;
pLOSIRS_s=abs(hLOSIRS_s).^2;

%generate map
[hLOS] = simulate_LOS_map(dx,dy,Nx,Ny,APs,lambda,ptmax,Gk,GSTA);
[hIRS,hIRSIndv,pIRS,pIRSIndv] = simulate_IRS_map(phiAligned,dx,dy,Nx,Ny,APs,IRSxy,orientationIRS,lambda,Na,Nb,Le,ptmax,Gk,GSTA);

hLOSIRS=hLOS+hIRS;
pLOSIRS=abs(hLOSIRS).^2;

%% compute noise and interference channels

pLOSIRSj=zeros(Nx,Ny);

for k=1:numAP
    if k~=transmitAP
        pj=p_k(k);
        [hLOSj] = simulate_LOS_map(dx,dy,Nx,Ny,APxy(k,:),lambda,pj,Gk,GSTA);
        [hIRSj,hIRSIndvj,~,pIRSIndvj] = simulate_IRS_map(phiAligned,dx,dy,Nx,Ny,APxy(k,:),IRSxy,orientationIRS,lambda,Na,Nb,Le,pj,Gk,GSTA);
        hLOSIRSj=hLOSj+hIRSj;
        pLOSIRSj=pLOSIRSj+pj.*abs(hLOSIRSj).^2;
    end
end

SINRmap=(pLOSIRS./(W.*repmat(N0,Nx,Ny)+pLOSIRSj));

Cap_u= calculate_user_cap(APxy, STAxy,IRSxy,orientationIRS,transmitAP, lambda,W, N0,ptmax,p_k,Na,Nb,Le,phiAligned,Gk,GSTA);
eveCap=calculate_eaves_cap(APxy, IRSxy,orientationIRS,transmitAP, eveArea, eveRes, lambda,W, N0,ptmax,p_k,Na,Nb,Le,phiAligned,Gk,GSTA);

sCAP=repmat(Cap_u,size(eveCap,1),size(eveCap,2))-eveCap;

%calculate the EASOR as percentage
EASOR = 100*sum(sCAP<(1/2*Cap_u),"all")/numel(sCAP);

fprintf('User capacity Mbit/s \n');
disp(Cap_u/1e6);
fprintf('EASOR percentage \n');
disp(EASOR)

%% graph and plots

colour_maps;
%1 = SINR
%2 = individual IRS pathloss (to transmitter)
%3 = Transmit pathloss
%4 = Jammer pathloss (all)
%5 = scenario scatter
%6 = IRS phase shifts
%7 = individual IRS pathloss (from all jammers)


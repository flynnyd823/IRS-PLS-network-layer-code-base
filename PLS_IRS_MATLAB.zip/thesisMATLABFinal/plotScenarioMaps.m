close all;
clear all;

%% set up network
%Carrier frequency [Hz]
f=2.4*10^9;
%speed of light [constant]
c=3*10^8;
%wavelength [m]
lambda = c/f;

%transmit power [watts]
ptmax = 1;
%maximum jammer power [watts]
pjmax = 1;

%receiver gain and transmit gain [lin.]
Gk=1;
GSTA=1;

%noise floor [lin.]
N0 = 10^-12;

%bandwidth [Hz]
W = 20*10^6;

%IRS elements
Na=16;
Nb=16;
Li=lambda/2;

%secrecy bias
sigma=1;

%load the scenario you want
load('Scenario1.mat');

%% enable the parts of the algorithm you want

%CHANGE THESE
IRSon=true;
FJon=true;

%% RESOLUTION of images
photoRes=1; %increase for higher res
Nx = Sx*photoRes;
Ny = round(Nx*Sy/Sx);
dx = Sx/Nx;
xa = (0:Nx-1)*dx;
dy = Sy/Ny;
ya = (0:Ny-1)*dy;

eveRes=1; %increase for higher res of calculated EASOR


%% calculate the distances

%DO NOT CHANGE
if IRSon==false
    numIRS=0;
    IRSxy=[];
    orientationIRS=[];
    phiAligned=[];
else
    numIRS=size(IRSxy,1);
end

if FJon==false
    pjmax=0;
end

minDistanceUB=3; %metres

x1=eveArea(1,1);
x2=eveArea(1,2);
y1=eveArea(2,1);
y2=eveArea(2,2);

[x, y] = meshgrid(0:dx:Sx, 0:dy:Sy);
pointsFree = [x(:), y(:)];

[x_eav, y_eav] = meshgrid(x1:dx:x2, y1:dy:y2);
pointsEav = [x_eav(:), y_eav(:)];

%generate user position outside eavesdropper area
[xU, yU] = meshgrid(minDistanceUB:dx:Sx-minDistanceUB, minDistanceUB:dy:Sy-minDistanceUB);
pointsUser = [xU(:), yU(:)];

inEav = ismember(pointsUser, pointsEav, 'rows');
points = pointsUser(~inEav, :);

for k=1:numAP
    distancesAPUser = sqrt((points(:,1) - APxy(k,1)).^2 + ...
             (points(:,2) - APxy(k,2)).^2);
    points(distancesAPUser <= 1, :) = [];  
end

if numIRS>1
    IRSx=IRSxy(:,1);
    IRSy=IRSxy(:,2);
end


%% discretise and solve distances in environment
X=x2-x1;
Y=y2-y1;

angleIncidence=ones(numIRS,numAP);
d_m_k=ones(numIRS,numAP);
d_m_u=ones(numIRS,1);
d_m_exy=ones(numIRS,X,Y);
d_mn_u=ones(Nb,Na,numIRS);
d_mn_k=ones(Nb,Na,numIRS,numAP);
d_mn_exy=ones(Nb,Na,numIRS,X,Y);
d_k_u=ones(numAP,1);
d_k_exy=ones(numAP,X,Y);

for  k=1:numAP
    for x=1:x2-x1
        for y=1:y2-y1
            d_k_exy(k,x,y)=sqrt((APxy(k,1)-(x1+x))^2+(APxy(k,2)-(y1+y))^2);
        end
    end
end

for m=1:numIRS
    for x=1:x2-x1
        for y=1:y2-y1
            d_m_exy(m,x,y) = sqrt((IRSx(m)-(x1+x)).^2+(IRSy(m)-(y1+y)).^2);
        end
    end

    if orientationIRS(m)=="horizontal" %ie ycoord is fixed
        for k=1:numAP
            d_m_k(m,k)=sqrt(((IRSx(m)-APxy(k,1))).^2+(IRSy(m)-APxy(k,2)).^2);
            angleIncidence(m,k)=atand(abs(APxy(k,1)-IRSx(m))/abs(APxy(k,2)-IRSy(m)));
        end

        for column = 1:Na
            for row = 1:Nb
                
                %AP
                for k=1:numAP
                    d_mn_k(row,column,m,k)=sqrt((IRSx(m)-(Na/2-column)*Li-APxy(k,1)).^2+(IRSy(m)-APxy(k,2)).^2+(-(Nb/2-row)*Li).^2);
                end

                %eavesdropper
                for x=1:x2-x1
                    for y=1:y2-y1
                        d_mn_exy(row,column,m,x,y) = sqrt((IRSx(m)-(Na/2-column)*Li-(x1+x)).^2+(IRSy(m)-(y1+y)).^2+(-(Nb/2-row)*Li).^2);
                    end
                end
            end
        end
   
    elseif orientationIRS(m)=="vertical" %ie x coord is fixed

        for k=1:numAP
            d_m_k(m,k)=sqrt(((IRSx(m)-APxy(k,1))).^2+(IRSy(m)-APxy(k,2)).^2);
            angleIncidence(m,k)=atand(abs(APxy(k,2)-IRSy(m))/abs(APxy(k,1)-IRSx(m)));
        end
        
        for column = 1:Na
            for row = 1:Nb

                %AP
                for k=1:numAP
                    d_mn_k(row,column,m,k)=sqrt((IRSx(m)-APxy(k,1)).^2+(IRSy(m)-(Na/2-column)*Li-APxy(k,2)).^2+(-(Nb/2-row)*Li).^2);
                end

                %eavesdropper
                for x=1:x2-x1
                    for y=1:y2-y1
                        d_mn_exy(row,column,m,x,y) = sqrt((IRSx(m)-(x1+x)).^2+(IRSy(m)-(Na/2-column)*Li-(y1+y)).^2+(-(Nb/2-row)*Li).^2);
                    end
                end
            end    
        end
    else
        error("Incorrect entered IRS orientation")
    end
end

%correct minimum values (zero exceptions)
d_m_k(d_m_k == 0) = 0.001;
d_m_exy(d_m_exy == 0) = 0.001;
d_mn_k(d_mn_k == 0) = 0.001;
d_mn_exy(d_mn_exy == 0) = 0.001;

EASORtotal=0;
CAPtotal=0;

connectionMap=zeros(Nx,Ny);
IRSconnectMap=zeros(Nx,Ny,numIRS);
FJpowerMap=zeros(Nx,Ny,numAP);
user_capMap=zeros(Nx,Ny);
EASORMap=ones(Nx,Ny)*100;

EASORlist=ones(size(points,1),1);
CAPlist=ones(size(points,1),1);

for p=1:size(points,1)
    %disp(p);
    xP=points(p,1)+1;
    yP=points(p,2)+1;

    for  k=1:numAP
        d_k_u(k)=sqrt((APxy(k,1)-points(p,1)).^2+(APxy(k,2)-points(p,2)).^2);
    end
    for m=1:numIRS
        d_m_u(m)=sqrt((IRSx(m)-points(p,1)).^2+(IRSy(m)-points(p,2)).^2);
        
        if orientationIRS(m)=="horizontal" %ie ycoord is fixed
    
            for column = 1:Na
                for row = 1:Nb
                    d_mn_u(row,column,m)=sqrt((IRSx(m)-(Na/2-column)*Li-points(p,1)).^2+(IRSy(m)-points(p,2)).^2+(-(Nb/2-row)*Li).^2);
                end
            end
    
        elseif orientationIRS(m)=="vertical" %ie x coord is fixed
            
            for column = 1:Na
                for row = 1:Nb
                    %user
                    d_mn_u(row,column,m)=sqrt((IRSx(m)-points(p,1)).^2+(IRSy(m)-(Na/2-column)*Li-points(p,2)).^2+(-(Nb/2-row)*Li).^2);
                end
            end
        end
    end

    d_m_u(d_m_u == 0) = 0.001;
    d_mn_u(d_mn_u == 0) = 0.001;
    d_k_u(d_k_u == 0) = 0.001;

    [transmitAP] = APselect_noIRS(d_k_u,d_k_exy,lambda,sigma,N0,W,ptmax,pjmax,Gk,GSTA);
    connectionMap(xP/dx,yP/dy)=transmitAP;
    
    if IRSon==true
        [phiAligned, I]=optimise_IRS_Align(d_m_u, d_m_k, d_m_exy, d_mn_u ,d_mn_k ,d_mn_exy ,d_k_u ,d_k_exy, angleIncidence,lambda,Na,Nb,Li,W,N0,pjmax,ptmax,transmitAP,sigma,Gk,GSTA);
    
        for i=1:numIRS
            IRSconnectMap(xP/dx,yP/dy,i)=I(i);
        end
    end
    
    if FJon==true
        [p_k] = FJpower(d_m_u, d_m_k, d_m_exy, d_mn_u ,d_mn_k ,d_mn_exy ,d_k_u ,d_k_exy, angleIncidence,phiAligned,ptmax,transmitAP, Li,lambda,W,sigma,N0,pjmax,Gk,GSTA);

        for k=1:numAP
            if k~=transmitAP
                FJpowerMap(xP/dx,yP/dy,k)=p_k(k);
            end
        end

    else
        p_k=zeros(numAP,1);
        p_k(transmitAP)=ptmax;
    end
    user_capMap(xP/dx,yP/dy) = calculate_user_cap(APxy, [points(p,1),points(p,2)],IRSxy,orientationIRS,transmitAP, lambda,W, N0,ptmax,p_k,Na,Nb,Li,phiAligned,Gk,GSTA);
  
    eveCap=calculate_eaves_cap(APxy, IRSxy,orientationIRS,transmitAP, eveArea, eveRes, lambda,W, N0,ptmax,p_k,Na,Nb,Li,phiAligned,Gk,GSTA);
    
    sCAP=repmat(user_capMap(xP/dx,yP/dy),size(eveCap,1),size(eveCap,2))-eveCap;
   
    %calculate the EASOR as percentage
    EASORMap(xP/dx,yP/dy) = 100*sum(sCAP<(1/2*user_capMap(xP/dx,yP/dy)),"all")/numel(sCAP);


    EASORlist(p)=EASORMap(xP/dx,yP/dy);
    CAPlist(p)=user_capMap(xP/dx,yP/dy);

end

CAPlist=CAPlist(isfinite(CAPlist));

EASOR_average=mean(EASORlist);
CAP_average=mean(CAPlist);

minEASOR=min(EASORlist);
maxEASOR=max(EASORlist);

minCAP=min(CAPlist);
maxCAP=max(CAPlist);


%% plotting 
textFontMinor=12;

xlabpos=ones(numAP+numIRS,1);
ylabpos=ones(numAP+numIRS,1);
labels=cell(numAP+numIRS,1);

for k=1:numAP
    xlabpos(k)=APxy(k,1)-6.25*Sx/80;
    ylabpos(k)=APxy(k,2)-6.25*Sx/80;
    labels{k}=sprintf('AP_%d', k);
end

for m=1:numIRS
    if(IRSxy(m,2)==0) %on bottom of scenario
        xlabpos(numAP+m)=IRSxy(m,1)-1*Sx/80;
        ylabpos(numAP+m)=IRSxy(m,2)+3.25*Sx/80;
    elseif(IRSxy(m,2)==Sy)
        xlabpos(numAP+m)=IRSxy(m,1)-2*Sx/80;
        ylabpos(numAP+m)=IRSxy(m,2)-10*Sx/80;
    elseif(IRSxy(m,1)==Sx) %on left of scenario
        xlabpos(numAP+m)=IRSxy(m,1)-10.25*Sx/80;
        ylabpos(numAP+m)=IRSxy(m,2)+1*Sx/80;
    else
        xlabpos(numAP+m)=IRSxy(m,1)+3.25*Sx/80;
        ylabpos(numAP+m)=IRSxy(m,2) -1*Sx/80;
    end

    labels{numAP+m}=sprintf('IRS_%d',m);
end

APx=APxy(:,1);
APy=APxy(:,2);

%% AP connections

figure(1)
contourf(xa,ya,connectionMap.','LineColor', 'none');

% Add the colorbar
a = colorbar;
a.Ticks = [0 1 2];
a.TickLabels = {'0','1', '2'};
colormap(gray);
axis equal tight;
set(gca,'FontSize',12,'LineWidth',2);
set(gca,'ColorScale','lin');
set(gca,'YDir','normal')
a.Label.String = 'AP Connection';
xlabel('x position [m]')
ylabel('y position [m]')
hold on;
scatter(APxy(:,1),APxy(:,2),105,'k','^',"filled");
axis square
t = text(xlabpos(1:2),ylabpos(1:2),labels(1:2),'HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
te = text((eveArea(1,2)+eveArea(1,1))/2-(Sx/10),(eveArea(2,2)+eveArea(2,1))/2,'A_e','HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
for ti=1:2
    t(ti).FontSize = textFontMinor;
    t(ti).Color = 'Black';
end
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,1) eveArea(2,1)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,2) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,1)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,2) eveArea(1,2)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
te.FontSize=20;
te.Color = 'White';
box on;
xlim([0 Sx]);
ylim([0 Sy]);


%% IRS Associations to AP

if IRSon==true
    figure(2)
    
    colormap(gray); % Apply the colormap
    
    for i = 1:numIRS
        % Create subplots according to numIRS
        if numIRS == 1
            contourf(xa,ya, IRSconnectMap(:,:,i).');
        elseif numIRS == 2
            subplot(1, 2, i);
        elseif numIRS == 3
            subplot(2, 2, i);
        elseif numIRS == 4
            subplot(2, 2, i);
        elseif numIRS == 5
            subplot(2, 3, i);
        elseif numIRS == 6
            subplot(2, 3, i);
        else
            error("Too many IRS to plot IRS assoc.");
        end
        
        hold on;
        
        % Plot the phase data
        contourf(xa,ya, IRSconnectMap(:,:,i).','LineColor', 'none');
        hold on;
        % Scatter plot IRS position after the imagesc
        plot(IRSxy(i,1), IRSxy(i,2), '+', 'LineWidth', 8, 'Color', [1 0.4 0.6], 'MarkerSize', 8, 'MarkerFaceColor', 'k');
       
    
        % Set consistent color axis for all subplots
        axis equal tight;
        
        title(sprintf('IRS_%d', i));
    
        % Adjust axes properties
        set(gca, 'FontSize', 6, 'LineWidth', 2);
        set(gca, 'ColorScale', 'linear');
        set(gca, 'YDir', 'normal');
        xlim([0 Sx]);  % Set x-axis limits
        ylim([0 Sy]);  % Set y-axis limits
        
        % Labels and text
        xlabel('x position [m]');
        ylabel('y position [m]');
        te = text((eveArea(1,2)+eveArea(1,1))/2 - (Sx/10), (eveArea(2,2)+eveArea(2,1))/2, 'A_e', ...
            'HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
        te.FontSize = 20;
        te.Color = 'White';
        hold off;
    end
    
     a= colorbar('Position', [0.9 0.11 0.015 0.815]);
    
    a.Label.String = 'AP Association';
            a.Ticks = [0 1 2];
        a.TickLabels = {'0','1', '2'}; % Optional: customize tick labels
end

%% FJ power

if FJon==true&&numAP>1 %only plot if necessary
    figure(3)
    i=0;
    for k = 1:numAP
            % Create subplots according to numIRS
            if numAP == 2
                subplot(1, 2, k);
            elseif numAP == 3
                subplot(2, 2, k);
            elseif numAP == 4
                subplot(2, 2, k);
            elseif numAP == 5
                subplot(2, 3, k);
            elseif numAP == 6
                subplot(2, 3, k);
            elseif numAP == 7
                subplot(2, 4, k);
            else
                error("Too many AP to plot FJ powers");
            end
            
            hold on;
            
            % Plot the phase data
            contourf(xa,ya, FJpowerMap(:,:,k).','LineColor', 'none');
            hold on;
            % Scatter plot IRS position after the imagesc
           scatter(APxy(k,1),APxy(k,2),105,'w','^',"filled");
           t = text(xlabpos,ylabpos,labels,'HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
           
            for ti=1:size(xlabpos)
                t(ti).FontSize = textFontMinor;
                t(ti).Color = 'white';
            end
                
            % Set consistent color axis for all subplots
            axis equal tight;
            
            title(sprintf('AP_%d', k));
        
            % Adjust axes properties
            set(gca, 'FontSize', 6, 'LineWidth', 2);
            set(gca, 'ColorScale', 'linear');
            set(gca, 'YDir', 'normal');
            xlim([0 Sx]);  % Set x-axis limits
            ylim([0 Sy]);  % Set y-axis limits
            
            % Labels and text
            xlabel('x position [m]');
            ylabel('y position [m]');
            te = text((eveArea(1,2)+eveArea(1,1))/2 - (Sx/10), (eveArea(2,2)+eveArea(2,1))/2, 'A_e', ...
                'HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
            te.FontSize = 20;
            te.Color = 'White';
            hold off;

    end
        
         a= colorbar('Position', [0.9 0.11 0.015 0.815]);
        
        a.Label.String = 'FJ Power [watts]';
end


%% User throughput map

figure(4)
imagesc(xa,ya, (user_capMap./1e6).');
a=colorbar();
colormap(turbo);
axis equal tight;
set(gca,'FontSize',12,'LineWidth',2);
set(gca,'ColorScale','log');
set(gca,'YDir','normal')
a.Label.String = 'User throughput [MBit/s]';
xlabel('x position [m]')
ylabel('y position [m]')
hold on;
if numIRS>0
    plot((IRSx),(IRSy), '+', 'LineWidth', 8, 'Color', 'w', 'MarkerSize', 8,'MarkerFaceColor','k');
end

t = text(xlabpos,ylabpos,labels,'HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
te = text((eveArea(1,2)+eveArea(1,1))/2-(Sx/10),(eveArea(2,2)+eveArea(2,1))/2,'A_e','HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
for ti=1:size(xlabpos)
    t(ti).FontSize = textFontMinor;
    t(ti).Color = 'white';
end

te.FontSize=20;
te.Color = 'white';
scatter(APxy(:,1),APxy(:,2),105,'w','^',"filled");
%scatter(STAxy(1),STAxy(2),90,'b',"o","filled");
%mark unprotected zone
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,1) eveArea(2,1)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,2) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,1)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,2) eveArea(1,2)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
axis square
box on;
xlim([0 Sx]);
ylim([0 Sy]);
%legend(["Access points" "User STAxy"],'fontsize', 10)
%title("SINR");
hold off;

%% EASOR Map

figure(5)
contourf(xa,ya, EASORMap.');
a=colorbar();
clim([0,maxEASOR]);
colormap(turbo);
axis equal tight;
set(gca,'FontSize',12,'LineWidth',2);
set(gca,'ColorScale','lin');
set(gca,'YDir','normal')
%colorbar('Direction','reverse')
a.Label.String = 'EASOR [%]';
xlabel('x position [m]')
ylabel('y position [m]')
hold on;

if numIRS>0
    plot((IRSx),(IRSy), '+', 'LineWidth', 8, 'Color', 'w', 'MarkerSize', 8,'MarkerFaceColor','k');
end

t = text(xlabpos,ylabpos,labels,'HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
te = text((eveArea(1,2)+eveArea(1,1))/2-(Sx/10),(eveArea(2,2)+eveArea(2,1))/2,'A_e','HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
for ti=1:size(xlabpos)
    t(ti).FontSize = textFontMinor;
    t(ti).Color = 'white';
end

te.FontSize=20;
te.Color = 'white';
scatter(APxy(:,1),APxy(:,2),105,'w','^',"filled");
%scatter(STAxy(1),STAxy(2),90,'b',"o","filled");
%mark unprotected zone
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,1) eveArea(2,1)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,2) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,1)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,2) eveArea(1,2)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
axis square
box on;
xlim([0 Sx]);
ylim([0 Sy]);
%legend(["Access points" "User STAxy"],'fontsize', 10)
%title("EASOR");
hold off;


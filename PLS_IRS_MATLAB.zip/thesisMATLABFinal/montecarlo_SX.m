%perform monte carlo simulation of environment with changing IRS and
%environment size

close all;

%number of independent samples to be run
samples=2000;

%% network parameters
%security bias
sigma=1;

f=2.4*10^9;
c=3*10^8;
lambda = c/f;

ptmax = 1;
pjmax = 1;
N0 = 10^-12;

Gk=1;
GSTA=1;

W = 20*10^6;

Na=12; %number of IRS elements on the width
Nb=Na; %default to square configuration
Le=lambda/2; %element size [m]

percentEve=10;
eveRes=1; %resolution for EASOR calculation

%proximity conditions
minDistanceAP = 10; %metres
minDistanceIRS=10; %metres
minDistanceAPB=10; %metres

farfieldrelax = 3*sqrt(Na*Nb*Le^2);
minDistanceUB=farfieldrelax; %metres

Sxmin=40; 
Sxmax=140; 
SxDiscrete=20; %increments at which to increase Sx

numIRSMin=2;
numIRSMax=5;

numAP=2;

SXresults=zeros(numIRSMax-numIRSMin+1,(Sxmax-Sxmin)/SxDiscrete+1,4);

for Sx=Sxmin:SxDiscrete:Sxmax
    Sy=Sx;
    fprintf('Currently on environment x dimension %d', Sx);
    fprintf('\n');
    [EASOR_mean, EASOR_std, Cap_u_mean, Cap_u_std]  = change_numIRS(numIRSMin,numIRSMax,samples,percentEve,eveRes,numAP, minDistanceAPB,minDistanceUB,minDistanceAP,minDistanceIRS,lambda,Sx,Sy,Na,Nb,Le,W,N0,pjmax,ptmax,sigma,Gk,GSTA);
    SXresults(:,1+(Sx-Sxmin)/SxDiscrete,1)=EASOR_mean.';
    SXresults(:,1+(Sx-Sxmin)/SxDiscrete,2)=EASOR_std.';
    SXresults(:,1+(Sx-Sxmin)/SxDiscrete,3)=Cap_u_mean.';
    SXresults(:,1+(Sx-Sxmin)/SxDiscrete,4)=Cap_u_std.';
end



%% plot

markers = {'o', 's', '^', 'd', 'x', '+'}; 
close all;

figure(1)
for m=1:numIRSMax-numIRSMin+1
    plot(Sxmin:SxDiscrete:Sxmax, SXresults(m,:,1), ['-' markers{m}]);
    hold on;
end

xlabel('S_x [m]');
ylabel('$\overline{\textrm{EASOR}}$ [\%]', 'Interpreter', 'latex');
grid on;
grid minor;
lgd = legend('M=2','M=3','M=4','M=5');
title(lgd, 'Number of IRS');
lgd.Location = 'southeast';

figure(2)

for m=1:numIRSMax-numIRSMin+1
    plot(Sxmin:SxDiscrete:Sxmax, SXresults(m,:,3), ['-' markers{m}]);
    hold on;
end

xlabel('S_x [m]');
ylabel('$\overline{R_u}$ [Mbit/s]', 'Interpreter', 'latex');

grid on;
grid minor;
lgd = legend('M=2','M=3','M=4','M=5');
title(lgd, 'Number of IRS');
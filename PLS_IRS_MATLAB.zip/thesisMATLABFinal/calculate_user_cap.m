function [Cap_u]= calculate_user_cap(APxy, STAxy,IRSxy,orientationIRS,transmitAP, lambda,W, N0,ptmax,p_k,Na,Nb,Le,phiAligned,Gk,GSTA)

%Calculate user throughput (shannon capacity)
%
%Inputs:
%AP location (1 x 2) [m], 
%User location (1 x 2) [m], 
%IRS location (numIRS x 2) [m],
%IRS orientation (numIRS x 2) [m],
%transmitting AP,
%carrier wavelength [m],
%channel bandwidth [Hz],
%Noise floor [watt],
%transmit power [watts], 
%power level of all AP (numAP x 1) [watt],
%number of elements along IRS width,
%number of elements along IRS height,
%size of element,
%phase shifts of IRS (Nb x Na x numIRS) [rads.],
%gain of transmitter [lin.], 
%gain of receivers [lin.].
%
%Outputs:
%Throughput of user [bit/s]

numAP=size(APxy,1);
hLOS=simulate_LOS_single(APxy(transmitAP,:),STAxy,lambda,ptmax,Gk,GSTA);
hIRS = simulate_IRS_single(phiAligned,APxy(transmitAP,:),STAxy,IRSxy,orientationIRS,lambda,Na,Nb,Le,ptmax,Gk,GSTA);

hLOSIRS_u=hLOS+hIRS;
pLOSIRS_u=ptmax*abs(hLOSIRS_u).^2;

pLOSIRSj_u=0;

for k=1:numAP
    if k~=transmitAP
        pj=p_k(k);
        hLOSj = simulate_LOS_single(APxy(k,:),STAxy,lambda,pj,Gk,GSTA);
        hIRSj = simulate_IRS_single(phiAligned,APxy(k,:),STAxy,IRSxy,orientationIRS,lambda,Na,Nb,Le,pj,Gk,GSTA);
        hLOSIRSj_u=hLOSj+hIRSj;
        pLOSIRSj_u=pLOSIRSj_u+pj.*abs(hLOSIRSj_u).^2;
    end
end

Cap_u=W*log2(1+pLOSIRS_u/(W*N0+pLOSIRSj_u));
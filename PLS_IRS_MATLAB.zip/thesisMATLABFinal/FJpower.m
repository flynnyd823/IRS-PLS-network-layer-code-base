function [p_k] = FJpower(d_m_u, d_m_k, d_m_exy, d_mn_u ,d_mn_k ,d_mn_exy ,d_k_u ,d_k_exy, angleIncidence,phiAligned,ptmax,transmitAP, Li,lambda,W,sigma,N0,pjmax,Gk,GSTA)

%Derive the friendly jamming powers for each idle AP analytically.

%Inputs:
%IRS to user (numIRS x 1),
%IRS to AP (numIRS x numAP),
%IRS to eaves (numIRS x eX x eY),
%IRS element to user (Nb x Na x numIRS),
%IRS element to AP (Nb x Na x numIRS x numAP),
%IRS element to eve (Nb x Na x numIRS x eX x eY),
%AP to user (numAP x 1),
%AP to eaves (numAP x eX x eY),
%Incidence angle from AP to IRS (numIRS x numAP),ations (numIRS x 1), 
%phases of the IRS elements (Nb x Na x numIRS) [rads]
%transmit power [watts], 
%transmitting AP,
%Size of element [m], 
%Carrier wavelength [m], 
%Channel Bandwidth [Hz],
%secrecy biasing term
%Noise floor [Watt],
%maximum jamming power [watt],
%Gain of transmitter [lin.], 
%Gain of receivers [lin.].
%
%Outputs: 
%Power for all AP (numAP x 1) [watt]

K=size(d_m_k,2);
M=size(d_m_k,1);

X=size(d_k_exy,2);
Y=size(d_k_exy,3);

p_k=zeros(size(d_m_k,2),1); %all powers must initially be zero

xc=floor(size(d_mn_exy,4)/2);
yc=floor(size(d_mn_exy,5)/2);

if K>1
    phi_k_u=(2*pi/lambda)*d_k_u;
    phi_k_exy=(2*pi/lambda).*d_k_exy;
    
    %generate a terms
    a_k_u = sqrt(Gk*GSTA)*lambda.*(exp(-1i.*(phi_k_u)))./d_k_u; %k
    a_k_exy = sqrt(Gk*GSTA)*lambda.*(exp(-1i.*(phi_k_exy)))./d_k_exy; %k, X,Y

    d_k_e=d_k_exy(:,xc,yc);
    phi_k_e=(2*pi/lambda).*d_k_e;
    a_k_e=lambda.*exp(-1i*phi_k_e);

    %generated according phase differences
    phi_mn_k=(2*pi/lambda).*d_mn_k;
    phi_mn_u=(2*pi/lambda).*d_mn_u;
    phi_mn_exy=(2*pi/lambda).*d_mn_exy;
    
    %generate b terms(LOS)
    %b_k_u= Li.*(cos(angleIncidence(m,k)./(d_m_k(m,k).*d_m_u(m)))).*sum(exp(1i*(phi_mn_k(:,:,m,k)+phi_mn_u(:,:,m)+phiAligned(:,:,m)))); %(k)
    %b_k_exy=Li.*(cos(angleIncidence(m,k)./(d_m_k(m,k).*d_m_exy(m,x,y)))).*sum(exp(1i*(phi_mn_k(:,:,m,k)+phi_mn_exy(:,:,m,x,y)+phiAligned(:,:,m)))); %(k,x,y)
    
    
    if M>0
        if M>1
            tempu=squeeze(sum(sum(exp(-1i*(phi_mn_k+repmat(phi_mn_u,[1,1,1,K])+repmat(phiAligned,[1,1,1,K]))),1),2)); %NL NL M K
            tempe=squeeze(sum(sum(exp(-1i*(permute(repmat(phi_mn_k,[1 1 1 1 X Y]),[1 2 3 5 6 4])+repmat(phi_mn_exy,[1,1,1,1,1,K])+repmat(phiAligned,[1,1,1,X,Y,K]))),1),2)); %NL NL M X Y K
        else
            tempu=squeeze(sum(sum(exp(-1i*(phi_mn_k+repmat(phi_mn_u,[1,1,1,K])+repmat(phiAligned,[1,1,1,K]))),1),2)).'; %NL NL M K
            tempe=permute(squeeze(sum(sum(exp(-1i*(permute(repmat(phi_mn_k,[1 1 1 1 X Y]),[1 2 3 5 6 4])+repmat(phi_mn_exy,[1,1,1,1,1,K])+repmat(phiAligned,[1,1,1,X,Y,K]))),1),2)),[4,1,2,3]); %NL NL M K XY
        end
        
        %sum each IRS contribution
        
        b_k_u = sqrt(Gk*GSTA).*sum(Li^2.*(cos(angleIncidence)./(d_m_k.*repmat(d_m_u,[1,K]))).*tempu,1); %1 k
        b_k_exy = sqrt(Gk*GSTA).*squeeze(sum(Li^2.*(cos(permute(repmat(angleIncidence,[1 1 X Y]),[1 3 4 2]))./(permute(repmat(d_m_k,[1 1 X Y]),[1 3 4 2]).*repmat(d_m_exy,[1,1,1,K]) ) ).*tempe,1)); %x,y,k
        
        b_k_e=b_k_exy(xc,yc,:);
    
        A_k_u=abs(a_k_u+b_k_u.').^2; %k
        A_k_exy=abs(a_k_exy+permute(b_k_exy,[3 1 2])).^2; %k x y
        A_k_e=abs(a_k_e+permute(b_k_e,[3 1 2])).^2;
    else
        A_k_u=abs(a_k_u).^2;
        A_k_exy=abs(a_k_exy).^2;
        A_k_e=abs(a_k_e).^2;
    end
    
    
    
    %normalized noise term
    %N=W*N0;
    N=W*N0*(4*pi)^2;
    Npiu=N;
    Npie=repmat(Npiu,[1,X,Y]);
    
    %create priority index
    Pri_k=ones(K,1);
    
    for k =1:K
        Pri_k(k)=A_k_u(k)+A_k_e(k);
    end
    
    [~,pri]=sort(Pri_k,'ascend');
    
    
    %remove the transmitter index
    pri(pri==transmitAP)=[];
    
    A_t_u=ptmax*A_k_u(transmitAP); 
    A_t_e=ptmax*A_k_e(transmitAP); 
    A_t_exy=ptmax*A_k_exy(transmitAP,:,:);

    
    for si=1:K-1
        s = pri(si); %take the priority
        
        %remove selected AP from B calculation
        A_k_u_s=A_k_u(setdiff(1:K, [s transmitAP]));
        A_k_exy_s=A_k_exy(setdiff(1:K, [s transmitAP]), :, :); 
        A_k_e_s=A_k_e(setdiff(1:K, [s transmitAP]));

        p_k_s=p_k(setdiff(1:K, [s transmitAP]));
       
    
        %other AP
        B_s_u=sum(p_k_s.*A_k_u_s); %powers included 
        B_s_exy=sum(repmat(p_k_s,[1,X,Y]).*A_k_exy_s,1); %powers included %1,x,y
        B_s_e=sum(p_k_s.*A_k_e_s); %powers included 
        %isolate the selected AP
        A_s_u=A_k_u(s);
        A_s_exy=A_k_exy(s,:,:);
        
        A_s_e=A_k_e(s);
        

        a=(A_s_u^2)*A_t_e*A_s_e-(A_s_e^2)*A_t_u*A_s_u;
        b=2*A_s_u*A_s_e*(N*(A_t_e-A_t_u)+(A_t_e*B_s_u-A_t_u*B_s_e));
        c=A_t_u*A_s_u*(N*(-N-A_t_e-2*B_s_e)+B_s_e*(-B_s_e-A_t_e))+A_t_e*A_s_e*(N*(2*B_s_u+N+A_t_u)+B_s_u*(B_s_u+A_t_u));

        r=roots([a b c]);

        if size(r,1)==1
            rConstraint1 = max(min(real(r(1)),pjmax),0);
            rsols = unique([0 pjmax rConstraint1],'stable');
        else
            rConstraint1 = max(min(real(r(1)),pjmax),0);
            rConstraint2 = max(min(real(r(2)),pjmax),0);
            rsols = unique([0 pjmax rConstraint1 rConstraint2],'stable');
        end
        
        obj = zeros(size(rsols,2),1);
        for p = 1:size(rsols,2)
            SINRu=repmat((A_t_u)./(Npiu+B_s_u+rsols(p).*A_s_u),[1,X,Y]); %1 x y
            SINRexy=(A_t_exy)./(Npie+B_s_exy+rsols(p).*A_s_exy); %1 x y
            obj(p)=W*squeeze(sum(sum(log2(((ones(1,X,Y)+SINRu)./((ones(1,X,Y)+SINRexy).^(sigma)))),2),3))./(X*Y); %m,k
            
        end

        %{
        objt = zeros(pjmax/0.01,1);
        
        %testcode
        for p = 1:1:pjmax/0.01+1
            tp=p*0.01-0.01;
            SINRu=repmat((A_t_u)./(Npiu+B_s_u+tp.*A_s_u),[1,X,Y]); %1 x y
            SINRexy=(A_t_exy)./(Npie+B_s_exy+tp.*A_s_exy); %1 x y
            objt(p)=W*squeeze(sum(sum(log2(((ones(1,X,Y)+SINRu)./((ones(1,X,Y)+SINRexy).^(sigma)))),2),3))/(X*Y); %m,k
            
        end
        %}
        
        [~, ind]=max(obj);
        
        p_k(s)= rsols(ind);
    end
end
p_k(transmitAP)=ptmax; %set initial transmitting power
end



function [hIRS,hIRSIndv,pIRS,pIRSIndv] = simulate_IRS_single(phiAligned,APxy,STAxy,IRSxy,orientationIRS,lambda,Na,Nb,Le,Pt,Gk,GSTA)

%Simulate the channel conditions introduced by multiple rectangular IRS from a single source to single destination. 
%
%Inputs:
%IRS phase elements (Nb x Na x numIRS), 
%AP locations (1 x 2) [m], 
%User location (1 x 2) [m], 
%IRS locations (numIRS x 2) [m], 
%IRS orientations (numIRS x 1), 
%carrier wavelength [m],
%number of elements along IRS width, 
%number of elements along IRS height, 
%size of element [m], 
%transmit power [watts], 
%gain of transmitter [lin.], 
%gain of receivers [lin.].
%
%Outputs:
%Channel coefficient for combined IRS [complex], 
%channel coefficients from each IRS (numIRS x 1) [complex], 
%received power [Watts], 
%each IRS power contribution (numIRS x 1) [Watts].



numIRS = size(IRSxy,1);

hIRSIndv=ones(numIRS,1);
pIRSIndv=ones(numIRS,1);


%for converting the phase shift to polar
phi=exp(phiAligned.*-1i);


if numIRS>0
    APx=APxy(1);
    APy=APxy(2);
    
    STAx=STAxy(1);
    STAy=STAxy(2);
    
    IRSx=IRSxy(:,1);
    IRSy=IRSxy(:,2);
    %AP to IRS elements distance (distance1)
    distance1=ones(Nb,Na,numIRS);
    
    %IRS elements to pos distance (distance2)
    distance2=ones(Nb,Na,numIRS);
    
    %path loss of IRS
    beta=zeros(numIRS,1);
    
    for ixIRS=1:numIRS
        dist1=sqrt(((IRSx(ixIRS)-APx)).^2+(IRSy(ixIRS)-APy).^2);
        dist2=sqrt(((IRSx(ixIRS)-STAx)).^2+(IRSy(ixIRS)-STAy).^2);
    
        %horizontal
        if orientationIRS(ixIRS)=="horizontal"
            for column = 1:Na
                for row = 1:Nb
                    distance1(row,column,ixIRS) = sqrt((IRSx(ixIRS)-(Na/2-column)*Le-APx).^2+(IRSy(ixIRS)-APy).^2+(-(Nb/2-row)*Le).^2);
                    distance2(row,column,ixIRS) = sqrt(((IRSx(ixIRS)-(Na/2-column)*Le-STAx)).^2+(IRSy(ixIRS)-STAy).^2+(-(Nb/2-row)*Le).^2);
                end
            end
            
            angleIncidence = atand(abs(APx-IRSx(ixIRS))/abs(APy-IRSy(ixIRS)));
            beta(ixIRS)=Gk*GSTA*(1/(4*pi)^2).*((Le^2)./(dist1.*dist2)).^2.*cos(angleIncidence)^2;
        
        %vertical
        elseif orientationIRS(ixIRS)=="vertical"
            for column = 1:Na
                for row = 1:Nb
                     distance1(row,column,ixIRS) = sqrt(((IRSx(ixIRS)-APx)).^2+(IRSy(ixIRS)-(Na/2-column)*Le-APy).^2+(-(Nb/2-row)*Le).^2);
                     distance2(row,column,ixIRS) = sqrt(((IRSx(ixIRS)-STAx)).^2+((IRSy(ixIRS)-(Na/2-column)*Le-STAy)).^2+(-(Nb/2-row)*Le).^2);
                end
            end
            %compensate for angular response of IRS
            angleIncidence = atand(abs(APy-IRSy(ixIRS))/abs(APx-IRSx(ixIRS)));
            beta(ixIRS)=Gk*GSTA*(1/(4*pi)^2).*((Le^2)./(dist1.*dist2)).^2.*cos(angleIncidence)^2;
        else
            error("Incorrect entered IRS orientation")
        end
    end
    
    %IRS phase shifts
    pd1=(2*pi/lambda)*distance1;
    pd2=(2*pi/lambda)*distance2;
    
    
    %generate IRS channels
    
    h1IRS2=exp((pd1+pd2)*-1i);
    
    %determine the total channel by identify each contribution from elements
    
    hTEMP=ones(Nb,Na,ixIRS);
    
    for ixIRS=1:numIRS
        for column=1:Na
            for row=1:Nb
                hTEMP(row,column,ixIRS) = phi(row,column,ixIRS).*h1IRS2(row,column,ixIRS);
            end
        end
    
        %sum the effects of columns and rows
        hTEMP2=sum(sum(hTEMP,1),2);
        hIRSIndv(ixIRS) = sqrt(beta(ixIRS))*hTEMP2(1,1,ixIRS);
        pIRSIndv(ixIRS) = Pt.*abs(hIRSIndv(ixIRS)).^2;
    end
    
    hIRS=sum(hIRSIndv);
    pIRS=Pt.*abs(hIRS).^2;
else
    hIRS=0;
    pIRS=0;
    hIRSIndv=0;
    pIRSIndv=0;
end

end
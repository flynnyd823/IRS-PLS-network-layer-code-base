%perform monte carlo simulation of environment with changing AP and IRS

close all;

%number of independent samples to be run
samples=2000;

%% network parameters
%security bias
sigma=1;

f=2.4*10^9;
c=3*10^8;
lambda = c/f;

ptmax = 1;
pjmax = 1;
N0 = 10^-12;

Gk=1;
GSTA=1;

W = 20*10^6;

Na=12; %number of IRS elements on the width
Nb=Na; %default to square configuration
Le=lambda/2; %element size [m]

%environment size
Sx = 80;
Sy = 80;

percentEve=10;
eveRes=1; %resolution for EASOR calculation

%proximity conditions
minDistanceAP = 10; %metres
minDistanceIRS=10; %metres
minDistanceAPB=10; %metres

farfieldrelax = 3*sqrt(Na*Nb*Le^2);
minDistanceUB=farfieldrelax; %metres

numAPMin=1;
numAPMax=5;
numIRSMax=7;
numIRSMin=0;

%% execute trials
APIRSresults=zeros(numIRSMax-numIRSMin+1,numAPMax-numAPMin+1,1);
for k=numAPMin:numAPMax
    fprintf('Currently on AP %d', k);
    fprintf('\n');
    [EASOR_mean, EASOR_std, Cap_u_mean, Cap_u_std] = change_numIRS(numIRSMin,numIRSMax,samples,percentEve,eveRes,k, minDistanceAPB,minDistanceUB,minDistanceAP,minDistanceIRS,lambda,Sx,Sy,Na,Nb,Le,W,N0,pjmax,ptmax,sigma,Gk,GSTA);
    APIRSresults(:,k,1)=EASOR_mean.';
    APIRSresults(:,k,2)=EASOR_std.';
    APIRSresults(:,k,3)=Cap_u_mean.';
    APIRSresults(:,k,4)=Cap_u_std.';
end


%% plotting
markers = {'o', 's', '^', 'd', 'x'}; %currently max 5 marke
close all;

figure(1) %EASOR
for k=numAPMin:numAPMax
    plot(numIRSMin:numIRSMax, APIRSresults(:,k,1), ['-' markers{k}]);
    hold on;
end
xlabel('Number of IRS');
ylabel('$\overline{\textrm{EASOR}}$ [\%]', 'Interpreter', 'latex');
ylim([0 65]);
grid on;
grid minor;
lgd = legend('K=1','K=2','K=3','K=4','K=5');
title(lgd, 'Number of AP');
hold off;

figure(2) %User throughput
for k=numAPMin:numAPMax
    plot(numIRSMin:numIRSMax, APIRSresults(:,k,3)./1e6, ['-' markers{k}]);
    hold on;
end
xlabel('Number of IRS');
ylabel('$\overline{R_u}$ [Mbit/s]', 'Interpreter', 'latex');
%ylim([-0.2 2.2]);
grid on;
grid minor;
lgd = legend('K=1','K=2','K=3','K=4','K=5');
title(lgd, 'Number of AP');
lgd.Location = 'southeast';
hold off;
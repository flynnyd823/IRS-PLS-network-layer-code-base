%perform monte carlo simulation of environment with changing IRS element
%budget

close all;

%number of independent samples to be run
samples=2000;

%% network parameters
%security bias
sigma=1;

f=2.4*10^9;
c=3*10^8;
lambda = c/f;

ptmax = 1;
pjmax = 1;
N0 = 10^-12;

Gk=1;
GSTA=1;

W = 20*10^6;

Na=12; %number of IRS elements on the width
Nb=Na; %default to square configuration
Le=lambda/2; %element size [m]

%environment size
Sx = 80;
Sy = 80;

percentEve=10;
eveRes=1; %resolution for EASOR calculation

%proximity conditions
minDistanceAP = 10; %metres
minDistanceIRS=10; %metres
minDistanceAPB=10; %metres

numIRSMin=1;
numIRSMax=6;

numAP=2;

ixIRS=numIRSMin:1:numIRSMax;
ixIRS=ixIRS(ixIRS ~= 0);
LCM_IRS = ixIRS(1);
for i = 2:length(ixIRS)
    LCM_IRS = lcm(LCM_IRS, ixIRS(i));
end

Nibudget=floor(1000/LCM_IRS)*LCM_IRS;

BUDGETresults=zeros(numIRSMax-numIRSMin,4);
for numIRS = numIRSMin:numIRSMax
    
    if numIRS>0
        Ni=Nibudget/numIRS; %must be divisible evenly
    else
        Ni=1;
    end

    if mod(sqrt(Ni), 1) == 0 %square IRS
        Na=sqrt(Ni);
        Nb=sqrt(Ni);
    else
        factorsd = divisors(Ni);
        % If even number of factors, pick the two middle ones
        Na = factorsd(length(factorsd)/2);
        Nb = factorsd(length(factorsd)/2 + 1); %bias number of rows (IRS height)
    end

    %set the far field accordingly
    minDistanceUB=3*sqrt(max(Na,Nb)*Le); %metres
    fprintf('Currently on irs %d', numIRS);
    fprintf(' with budget %d', Na);
    fprintf(' and %d', Nb);
    fprintf(' and far field condition %d', minDistanceUB);
    fprintf('\n');

    [EASOR_mean, EASOR_std, Cap_u_mean, Cap_u_std] = change_none(numIRS,numAP,percentEve,eveRes,samples,minDistanceAPB,minDistanceUB,minDistanceAP,minDistanceIRS,lambda,Sx,Sy,Na,Nb,Le,W,N0,pjmax,ptmax,sigma,Gk,GSTA);
    BUDGETresults(numIRS-numIRSMin+1,1)=EASOR_mean;
    BUDGETresults(numIRS-numIRSMin+1,2)=EASOR_std;
    BUDGETresults(numIRS-numIRSMin+1,3)=Cap_u_mean;
    BUDGETresults(numIRS-numIRSMin+1,4)=Cap_u_std;
end

%% plotting
markers = {'o', 's', '^', 'd', 'x', '+'};  % Added plus marker
close all;

figure(1)

% Plot Secrecy Outage Area on the left y-axis
yyaxis left
plot(numIRSMin:numIRSMax, BUDGETresults(:,1), ['-' markers{1}]);
xlabel('Number of IRS');
ylabel('$\overline{\textrm{EASOR}}$ [\%]', 'Interpreter', 'latex');
grid on;
grid minor;

% Plot User Capacity on the right y-axis
yyaxis right
plot(numIRSMin:numIRSMax, BUDGETresults(:,3)./1e6, ['-' markers{2}]); % Use a different marker for the second plot
ylabel('$\overline{R_u}$ [Mbit/s]', 'Interpreter', 'latex');
grid on;
grid minor;
function [eveArea, STAxy, APxy, IRSxy,orientationIRS] = generate_random_scen(Sx,Sy,percentEve,numAP,numIRS,minDistanceAPB,minDistanceUB,minDistanceAP,minDistanceIRS)

%Generate a random wireless scenario given user defined parameters.
%
%Inputs:
%environment width [m], 
%environment height [m], 
%percent eavesdroppers [%],
%number of AP, 
%number of IRS, 
%min distances: 
% AP to border, 
% AP to AP, 
% IRS to IRS,
% user to border
%
%Outputs:
%eve area dimensions, 
%user location, 
%AP locations, 
%IRS locations, 
%IRS orientations.

eavAreaTotal=Sx*Sy*percentEve/100; %m^2

xLenMin=eavAreaTotal/Sy;
xLen=randi([xLenMin Sx]);  %uniformally distribute the x length
yLen = floor(eavAreaTotal/xLen);


%select the quadrant for eaves and apply dimensions
quadrant = randi([1, 4]);
if quadrant==1 %bottom left
    xEav1=0;
    xEav2=xLen;
    yEav1=0;
    yEav2=yLen;
elseif quadrant==2 %top left
    xEav1=0;
    xEav2=xLen;
    yEav2=Sy;
    yEav1=Sy-yLen;
elseif quadrant==3 %top right
    xEav2=Sx;
    xEav1=Sx-xLen;
    yEav2=Sy;
    yEav1=Sy-yLen;
else %bottom right
    xEav2=Sx;
    xEav1=Sx-xLen;
    yEav1=0;
    yEav2=yLen;
end

eveArea= [xEav1,xEav2;yEav1,yEav2];

[x, y] = meshgrid(0:Sx, 0:Sy);
pointsFree = [x(:), y(:)];

[x_eav, y_eav] = meshgrid(xEav1:xEav2, yEav1:yEav2);
pointsEav = [x_eav(:), y_eav(:)];

%generate a random user position outside eavesdropper area
[xU, yU] = meshgrid(minDistanceUB:Sx-minDistanceUB, minDistanceUB:Sy-minDistanceUB);
pointsUser = [xU(:), yU(:)];

[xAP, yAP] = meshgrid(minDistanceAPB:Sx-minDistanceAPB, minDistanceAPB:Sy-minDistanceAPB);
pointsAP = [xAP(:), yAP(:)];

%remove the eavesdropper points
inEav = ismember(pointsUser, pointsEav, 'rows');
pointsUser = pointsUser(~inEav, :);

inEav = ismember(pointsAP, pointsEav, 'rows');
pointsAP = pointsAP(~inEav, :);

%find available border points
is_on_edge = pointsFree(:,1) == 0 | pointsFree(:,1) == Sx | ...
         pointsFree(:,2) == 0 | pointsFree(:,2) == Sy;
pointsEdge = pointsFree(is_on_edge, :);

inEav = ismember(pointsEdge, pointsEav, 'rows');
pointsEdge = pointsEdge(~inEav, :);

%generate random positions for IRS
orientationIRS=strings(numIRS,1);
IRSxy=zeros(numIRS,2);

for m=1:numIRS
    if size(pointsEdge,1)==0
        error("No more remaining space for AP");
    end
    m_index = randi(size(pointsEdge, 1));
    IRSxy(m,:) = pointsEdge(m_index, :);
    
    if IRSxy(m,1)==0||IRSxy(m,1)==Sx
        orientationIRS(m)="vertical";
    else
        orientationIRS(m)="horizontal";
    end
    
    distancesIRS = sqrt((pointsEdge(:,1) - IRSxy(m,1)).^2 + ...
             (pointsEdge(:,2) - IRSxy(m,2)).^2);

    pointsEdge(distancesIRS <= minDistanceIRS, :) = [];  % Remove all invalid border points
end  

%generate random AP locations
APxy = zeros(numAP,2);

for k=1:numAP
    if size(pointsAP,1)==0
        error("No more remaining space for AP");
    end
    k_index = randi(size(pointsAP, 1));
    APxy(k,:) = pointsAP(k_index, :);

    distancesAP = sqrt((pointsAP(:,1) - APxy(k,1)).^2 + ...
             (pointsAP(:,2) - APxy(k,2)).^2);

    pointsAP(distancesAP <= minDistanceAP, :) = [];  % Remove all unviable points for other AP

    distancesAPUser = sqrt((pointsUser(:,1) - APxy(k,1)).^2 + ...
             (pointsUser(:,2) - APxy(k,2)).^2);

    pointsUser(distancesAPUser <= 1, :) = [];  

end

%grab the user position
STA_index = randi(size(pointsUser, 1));
STAxy =  pointsUser(STA_index, :);

end

function [d_m_u, d_m_k, d_m_exy, d_mn_u ,d_mn_k ,d_mn_exy ,d_k_u ,d_k_exy, angleIncidence] = quickCompute_d(APxy,STAxy,eveArea,IRSxy,orientationIRS,Na,Nb,Le)

%Compute the distance matrixes for the environment
% 
%Inputs:
%AP location (numAP x 2) [m],
%user location (1 x 2) [m],
%IRS locations (numIRS x 2) [m]
%IRS orientations (numIRS x 1),
%number of elements along IRS width,
%num elements IRS height,
%Size of element Le [m],
% 
%Outputs:
%Distances [m] for
% IRS to user (numIRS x 1),
% IRS to AP (numIRS x numAP),
% IRS to eaves (numIRS x eX x eY),
% IRS element to user (Nb x Na x numIRS),
% IRS element to AP (Nb x Na x numIRS x numAP),
% IRS element to eve (Nb x Na x numIRS x eX x eY),
% AP to user (numAP x 1),
% AP to eaves (numAP x eX x eY),
% Incidence angle from AP to IRS (numIRS x numAP),

x1=eveArea(1,1);
x2=eveArea(1,2);
y1=eveArea(2,1);
y2=eveArea(2,2);

IRSx=IRSxy(:,1);
IRSy=IRSxy(:,2);

M=size(IRSxy,1);
K=size(APxy,1);

X=x2-x1;
Y=y2-y1;

angleIncidence=ones(M,K);
d_m_k=ones(M,K);
d_m_u=ones(M,1);
d_m_exy=ones(M,X,Y);
d_mn_u=ones(Nb,Na,M);
d_mn_k=ones(Nb,Na,M,K);
d_mn_exy=ones(Nb,Na,M,X,Y);

d_k_u=ones(K,1);
d_k_exy=ones(K,x2-x1,y2-y1);

for  k=1:K
    d_k_u(k)=sqrt((APxy(k,1)-STAxy(1))^2+(APxy(k,2)-STAxy(2))^2);
    for x=1:x2-x1
        for y=1:y2-y1
            d_k_exy(k,x,y)=sqrt((APxy(k,1)-(x1+x))^2+(APxy(k,2)-(y1+y))^2);
        end
    end
end

for m=1:M

    d_m_u(m)=sqrt((IRSx(m)-STAxy(1)).^2+(IRSy(m)-STAxy(2)).^2);

    for x=1:x2-x1
        for y=1:y2-y1
            d_m_exy(m,x,y) = sqrt((IRSx(m)-(x1+x)).^2+(IRSy(m)-(y1+y)).^2);
        end
    end

    if orientationIRS(m)=="horizontal" %ie ycoord is fixed
        for k=1:K
            d_m_k(m,k)=sqrt(((IRSx(m)-APxy(k,1))).^2+(IRSy(m)-APxy(k,2)).^2);
            angleIncidence(m,k)=atand(abs(APxy(k,1)-IRSx(m))/abs(APxy(k,2)-IRSy(m)));
        end

        for column = 1:Na
            for row = 1:Nb
                %user
                d_mn_u(row,column,m)=sqrt((IRSx(m)-(Na/2-column)*Le-STAxy(1)).^2+(IRSy(m)-STAxy(2)).^2+(-(Nb/2-row)*Le).^2);
                
                %AP
                for k=1:K
                    d_mn_k(row,column,m,k)=sqrt((IRSx(m)-(Na/2-column)*Le-APxy(k,1)).^2+(IRSy(m)-APxy(k,2)).^2+(-(Nb/2-row)*Le).^2);
                end

                %eavesdropper
                for x=1:x2-x1
                    for y=1:y2-y1
                        d_mn_exy(row,column,m,x,y) = sqrt((IRSx(m)-(Na/2-column)*Le-(x1+x)).^2+(IRSy(m)-(y1+y)).^2+(-(Nb/2-row)*Le).^2);
                    end
                end
            end
        end
   
    elseif orientationIRS(m)=="vertical" %ie x coord is fixed

        for k=1:K
            d_m_k(m,k)=sqrt(((IRSx(m)-APxy(k,1))).^2+(IRSy(m)-APxy(k,2)).^2);
            angleIncidence(m,k)=atand(abs(APxy(k,2)-IRSy(m))/abs(APxy(k,1)-IRSx(m)));
        end
        
        for column = 1:Na
            for row = 1:Nb
                %user
                d_mn_u(row,column,m)=sqrt((IRSx(m)-STAxy(1)).^2+(IRSy(m)-(Na/2-column)*Le-STAxy(2)).^2+(-(Nb/2-row)*Le).^2);

                %AP
                for k=1:K
                    d_mn_k(row,column,m,k)=sqrt((IRSx(m)-APxy(k,1)).^2+(IRSy(m)-(Na/2-column)*Le-APxy(k,2)).^2+(-(Nb/2-row)*Le).^2);
                end

                %eavesdropper
                for x=1:x2-x1
                    for y=1:y2-y1
                        d_mn_exy(row,column,m,x,y) = sqrt((IRSx(m)-(x1+x)).^2+(IRSy(m)-(Na/2-column)*Le-(y1+y)).^2+(-(Nb/2-row)*Le).^2);
                    end
                end
            end    
        end
    else
        error("Incorrect entered IRS orientation")
    end
end

%correct minimum values (zero exceptions)

d_m_k(d_m_k == 0) = 0.001;
d_m_u(d_m_u == 0) = 0.001;
d_m_exy(d_m_exy == 0) = 0.001;
d_mn_u(d_mn_u == 0) = 0.001;
d_mn_k(d_mn_k == 0) = 0.001;
d_mn_exy(d_mn_exy == 0) = 0.001;
d_k_u(d_k_u == 0) = 0.001;

end
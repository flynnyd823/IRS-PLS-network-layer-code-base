%Generates the first example scenario used to show IRS beam patterns

Sx = 80;
Sy = 80;

%user (x,y)
STAxy = [16 16];

%access point (x,y)\120
APxy=[60 64;
24	32];

%IRS locations (x,y)
IRSxy=[round(Sx/2) Sy
    Sx round(Sy/2);
    ];

% eavesdropper area x1 x2 y1 y2
eveArea=[round(Sx/2),Sx;0,round(Sy/2)];

%% do not change

numAP=size(APxy,1);
numIRS=size(IRSxy,1);

orientationIRS=strings(numIRS,1);

for m=1:numIRS
    if IRSxy(m,1)==0||IRSxy(m,1)==Sx
        orientationIRS(m)="vertical";
    else
        orientationIRS(m)="horizontal";
    end
end



%throw error messages (do not delete)
if size(eveArea,1)~=2||size(eveArea,2)~=2
    error("Incorrectly defined eavesdropper area");
elseif size(STAxy,1)>1
    error("Only one user position should be defined");
end
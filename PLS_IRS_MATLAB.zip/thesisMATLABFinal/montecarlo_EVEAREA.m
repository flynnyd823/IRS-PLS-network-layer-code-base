%perform monte carlo simulation of environment with changing eavesdropper
%area

close all;

%number of independent samples to be run
samples=2000;

%% network parameters
%security bias
sigma=1;

f=2.4*10^9;
c=3*10^8;
lambda = c/f;

ptmax = 1;
pjmax = 1;
N0 = 10^-12;

Gk=1;
GSTA=1;

W = 20*10^6;

Na=12; %number of IRS elements on the width
Nb=Na; %default to square configuration
Le=lambda/2; %element size [m]i

%environment size
Sx = 80;
Sy = 80;

eveRes=1; %resolution for EASOR calculation

%proximity conditions
minDistanceAP = 10; %metres
minDistanceIRS=10; %metres
minDistanceAPB=10; %metres

farfieldrelax = 3*sqrt(Na*Nb*Le^2);
minDistanceUB=farfieldrelax; %metres


%choose the bounds of the percent of environment taken up by eve
percentEvemin=5; 
percentEvemax=40; 
percentEveDiscrete=5; %increments at which to increase xi

numIRSMax=5;
numIRSMin=2;

numAP=2;

XIresults=zeros(numIRSMax-numIRSMin+1,(percentEvemax-percentEvemin)/5+1,4);

for percentEve=percentEvemin:percentEveDiscrete:percentEvemax
    fprintf('Currently on area %d', percentEve);
    fprintf('\n');
    [EASOR_mean, EASOR_std, Cap_u_mean, Cap_u_std]  = change_numIRS(numIRSMin,numIRSMax,samples,percentEve,eveRes,numAP, minDistanceAPB,minDistanceUB,minDistanceAP,minDistanceIRS,lambda,Sx,Sy,Na,Nb,Le,W,N0,pjmax,ptmax,sigma,Gk,GSTA);
    XIresults(:,1+(percentEve-percentEvemin)/percentEveDiscrete,1)=EASOR_mean.';
    XIresults(:,1+(percentEve-percentEvemin)/percentEveDiscrete,2)=EASOR_std.';
    XIresults(:,1+(percentEve-percentEvemin)/percentEveDiscrete,3)=Cap_u_mean.';
    XIresults(:,1+(percentEve-percentEvemin)/percentEveDiscrete,4)=Cap_u_std.';
end



%% plot
markers = {'o', 's', '^', 'd', 'x', '+'};  % Added plus marker

close all;
figure(1)

for m=1:numIRSMax-numIRSMin+1
    plot(percentEvemin:percentEveDiscrete:percentEvemax, XIresults(m,:,1), ['-' markers{m}]);
    hold on;
end

xlabel('Eavesdropper area [%]');
ylabel('$\overline{\textrm{EASOR}}$ [\%]', 'Interpreter', 'latex');
grid on;
grid minor;
lgd = legend('M=2','M=3','M=4','M=5');
title(lgd, 'Number of IRS');


figure(2)
for m=1:numIRSMax-numIRSMin+1
    plot(percentEvemin:percentEveDiscrete:percentEvemax, XIresults(m,:,3), ['-' markers{m}]);
    hold on;
end

xlabel('Eavesdropper area [%]');
ylabel('$\overline{R_u}$ [Mbit/s]', 'Interpreter', 'latex');
grid on;
grid minor;
lgd = legend('M=2','M=3','M=4','M=5');
lgd.Location = 'southeast';
title(lgd, 'Number of IRS');

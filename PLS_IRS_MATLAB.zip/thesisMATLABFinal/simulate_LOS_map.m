function [hLOS, pLOS] = simulate_LOS_map(dx,dy,Nx,Ny,APxy,lambda,Pt,Gk,GSTA)

%Simulate the channel conditions for line of sight from a single source to a square map.
%
%Inputs:
%x resolution [1/m], 
%y resolution [1/m], 
%grid Nx, 
%grid Ny, 
%AP location (1 x 2) [m], 
%carrier wavelength [m], 
%transmit power [watts], 
%gain of transmitter [lin.], 
%gain of receivers [lin.].
%
%Outputs:
%Channel coefficient for LOS [complex], 
%received power [Watts].

APx=APxy(1);
APy=APxy(2);

distance = zeros(Nx,Ny);

for x = 1:Nx
    for y = 1:Ny
        distance(x,y) = sqrt(((x*dx-(APx))).^2+((y*dy-(APy))).^2);
    end
end

%phase shifts
pdLOS=(2*pi/lambda)*distance;

%generate channel
hLOS = sqrt(Gk*GSTA*(lambda/(4*pi))^2).*(1./distance).*exp(pdLOS*-1i);
pLOS=Pt.*abs(hLOS).^2;
end
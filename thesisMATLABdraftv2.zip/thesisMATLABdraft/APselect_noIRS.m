function [selectedAP] = APselect_noIRS(d_k_u,d_k_exy,lambda,alpha,N0,W,ptmax,pjmax)

%Determine the access point connections based on signal to noise advantage
%over average eavesdropper area (including the mutual interference on same
%channel).
%
%Inputs: 
%AP locations (numAP x 2) [m], User location (numUser x 2) [m], eavesdropper location border (4 x 1) [m],
%carrier wavelength [m], spatial resolution [1/m], IRS locations (numIRS x 2) [m], 
%IRS orientations (numIRS x 1), number of elements per IRS, size width of
%element on IRS [m], IRS phases (√NI x √NI x numIRS) [rads], noise floor
%[lin.], bandwidth [Hz]
% 
%Outputs:
%Return recommended connections (numUser x 1), maximum SINR advantage (numUser x 1), user secrecy
%outage probability (numUser x 1) [%].

%set up arrays

numAP=size(d_k_u,1);

X=size(d_k_exy,2);
Y=size(d_k_exy,3);

%find all channel coefficients between user to AP and eaves to AP

if numAP>1
    phi_k_u=(2*pi/lambda)*d_k_u;
    phi_k_exy=(2*pi/lambda).*d_k_exy;
    
    a_k_u = lambda.*(exp(1i.*(phi_k_u)))./d_k_u; 
    a_k_exy=lambda.*(exp(1i.*(phi_k_exy)))./d_k_exy;
    
    %all AP
    A_k_u=abs(a_k_u).^2;
    A_k_exy=abs(a_k_exy).^2;
    
    %jamming effect
    A_j_u=ones(numAP,1);
    A_j_exy=ones(numAP,X,Y);
    
    for kconnected = 1:numAP
        for kinterference=1:numAP
            if kinterference~=kconnected
                A_j_u(kconnected)=A_j_u(kconnected)+A_k_u(kinterference);
                A_j_exy(kconnected)=A_j_exy(kconnected)+A_k_exy(kinterference);
            end
        end
    end
    
    %normalized noise term
    Npi=4*pi*W*N0;
    
    %calculate SINR
    SINRu = repmat(ptmax.*A_k_u./(Npi+pjmax.*A_j_u),[1,X,Y]);
    SINRexy = ptmax.*A_k_exy./(Npi+pjmax.*A_j_exy);
    
    
    
    obj=squeeze(sum(sum(log2(((ones(1,X,Y)+SINRu)./((ones(1,X,Y)+SINRexy).^(alpha)))),2),3)); %m,k   
    
    [~,I]=max(obj);
    %take the index (best AP)
    selectedAP=I;
    
    
    %for eavesdropper only capable of connecting to one AP at a time
    %{
    %access points decided
    availableAP = unique(selectedAP(:).');
    
    eavSINRdiff=zeros(Ne,1);
    eveConnectionMap=zeros(Ne,1);
    tempSINR = ones(size(availableAP));
    
    for e=1:Ne %for each eavesdropper location
        for ja = 1:size(availableAP) %and for each available access point
            tempSINR(e,ja)=SINREaves(e,ja);
        end
        [eavSINRdiff(e), eveConnectionMap(e)]= max(tempSINR(e,:)); %indicate channel wiretap and strength
    end
    
    userSINR2=zeros(size(STAxy,1));
    
    for k=1:size(STAxy,1) %for each user get the SINR
        userSINR2(k)=SINRUser(k,selectedAP(k));
    end
    
    eavCAPMax = W.*log2(eavSINRdiff+1); %strongest eavesdropper capacity Ne x 1 matrix to AP defined by eveConnectionMap
    userCAPMax = W.*log2(userSINR2+1); %user capacity according to selectedAP
    
    %for every user calculate the SOP given that eavesdropper only associate
    %with strongest AP
    userSOP=zeros(size(STAxy,1),1);
    tempSOP =0;
    
    for k=1:size(STAxy,1)
        for e=1:Ne
            if(eveConnectionMap(e)==selectedAP(k)) %if the eavesdropper is connected to the same AP as the user
                if(eavCAPMax(e)>userCAPMax(k)/2) %define the condition for SOP threshold
                    tempSOP=tempSOP+1;
                end
            end
        end
        userSOP(k)=tempSOP/Ne;
        tempSOP=0;
    end
    %}
else
    selectedAP=1;
end
end


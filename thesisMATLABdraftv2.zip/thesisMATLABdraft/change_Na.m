function [SOA_mean, SOA_std, Cap_u_mean, Cap_u_std] = change_Na(Namin,Namax,percentEve,numIRS, numAP,minDistanceSTA,distanceBorder,minDistanceAP,minDistanceIRS,lambda,Sx,Sy,Li,W,N0,P0,d0,pjmax,ptmax,alpha)

%keeping IRS square
Cap_u_results=ones(samples,numIRSMax-numIRSMin+1);
SOA_results=ones(samples,numIRSMax-numIRSMin+1);

for Na=Namin:Namax
    Nb=Na;
    for s=1:samples
        fprintf('Currently on sample %d', s);
        fprintf('\n');
        %solvers
        [eveArea, STAxy, APxy, IRSxy,orientationIRS] = monte_carlo_scen(Sx,Sy,percentEve,numAP,numIRS, minDistanceSTA,distanceBorder,minDistanceAP,minDistanceIRS);
        [d_m_u, d_m_k, d_m_exy, d_mn_u ,d_mn_k ,d_mn_exy ,d_k_u ,d_k_exy, angleIncidence]=quickCompute_d(APxy,STAxy,eveArea,IRSxy,orientationIRS,Na,Nb,Li);
        
        transmitAP=APselect_noIRS(d_k_u,d_k_exy,lambda,alpha,N0,W,ptmax,pjmax);
        
        phiAligned = optimise_IRS_Align(d_m_u, d_m_k, d_m_exy, d_mn_u ,d_mn_k ,d_mn_exy ,d_k_u ,d_k_exy, angleIncidence,lambda,Na,Nb,Li,W,N0,pjmax,ptmax,transmitAP,alpha);
        
        p_k=FJpower(d_m_u, d_m_k, d_m_exy, d_mn_u ,d_mn_k ,d_mn_exy ,d_k_u ,d_k_exy, ...
            angleIncidence,phiAligned,ptmax,transmitAP, Li,lambda,W,alpha,N0,pjmax);
    
        APs=APxy(transmitAP,:);

        hLOS=simulate_LOS_single(APs,STAxy,lambda,d0,P0,ptmax);
        hIRS = simulate_IRS_single(phiAligned,APs,STAxy,IRSxy,orientationIRS,lambda,P0,d0,Na,Nb,Li,ptmax);
        hLOSIRS_u=hLOS+hIRS;
        pLOSIRS_u=ptmax*abs(hLOSIRS_u).^2;
    
        pLOSIRSj_u=0;
    
        for k=1:numAP
            if k~=transmitAP
                pj=p_k(k);
                hLOSj = simulate_LOS_single(APxy(k,:),STAxy,lambda,d0,P0,pj);
                hIRSj = simulate_IRS_single(phiAligned,APxy(k,:),STAxy,IRSxy,orientationIRS,lambda,P0,d0,Na,Nb,Li,pj);
                hLOSIRSj_u=hLOSj+hIRSj;
                pLOSIRSj_u=pLOSIRSj_u+pj.*abs(hLOSIRSj_u).^2;
            end
        end
    
        Cap_u=W*log2(1+pLOSIRS_u/(W*N0+pLOSIRSj_u));
        eveCap=calculate_eaves_cap(APxy, IRSxy,orientationIRS,transmitAP, eveArea, eveDiscrete, lambda,W, N0,ptmax,p_k,d0,P0,Na,Nb,Li,phiAligned);
        
        sCAP=repmat(Cap_u,size(eveCap,1),size(eveCap,2))-eveCap;
        %sCAPn=sum(sCAP,"all")/numel(sCAP);
        
        %calculate the secrecy outage area as percentage
        ratio = 100*sum(sCAP<(1/2*Cap_u),"all")/numel(sCAP);
        
        SOA_results(s,numIRS-numIRSMin+1)=ratio;
        Cap_u_results(s,numIRS-numIRSMin+1)=Cap_u;
    
    end
end

SOA_mean=mean(SOA_results,1);
SOA_std=std(SOA_results,1);

Cap_u_mean=mean(Cap_u_results,1);
Cap_u_std=std(Cap_u_results,1);

end

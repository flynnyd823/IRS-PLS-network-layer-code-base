function selectedAP = APselectorWiFi(APxy,STAxy,eveArea,dx,dy,lambda)

%Determine the access point connections based on strongest signal (Wi-FI). Return connections, maximum SINR advantage and user secrecy
%outage probability (Credit: Sayed Amir Hoseini 2022). 

P0=((lambda/(4*pi))^2);
if size(STAxy,2) == 1
    STAxyoc = STAxy';
else
    STAxyoc = STAxy;
end

if iscolumn(APxy)
    APxyec = APxy';
else
    APxyec = APxy;
end


dU = zeros(size(APxy,1),1);

Ne = (1/dx)*(1/dy)*(eveArea(2,2)-eveArea(2,1))*(eveArea(1,2)-eveArea(1,1));

selectedAP = zeros(size(STAxy,1),1);
hUser = ones(size(STAxy,1),1);
hEaves = ones(Ne,size(APxy,1));

for k=1:size(STAxy,1)
    for j=1:size(APxy,1)
        apXY = squeeze(APxyec(j,:));
        usrXY = squeeze(STAxyoc(k,:));
        dU(j) = sqrt((apXY(1)-usrXY(1)).^2+(apXY(2)-usrXY(2)).^2);
    end

[~, selectedAP(k)] = min(dU); %minimise distance
end


end

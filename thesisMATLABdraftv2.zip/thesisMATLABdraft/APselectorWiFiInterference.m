function [selectedAP,SINRdiff,userSOP] = APselectorWiFiInterference(APxy,STAxy,eveArea,dx,dy,phi,xIRS,yIRS,orientationIRS,lambda,kfactor,Ni,Li,B,N)

%Determine the access point connections based on strongest signal (Wi-FI)
%including channel interference. Return connections, maximum SINR advantage and user secrecy
%outage probability


P0=((lambda/(4*pi))^2);

Ne = (1/dx)*(1/dy)*(eveArea(2,2)-eveArea(2,1))*(eveArea(1,2)-eveArea(1,1));

selectedAP = zeros(size(STAxy,1),1);

hUser = ones(size(STAxy,1),size(APxy,1));
hEaves = ones(Ne,size(APxy,1));

for k=1:size(STAxy,1)
    %user location k
    STAx=STAxy(k,1);
    STAy=STAxy(k,2);

    for j=1:size(APxy,1)
        %AP location j
        APx=APxy(j,1);
        APy=APxy(j,2);
        
        hLOSUser = simulate_LOSnoRic_SISO(APx,APy,STAx,STAy,lambda);
        hIRSUser = simulate_IRS_SISO(phi,APx,APy,STAx,STAy,xIRS,yIRS,orientationIRS,lambda,Ni,Li);
        
        hUser(k,j)=hLOSUser+hIRSUser;
    end
end

i=0;

for j=1:size(APxy,1)

        %AP location j
        APx=APxy(j,1);
        APy=APxy(j,2);
        %find the eavesdropper capacitor to all AP (save no. calc for large user size) 
        for ex=(eveArea(1,1)/dx):(eveArea(1,2)/dx)-1
            for ey=(eveArea(2,1)/dy):(eveArea(2,2)/dy)-1
                i=i+1;
                %apply desired resolution
                eveX=ex*dx;
                eveY=ey*dx;

                hLOSeve = simulate_LOSnoRic_SISO(APx,APy,eveX,eveY,lambda);
                hIRSeve = simulate_IRS_SISO(phi,APx,APy,eveX,eveY,xIRS,yIRS,orientationIRS,lambda,Ni,Li);
                
                hEaves(i,j)=hLOSeve+hIRSeve;
                
            end
        end
        i=0;
end 
%transform to power
pUser=P0.*abs(hUser).^2;
pEaves=P0.*abs(hEaves).^2;

%interference calculations
pUserInt = zeros(size(STAxy,1),size(APxy,1));
pEavesInt = zeros(Ne,size(APxy,1));

for k = 1:size(STAxy,1)
    for jconnected=1:size(APxy,1)
        for jinterference=1:size(APxy,1)
            if jinterference~=jconnected
                pUserInt(k,jconnected)=pUserInt(k,jconnected)+pUser(k,jinterference);
            end
        end
    end
end

for e = 1:Ne
    for jconnected=1:size(APxy,1)
        for jinterference=1:size(APxy,1)
            if jinterference~=jconnected
                pEavesInt(e,jconnected)=pEavesInt(e,jconnected)+pEaves(e,jinterference);
            end
        end
    end
end

%calculate SINR
SINRUser = pUser./(B*N+pUserInt);
SINREaves = pEaves./(B*N+pEavesInt);

%average along the first dimension (all discrete positions)
SINREavesAve = sum(SINREaves,1)./Ne; 

for user=1:size(STAxy,1)
    %take the maximum signal strength in the interference
   [M,I]=max(SINRUser(user,:));
   %take the index (best AP)
   selectedAP(user)=I;
end

SINRdiff = ones(size(STAxy,1),1);
for k=1:size(STAxy,1)
    SINRdiff(k) = SINRUser(k)-SINREavesAve(selectedAP(k));
end

%eaves connects to all AP simultaneously
userSINR2=zeros(size(STAxy,1));

for k=1:size(STAxy,1) %for each user get the SINR
    userSINR2(k)=SINRUser(k,selectedAP(k));
end

eavCAPMax = B.*log2(SINREaves+1); %eavesdropper capacity Ne x j matrix
userCAPMax = B.*log2(userSINR2+1); %user capacity according to selectedAP

%for every user calculate the SOP given that eavesdropper can associate
%with any AP. 
userSOP=zeros(size(STAxy,1),1);
tempSOP =0;

for k=1:size(STAxy,1)
    for e=1:Ne
        if(eavCAPMax(e,selectedAP(k))>userCAPMax(k)/2) %define the condition for SOP threshold being more than half the user capacity
            tempSOP=tempSOP+1;
        end
    end
    userSOP(k)=tempSOP/Ne;
    tempSOP=0;
end

end

function [hLOS, pLOS] = simulate_LOS_single(APxy,STAxy,lambda,d0,P0,Pt)

%Simulate the channel conditions for line of sight from a single source to single destination. 
%
%Inputs:
%AP location (1 x 2) [m], User location (1 x 2) [m], carrier wavelength [m], reference power [watts], 
%reference distance [m], transmit power [watts].
%
%Outputs:
%Channel coefficient for LOS [complex], received power [Watts].

APx=APxy(1);
APy=APxy(2);

STAx=STAxy(1);
STAy=STAxy(2);

%LOS distance
distance = sqrt(((STAx-(APx))).^2+((STAy-(APy))).^2);

%LOS phase shifts
pdLOS=(2*pi/lambda)*distance;

%generate rician channel for LOS link
%[~, h] = simulate_channels(kfactor, 1);
ric=1;

%generate LOS channel
hLOS = sqrt(P0.*ric).*(d0./distance).*exp(pdLOS*1i);
pLOS= Pt.*abs(hLOS).^2;
end
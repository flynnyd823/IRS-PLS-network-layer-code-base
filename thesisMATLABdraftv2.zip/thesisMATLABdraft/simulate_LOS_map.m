function [hLOS, pLOS] = simulate_LOS_map(dx,dy,Nx,Ny,APxy,lambda,P0,d0,Pt)

%Simulate the channel conditions for line of sight from a single source to a square map.
%
%Inputs:
%x resolution, y resolution, grid x, grid y, AP location (1 x 2) [m], 
%carrier wavelength [m], reference power [watts], reference distance [m], transmit power [watts].
%
%Outputs:
%Channel coefficient for LOS [complex], received power [Watts].

APx=APxy(1);
APy=APxy(2);

distance = zeros(Nx,Ny);

for x = 1:Nx
    for y = 1:Ny
        distance(x,y) = sqrt(((x*dx-(APx))).^2+((y*dy-(APy))).^2);
    end
end

%phase shifts
pdLOS=(2*pi/lambda)*distance;

%generate rician channels
%{

for hi = 1:Ny
    [~, h_rician] = simulate_channels(kfactor, Nx);
    h(:,hi)=h_rician;
end
%}

ric=ones(Nx,Ny);

%generate channel
hLOS = sqrt(P0.*ric).*(d0./distance).*exp(pdLOS*1i);
pLOS=Pt.*abs(hLOS).^2;
end
%Create a basic scenario for simple simulation functionality testing


numAP=2;
numIRS=3;
Sx = 100;
Sy = 100;

%user (x,y)
STAxy = [25 30];

%access point (x,y)
APxy = [120 140; % just to make the user and eavesdropper do not fall exactly on the APs
45 90;
]*Sx/200;

%IRS locations (x,y)
IRSxy=[round(Sx/2) Sy
    0 round(Sy/2); ...
    Sx round(Sy/2) ...
    ];

orientationIRS=["horizontal","vertical","vertical"];

% eavesdropper area x1 x2 y1 y2
eveArea=[Sx/2,Sx;0,Sy/2];

%throw error messages (do not delete)
if size(eveArea,1)~=2||size(eveArea,2)~=2
    error("Incorrectly defined eavesdropper area");
elseif size(orientationIRS)~=size(IRSxy,1)
    error("Sumber of IRS positions does not match number of IRS orientations");
elseif size(IRSxy)~=2
    error("Array for IRS positions incorrectly defined")
elseif size(APxy)~=2
    error("Array for AP positions incorrectly defined")
end
function [eveArea, STAxy, APxy, IRSxy,orientationIRS] = monte_carlo_scen(Sx,Sy,percentEve,numAP,numIRS, minDistanceSTA,distanceBorder,minDistanceAP,minDistanceIRS)

    %calculate the optimal phase shifts
    %generate a random area for eavesdroppers given size limit
    restartL = true;
    
    eavAreaTotal=Sx*Sy*percentEve/100; %m^2

    xLenMin=eavAreaTotal/Sy;
    xLen=randi([xLenMin Sx]);  %uniformally distribute the x length
    yLen = floor(eavAreaTotal/xLen);
    
    quadrant = randi([1, 4]);
    if quadrant==1 %bottom left
        xEav1=0;
        xEav2=xLen;
        yEav1=0;
        yEav2=yLen;
    elseif quadrant==2 %top left
        xEav1=0;
        xEav2=xLen;
        yEav2=Sy;
        yEav1=Sy-yLen;
    elseif quadrant==3 %top right
        xEav2=Sx;
        xEav1=Sx-xLen;
        yEav2=Sy;
        yEav1=Sy-yLen;
    else %bottom right
        xEav2=Sx;
        xEav1=Sx-xLen;
        yEav1=0;
        yEav2=yLen;
    end

    eveArea= [xEav1,xEav2;yEav1,yEav2];
    
    %generate a random user position outside eavesdropper area
    [x, y] = meshgrid(0:Sx, 0:Sy);
    pointsAll = [x(:), y(:)];
    [xMar, yMar] = meshgrid(distanceBorder:Sx-distanceBorder, distanceBorder:Sy-distanceBorder);
    pointsMargin = [xMar(:), yMar(:)];

    [x_eav, y_eav] = meshgrid(xEav1:xEav2, yEav1:yEav2);
    eav_points = [x_eav(:), y_eav(:)];

    is_in_subset = ismember(pointsAll, eav_points, 'rows');
    all_points = pointsAll(~is_in_subset, :);

    is_in_subset_mar = ismember(pointsMargin, eav_points, 'rows');
    remaining_points = pointsMargin(~is_in_subset_mar, :);

    is_on_edge = all_points(:,1) == 0 | all_points(:,1) == Sx | ...
             all_points(:,2) == 0 | all_points(:,2) == Sy;
    edge_points = all_points(is_on_edge, :);

    original_edge_points=edge_points; %keep constant

    STA_index = randi(size(remaining_points, 1));
    STAxy = remaining_points(STA_index, :);

    distancesSTA = sqrt((remaining_points(:,1) - STAxy(1)).^2 + ...
                 (remaining_points(:,2) - STAxy(2)).^2);

    remaining_points(distancesSTA <= minDistanceSTA, :) = [];  % Remove all points within 1 metre

    original_points=remaining_points; %keep constant

    %generate random AP locations
    APxy = zeros(numAP,2);
    while restartL
        restartL=false;
        remaining_points = original_points;
        for k=1:numAP
            if size(remaining_points,1)==0
                %error("No more remaining space for AP");
                restartL = true;
                break;  % Exit the for loop and restartL it
            end
            k_index = randi(size(remaining_points, 1));
            APxy(k,:) = remaining_points(k_index, :);
    
            distancesAP = sqrt((remaining_points(:,1) - APxy(k,1)).^2 + ...
                     (remaining_points(:,2) - APxy(k,2)).^2);
    
            remaining_points(distancesAP <= minDistanceAP, :) = [];  % Remove all points within 1 metre
            %remaining_points(k_index, :) = [];
        end
    end
 
    %generate random positions for IRS
  
    restartL = true;
    orientationIRS=strings(numIRS,1);
    IRSxy=zeros(numIRS,2);

    while restartL
        restartL=false;
        edge_points=original_edge_points;
        for m=1:numIRS
            if size(edge_points,1)==0
                %error("No more remaining space for AP");
                restartL = true;
                break;  % Exit the for loop and restartL it
            end
            m_index = randi(size(edge_points, 1));
            IRSxy(m,:) = edge_points(m_index, :);
            
            if IRSxy(m,1)==0||IRSxy(m,1)==Sx
                orientationIRS(m)="vertical";
            else
                orientationIRS(m)="horizontal";
            end
            
            distancesIRS = sqrt((edge_points(:,1) - IRSxy(m,1)).^2 + ...
                     (edge_points(:,2) - IRSxy(m,2)).^2);
    
            edge_points(distancesIRS <= minDistanceIRS, :) = [];  % Remove all points within 1 metre
            %edge_points(m_index, :) = [];
        end  
    end


end

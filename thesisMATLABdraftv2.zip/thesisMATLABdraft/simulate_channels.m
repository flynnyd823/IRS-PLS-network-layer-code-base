% Function to simulate Rayleigh and Rician fading channels
function [h_rayleigh, h_rician] = simulate_channels(rician_K, num_samples)
    % Rayleigh fading channel simulation
    h_rayleigh = (randn(1, num_samples) + 1j*randn(1, num_samples))/sqrt(2);
    % Rician fading channel simulation
    h_rician = sqrt(rician_K/(rician_K+1)) * ones(1, num_samples) + sqrt(1/(rician_K+1)) * (randn(1, num_samples) + 1j*randn(1, num_samples))/sqrt(2);
end
function Output = single_objective_function(transmitAPop,phiAlignedop,p_jop)

%load scenario


scCustomSimple;


%Carrier frequency [Hz]
f=2.4*10^9;
%speed of light [constant]
c=3*10^8;
%wavelength [m]
lambda = c/f;

W = 20*10^6;
N0 = 10^-14;
%IRS dimensions [element]
NL=10;

%IRS elements [element x element]
Ni=NL^2;

%element size [m]
Li=lambda/5;
%transmit power [watts]
ptmax = 1;

%reference distance and corresponding power
d0 = 1;
P0= (lambda/(4*pi*d0))^2;

%transform jammer powers to include transmit power
p_kop = zeros(numAP,1);

inAP=false;

for n=1:numAP
    if n==transmitAPop
        p_kop(n)=1;
        inAP=true;
    else
        if inAP
            p_kop(n)=p_jop(n-1);
        else
            p_kop(n)=p_jop(n);
        end
    end
end



f1= calculate_user_cap(APxy, STAxy,IRSxy,orientationIRS,transmitAPop, lambda,W, N0,ptmax,p_kop,d0,P0,Ni,Li,phiAlignedop);

eveDiscrete=2; %for SOA calculation
eveCap=calculate_eaves_cap(APxy, IRSxy,orientationIRS,transmitAPop, eveArea, eveDiscrete, lambda,W, N0,ptmax,p_kop,d0,P0,Ni,Li,phiAlignedop);

sCAP=repmat(f1,size(eveCap,1),size(eveCap,2))-eveCap;

%calculate the SOA
f2 = sum(sCAP<(1/2*f1),"all")/numel(sCAP);

Output = f2;
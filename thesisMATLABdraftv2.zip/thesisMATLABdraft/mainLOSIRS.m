close all;
%clear all;

%fix random seed (if desired)
%rng(1993); 

%simulation constraints:
%Na>1
%Nb>1
%num USER = 1
%X,Y>1
%numAP>1

%%
%network operating parameters

%Carrier frequency [Hz]
f=2.4*10^9;
%speed of light [constant]
c=3*10^8;
%wavelength [m]
lambda = c/f;

%transmit power [watts]
ptmax = 1;

%maximum jammer power [watts]
pjmax = 1;

%receiver gain and transmit gain [lin.]
Gr=1;
Gt=1;

%noise floor [lin.]
N0 = 10^-14;
%N0=0;

%rician-k factor (5-8 for indoor settings)
kfactor=100000;

%reference distance and corresponding power
d0 = 1;
P0= Gr*Gt*(lambda/(4*pi*d0))^2;

%bandwidth [Hz]
W = 20*10^6;

%%
%IRS parameters (shared)

%IRS dimensions [element]
Na=10;
Nb=10;

%IRS elements [element x element]
Ni=Na*(Nb);

%element size [m]
Li=lambda/5;

%far field (rayleigh distance) where simple channel gain model applied [m]
%farfield=2*(Li*max(Na,Nb))^2/lambda;


%%

%SIZE of environment (m)
Sx = 100;
Sy = 100;

%RESOLUTION of images
Nx = 200;
Ny = round(Nx*Sy/Sx);
dx = Sx/Nx;
xa = (0:Nx)*dx;
dy = Sy/Ny;
ya = (0:Ny)*dy;

eveDiscrete=2; %for SOA calculation

%calculate phase discrepancy to occur over surface of IRS (validity of path
%loss model) [degrees]
phaseDiscrepancy=(pi/4)*(Li*max(Na,Nb))^2/(lambda*20)*180/pi;


%%
%perform monte carlo simulation of environment

samples=1;

alpha=1;%security bias

minDistanceAP = 10; %metres
minDistanceIRS=10; %metres
distanceBorder=10; %metres
minDistanceSTA=2; %metres

numAPMin=1;
numIRSMin=0;

Na=10; %number of IRS elements on the width
Nb=Na; %default square config

percentEve=20; %percent area covered by eavesdropper
percentDiscrete=0.5; %1/percentDiscrete = step size

%calculate limits on number of nodes
eveArea=percentEve/100*(Sx*Sy);
Area_perAP=pi*(minDistanceAP)^2; %area occupied by an AP
Area_AP_available=(Sx-2*distanceBorder)*(Sy-2*distanceBorder)-(eveArea-2*sqrt(eveArea)*distanceBorder+(distanceBorder)^2)-pi*minDistanceSTA^2; %total area that AP can be placed in
numAPMax=floor(Area_AP_available/Area_perAP); %theoretical max number of AP under worst case placement

Br = ceil(eveArea/max(Sx,Sy));
B=Br+eveArea/Br;
BIRS=2*minDistanceIRS;
numIRSMax=floor(B/BIRS);

%for no friendly jamming
%pjmax=0;
%for direct signal
%selectedAP = APselectorWiFi(APxy,STAxy,eveArea,dx,dy,lambda);

numAP=3;
[SOA_mean, SOA_std, Cap_u_mean, Cap_u_std] = change_numIRS(numIRSMin,numIRSMax,samples,percentEve,eveDiscrete,numAP, minDistanceSTA,distanceBorder,minDistanceAP,minDistanceIRS,lambda,Sx,Sy,Na,Nb,Li,W,N0,P0,d0,pjmax,ptmax,alpha);
ixMin = numIRSMin;                                                           
ixMax = numIRSMax;
%[SOA_mean, SOA_std, Cap_u_mean, Cap_u_std] = change_numAP(numAPMin,numAPMax,samples,percentEve,eveDiscrete,numIRS, minDistanceSTA,distanceBorder,minDistanceAP,minDistanceIRS,lambda,Sx,Sy,Na,Nb,Li,W,N0,P0,d0,pjmax,ptmax,alpha);

%[SOA_mean, SOA_std, Cap_u_mean, Cap_u_std] =
%change_alpha(alphaDiscrete,samples,percentEve,numIRS, numAP,minDistanceSTA,distanceBorder,minDistanceAP,minDistanceIRS,lambda,Sx,Sy,Na,Nb,Li,W,N0,P0,d0,pjmax,ptmax);

%[SOA_mean, SOA_std, Cap_u_mean, Cap_u_std]
%=change_Na(Namin,Namax,percentEve,numIRS,
%numAP,minDistanceSTA,distanceBorder,minDistanceAP,minDistanceIRS,lambda,Sx,Sy,Li,W,N0,P0,d0,pjmax,ptmax,alpha);

%[SOA_mean, SOA_std, Cap_u_mean, Cap_u_std] =
%change_percentEve(percentmin,percentmax,percentDiscrete,samples,numIRS, numAP,minDistanceSTA,distanceBorder,minDistanceAP,minDistanceIRS,lambda,Sx,Sy,Li,W,N0,P0,d0,pjmax,ptmax,alpha);

%budget IRS elements
%{
ixIRS=numIRSMin:1:numIRSMax;
ixIRS=ixIRS(ixIRS ~= 0);
LCM_IRS = ixIRS(1);
for i = 2:length(ixIRS)
    LCM_IRS = lcm(LCM_IRS, ixIRS(i));
end

Nibudget=floor(1000/LCM_IRS)*LCM_IRS;

for numIRS = numIRSMin:1:numIRSMax
    if numIRS>0
        Ni=Nibudget/numIRS; %must be divisible evenly
    else
        Ni=1;
    end

    if mod(sqrt(Ni), 1) == 0 %square IRS
        Na=sqrt(Ni);
        Nb=sqrt(Ni);
    else
        factorsd = divisors(Ni);
        % If even number of factors, pick the two middle ones
        Na = factorsd(length(factorsd)/2);
        Nb = factorsd(length(factorsd)/2 + 1); %bias number of rows (IRS height)
    end

    fprintf('Currently on trial %d', numIRS);
    fprintf('\n');

    [SOA_mean, SOA_std, Cap_u_mean, Cap_u_std] =
    change_none(numIRS,numAP,percentEve,samples,minDistanceSTA,distanceBorder,minDistanceAP,minDistanceIRS,lambda,Sx,Sy,Li,W,N0,P0,d0,pjmax,ptmax,alpha);
end
%}

plot_statistics(ixMin,ixMax,SOA_mean,SOA_std,Cap_u_mean,Cap_u_std,samples);
%%
%channels and mapper functions

%manual initialization of test environment (overwrite)
%scCustomSimple
%{
numAP=2;
numIRS=3;
alpha=1;

[d_m_u, d_m_k, d_m_exy, d_mn_u ,d_mn_k ,d_mn_exy ,d_k_u ,d_k_exy, angleIncidence]=quickCompute_d(APxy,STAxy,eveArea,IRSxy,orientationIRS,Na,Nb,Li);
    
transmitAP=APselect_noIRS(d_k_u,d_k_exy,lambda,alpha,N0,W,ptmax,pjmax);

phiAligned = optimise_IRS_Align(d_m_u, d_m_k, d_m_exy, d_mn_u ,d_mn_k ,d_mn_exy ,d_k_u ,d_k_exy, angleIncidence,lambda,Na,Nb,Li,W,N0,pjmax,ptmax,transmitAP,alpha);

p_k=FJpower(d_m_u, d_m_k, d_m_exy, d_mn_u ,d_mn_k ,d_mn_exy ,d_k_u ,d_k_exy, ...
    angleIncidence,phiAligned,ptmax,transmitAP, Li,lambda,W,alpha,N0,pjmax);

APs=APxy(transmitAP,:);

%mapping
hLOS_single=simulate_LOS_single(APs,STAxy,lambda,d0,P0,ptmax);
[hIRS] = simulate_IRS_single(phiAligned,APs,STAxy,IRSxy,orientationIRS,lambda,P0,d0,Na,Nb,Li,ptmax);

%calculate combined channel responses
hLOSIRS_s=hLOS_single+hIRS;
pLOSIRS_s=abs(hLOSIRS_s).^2;

%generate map
[hLOS] = simulate_LOS_map(dx,dy,Nx,Ny,APs,lambda,P0,d0,ptmax);
[hIRS,hIRSIndv,pIRS,pIRSIndv] = simulate_IRS_map(phiAligned,dx,dy,Nx,Ny,APs,IRSxy,orientationIRS,lambda,P0,d0,Na,Nb,Li,ptmax);

hLOSIRS=hLOS+hIRS;
pLOSIRS=abs(hLOSIRS).^2;

%%
%compute noise and interference channels

pLOSIRSj=zeros(Nx,Ny);

for k=1:numAP
    if k~=transmitAP
        pj=p_k(k);
        [hLOSj] = simulate_LOS_map(dx,dy,Nx,Ny,APxy(k,:),lambda,P0,d0,pj);
        [hIRSj,hIRSIndvj] = simulate_IRS_map(phiAligned,dx,dy,Nx,Ny,APxy(k,:),IRSxy,orientationIRS,lambda,P0,d0,Na,Nb,Li,pj);
        hLOSIRSj=hLOSj+hIRSj;
        pLOSIRSj=pLOSIRSj+pj.*abs(hLOSIRSj).^2;
    end
end

SINRmap=(pLOSIRS./(W.*repmat(N0,Nx,Ny)+pLOSIRSj));

Cap_u= calculate_user_cap(APxy, STAxy,IRSxy,orientationIRS,transmitAP, lambda,W, N0,ptmax,p_k,d0,P0,Na,Nb,Li,phiAligned);
eveCap=calculate_eaves_cap(APxy, IRSxy,orientationIRS,transmitAP, eveArea, eveDiscrete, lambda,W, N0,ptmax,p_k,d0,P0,Na,Nb,Li,phiAligned);

sCAP=repmat(Cap_u,size(eveCap,1),size(eveCap,2))-eveCap;
%sCAPn=sum(sCAP,"all")/numel(sCAP);

%calculate the SOA as percentage
SOA = 100*sum(sCAP>(1/2*Cap_u),"all")/numel(sCAP);
%}
%%
%optimisation single objective
%{
% Create optimization variables
transmitAPop = optimvar("transmitAPop", 1, "Type", "integer", "LowerBound", 1, "UpperBound", 3);
phiAlignedop = optimvar("phiAlignedop", 10, 10, 3, "LowerBound", -1*pi, "UpperBound", pi);
p_jop = optimvar("p_jop", numAP - 1, "LowerBound", 0, "UpperBound", pjmax);

% Create problem
problem = optimproblem("ObjectiveSense", "min");

% Define problem objective
problem.Objective = fcn2optimexpr(@multiple_objective_function, transmitAPop, phiAlignedop, p_jop);

% Set initial starting point for the solver
initialPoint.transmitAPop = 1;  % Must be within bounds
initialPoint.phiAlignedop = zeros(size(phiAlignedop));
initialPoint.p_jop = zeros(size(p_jop));
disp('Input sizes:');
disp(size(transmitAPop));
disp(size(phiAlignedop));
disp(size(p_jop));
% Solve the problem
[solution, fval] = solve(problem, initialPoint);


disp('Optimal solution:');
disp(solution);
disp('Function value at optimal solution:');
disp(fval);
%}
%%
%graph and plots
%{
xlabpos=ones(numAP+numIRS+1,1);
ylabpos=ones(numAP+numIRS+1,1);
labels=cell(numAP+numIRS+1,1);

for k=1:numAP
    xlabpos(k)=APxy(k,1);
    ylabpos(k)=APxy(k,2);
    labels{k}=sprintf('AP_%d', k);
end

for m=1:numIRS
    xlabpos(numAP+m)=IRSxy(m,1);
    ylabpos(numAP+m)=IRSxy(m,2);
    labels{numAP+m}=sprintf('IRS_%d', m);
end
    xlabpos = xlabpos-1.25*Sx/20;
    ylabpos = ylabpos-1.25*Sy/20;

STAx=STAxy(1);
STAy=STAxy(2);

xlabpos(end)=STAx-1.25*Sy/20;
ylabpos(end)=STAy-1.25*Sy/20;
labels{end}='User';

IRSx=IRSxy(:,1);
IRSy=IRSxy(:,2);

APx=APxy(:,1);
APy=APxy(:,2);

textFontMinor=8;

figure(1)%SINR
imagesc(xa, ya, 10.*log10(SINRmap).');
a=colorbar();
colormap(turbo);
axis equal tight;
set(gca,'FontSize',12,'LineWidth',2);
set(gca,'ColorScale','lin');
set(gca,'YDir','normal')
a.Label.String = 'SINR (dB)';
xlabel('x position (m)')
ylabel('y position (m)')
hold on;
%plot((APx),(APy), 'p', 'LineWidth', 2, 'Color', 'w', 'MarkerSize', 2,'MarkerFaceColor','k');
plot((IRSx),(IRSy), 'p', 'LineWidth', 2, 'Color', 'w', 'MarkerSize', 3,'MarkerFaceColor','k');
%plot((APx2*dx)-1,(APy2*dy)-1, 'p', 'LineWidth', 2, 'Color', 'w', 'MarkerSize', 10,'MarkerFaceColor','k')
%plot((STAx),(STAy), 'p', 'LineWidth', 2, 'Color', 'w', 'MarkerSize', 1,'MarkerFaceColor','k');

t = text(xlabpos,ylabpos,labels,'HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
te = text((eveArea(1,2)+eveArea(1,1))/2-(Sx/10),(eveArea(2,2)+eveArea(2,1))/2,'Eaves','HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
for ti=1:size(xlabpos)
    t(ti).FontSize = textFontMinor;
    t(ti).Color = 'White';
end

te.FontSize=20;
te.Color = 'White';
scatter(APxy(:,1),APxy(:,2),105,'k','^',"filled");
scatter(STAxy(1),STAxy(2),90,'b',"o","filled");
%mark unprotected zone
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,1) eveArea(2,1)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,2) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,1)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,2) eveArea(1,2)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
axis square
box on;
xlim([0 Sx]);
ylim([0 Sy]);
%legend(["Access points" "User STAxy"],'fontsize', 10)
hold off;

figure(2);
colormap(turbo);
for i =1:numIRS
    pToPlot=pIRSIndv(:,:,i);
    %handles maximum 6 irs
    if numIRS==1
        imagesc(1:Na, 1:Nb, -10.*log10(pToPlot.'));
    elseif numIRS==2
        subplot(1,2,i)
    elseif numIRS==3
        subplot(2,2,i)
    elseif numIRS==4
        subplot(2,2,i)
    elseif numIRS==5
        subplot(2,3,i)
    elseif numIRS==6
        subnplot(2,3,i)
    else
        error("Too many IRS to plot maps");
    end
imagesc(xa, ya, -10.*log10(pToPlot.'));
a=colorbar();
axis equal tight;
set(gca,'FontSize',12,'LineWidth',2);
box on;
xlim([0 Sx]);
ylim([0 Sy]);
set(gca,'ColorScale','lin');
set(gca,'YDir','normal')
a.Label.String = 'Pathloss (dB)';
xlabel('x position (m)')
ylabel('y position (m)')
hold on;

%plot((APx),(APy), 'p', 'LineWidth', 2, 'Color', 'w', 'MarkerSize', 2,'MarkerFaceColor','k');
plot((IRSx),(IRSy), 'p', 'LineWidth', 2, 'Color', 'w', 'MarkerSize', 3,'MarkerFaceColor','k');
scatter(APxy(:,1),APxy(:,2),105,'k','^',"filled");
scatter(STAxy(1),STAxy(2),90,'b',"*","filled");
%plot((STAx),(STAy), 'p', 'LineWidth', 2, 'Color', 'w', 'MarkerSize', 1,'MarkerFaceColor','k');

%labels (with normalized ratio to the 20x20 scenario)

t = text(xlabpos,ylabpos,labels,'HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');

for ti=1:size(xlabpos)
    t(ti).FontSize = textFontMinor;
    t(ti).Color = 'White';
end

hold off;
title("IRS " + num2str(i));
end
sgtitle('Individual IRS patterns');

figure(3);
colormap(turbo);
imagesc(xa, ya, -10.*log10(pLOSIRS).');
a=colorbar();
axis equal tight;
set(gca,'FontSize',12,'LineWidth',2);
set(gca,'ColorScale','lin');
set(gca,'YDir','normal')
a.Label.String = 'Pathloss Transmit (dB)';
xlabel('x position (m)')
ylabel('y position (m)')
hold on;
%plot((APx),(APy), 'p', 'LineWidth', 2, 'Color', 'w', 'MarkerSize', 2,'MarkerFaceColor','k');
plot((IRSx),(IRSy), 'p', 'LineWidth', 2, 'Color', 'w', 'MarkerSize', 3,'MarkerFaceColor','k');
%plot((STAx),(STAy), 'p', 'LineWidth', 2, 'Color', 'w', 'MarkerSize', 1,'MarkerFaceColor','k');
%labels (with normalized ratio to the 20x20 scenario)

t = text(xlabpos,ylabpos,labels,'HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
te = text((eveArea(1,2)+eveArea(1,1))/2-(Sx/10),(eveArea(2,2)+eveArea(2,1))/2,'Eaves','HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
for ti=1:size(xlabpos)
    t(ti).FontSize = textFontMinor;
    t(ti).Color = 'White';
end

te.FontSize=20;
te.Color = 'White';
scatter(APxy(:,1),APxy(:,2),105,'k','^',"filled");
scatter(STAxy(:,1),STAxy(:,2),90,'b',"o","filled");
%mark unprotected zone
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,1) eveArea(2,1)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,2) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,1)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,2) eveArea(1,2)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
axis square
%legend(["Access points" "User STAxy"],'fontsize', 10)
box on;
xlim([0 Sx]);
ylim([0 Sy]);
hold off;

figure(4);
imagesc(xa, ya, -10.*log10(pLOSIRSj).');
a=colorbar();
colormap(turbo);
axis equal tight;
set(gca,'FontSize',12,'LineWidth',2);
set(gca,'ColorScale','lin');
set(gca,'YDir','normal')
a.Label.String = 'Pathloss Jammer (dB)';
xlabel('x position (m)')
ylabel('y position (m)')
hold on;
%plot((APx),(APy), 'p', 'LineWidth', 2, 'Color', 'w', 'MarkerSize', 2,'MarkerFaceColor','k');
plot((IRSx),(IRSy), 'p', 'LineWidth', 2, 'Color', 'w', 'MarkerSize', 3,'MarkerFaceColor','k');
%plot((STAx),(STAy), 'p', 'LineWidth', 2, 'Color', 'w', 'MarkerSize', 1,'MarkerFaceColor','k');
%labels (with normalized ratio to the 20x20 scenario)

t = text(xlabpos,ylabpos,labels,'HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
te = text((eveArea(1,2)+eveArea(1,1))/2-(Sx/10),(eveArea(2,2)+eveArea(2,1))/2,'Eaves','HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
for ti=1:size(xlabpos)
    t(ti).FontSize = textFontMinor;
    t(ti).Color = 'White';
end

te.FontSize=20;
te.Color = 'White';
scatter(APxy(:,1),APxy(:,2),105,'k','^',"filled");
scatter(STAxy(:,1),STAxy(:,2),90,'b',"o","filled");
%mark unprotected zone
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,1) eveArea(2,1)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,2) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,1)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,2) eveArea(1,2)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
axis square
%legend(["Access points" "User STAxy"],'fontsize', 10)
box on;
xlim([0 Sx]);
ylim([0 Sy]);
hold off;



figure(5)
scatter(APxy(:,1),APxy(:,2),105,'k','^',"filled");
hold all;
scatter(STAxy(:,1),STAxy(:,2),90,'b',"o","filled");
scatter(IRSx,IRSy,130,'m','+','LineWidth', 5);

%mark unprotected zone
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,1) eveArea(2,1)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,2) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,1)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,2) eveArea(1,2)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
te = text((eveArea(1,2)+eveArea(1,1))/2-(Sx/10),(eveArea(2,2)+eveArea(2,1))/2,'Eaves','HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
te.FontSize=20;
te.Color='Red';
axis square
legend(["Access points" "User STAxy" "IRS"],'fontsize', 14)
box on;
xlim([0 Sx]);
ylim([0 Sy]);
title('Scenario')



figure(6)

for i =1:numIRS

    %handles maximum 6 irs
    if numIRS==1
        imagesc(1:Na, 1:Nb, phiAligned(:,:,i)./(2*pi));
    elseif numIRS==2
        subplot(1,2,i)
    elseif numIRS==3
        subplot(2,2,i)
    elseif numIRS==4
        subplot(2,2,i)
    elseif numIRS==5
        subplot(2,3,i)
    elseif numIRS==6
        subnplot(2,3,i)
    else
        error("Too many IRS to plot phases");
    end
    hold on;
    imagesc(1:Na, 1:Nb, phiAligned(:,:,i)./(2*pi));
    colormap(gray);
    axis equal tight;
    set(gca,'FontSize',6,'LineWidth',2);
    set(gca,'ColorScale','lin');
    set(gca,'YDir','normal')
    
    xlabel('Element columns')
    ylabel('Element rows')
    a=colorbar();
    a.Label.String = 'Phase shifts (\times 2\pi)';
    
    hold off;

    title("IRS " + num2str(i));
end
sgtitle('IRS elements with aligned phases');

close(6);
close(5);
close(2);
%}

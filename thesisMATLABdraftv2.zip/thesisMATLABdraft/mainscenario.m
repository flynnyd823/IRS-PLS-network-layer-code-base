close all;
Tf=100;

env.f0 = 2.4e9;
env.c = 3e8;
env.Pi_max = 1;
env.N = 3.16e-12; % -85 dBmnoise
env.W = 1;
env.max_x = 50;
env.max_y = 50;
sc1;
APxy=APxy*4+0;
STA=STA*4+0;
APxy(:,2)=APxy(:,2)+40;
STA(:,2)=STA(:,2)+40;
%eav=eav*4;


figure(1);
%scale by factor of 4
scatter(APxy(:,1),APxy(:,2),105,'k','^',"filled");
hold all;
scatter(STA(:,1),STA(:,2),90,'b',"o","filled");
%scatter(eav(:,1),eav(:,2),90,[0.6350 0.0780 0.1840],"diamond","filled");

%mark unprotected zone
%plot(60,140,'p');
line([0 200],[60 60]);
%line([60 60],[140 200]);

axis square
legend(["Access points" "User STA"],'fontsize', 14)
box on;
xlim([0 200]);
ylim([0 200]);
env.num_users = size(STA,1);
env.num_eavs = size(eav,1);
env.num_AP = size(APxy,1);
%wifiAP = APselectorWiFi(APxy,eav,STA,env);
%smartAP = APselectorSmart(APxy,eav,STA,env);
%averageAP = APselecterSINR(APxy,eav,STA,envArea);
function [hIRS,hIRSIndv,pIRS,pIRSIndv] = simulate_IRS_map(phi,dx,dy,Nx,Ny,APxy,IRSxy,orientationIRS,lambda,P0,d0,Na,Nb,Li,Pt)

%Simulate the channel conditions introduced by multiple square IRS from a single source to a square map. 
%
%Inputs:
%IRS phase elements (√NI x √NI x numIRS), x resolution, y resolution, grid x, grid y, 
%AP location (1 x 2) [m], IRS locations (numIRS x 2) [m], IRS orientations (numIRS x 1), 
%carrier wavelength [m], number of elements per IRS, size width of element
%on IRS [m], transmit power [watts]
%
%Outputs:
%Channel coefficient for combined IRS [complex], channel coefficients from each IRS (numIRS x 1) [complex], 
%received power [Watts], each power contribution (numIRS x 1) [Watts].

APx=APxy(1);
APy=APxy(2);

IRSx=IRSxy(:,1);
IRSy=IRSxy(:,2);

numIRS = size(IRSxy,1);

hIRSIndv=ones(Nx,Ny,numIRS);
pIRSIndv=ones(Nx,Ny,numIRS);

phi=exp(phi*1i);

%AP to IRS elements distance (distance1)
distance1=ones(Nb,Na,numIRS);

%IRS elements to pos distance (distance2)
distance2=ones(Nx,Ny,Nb,Na,numIRS);

%path loss of IRS
beta=zeros(Nx,Ny,numIRS);
dist2=ones(Nx,Ny);

for ixIRS=1:numIRS

    dist1=sqrt(((IRSx(ixIRS)-APx)).^2+(IRSy(ixIRS)-APy).^2);

    %horizontal IRS
    if orientationIRS(ixIRS)=="horizontal"


        for column = 1:Na
            for row = 1:Nb
                distance1(row,column,ixIRS) = sqrt((IRSx(ixIRS)-(Na/2-column)*Li-APx).^2+(IRSy(ixIRS)-APy).^2+(-(Nb/2-row)*Li).^2);
            end
        end
    
        for column = 1:Na
            for row = 1:Nb
                for x = 1:Nx
                    for y = ylim1:ylim2
                        distance2(x,y,row,column,ixIRS) = sqrt((IRSx(ixIRS)-(Na/2-column)*Li-x*dx).^2+(IRSy(ixIRS)-y*dy).^2+(-(Nb/2-row)*Li).^2);
                        dist2(x,y)=sqrt(((IRSx(ixIRS)-x*dx)).^2+(IRSy(ixIRS)-y*dy).^2);
                    end
                end
            end
        end

        %compensate for angular response of IRS
        angleIncidence = atand(abs(APx-IRSx(ixIRS))/abs(APy-IRSy(ixIRS)));
        beta(:,:,ixIRS)=(P0/lambda^2).*((Li^2*d0)./(dist1.*dist2(:,:))).^2.*cos(angleIncidence)^2;
    

    elseif orientationIRS(ixIRS)=="vertical"

        for column = 1:Na
            for row = 1:Nb
                distance1(row,column,ixIRS) = sqrt(((IRSx(ixIRS)-APx)).^2+(IRSy(ixIRS)-(Na/2-column)*Li-APy).^2+(-(Nb/2-row)*Li).^2);
            end
        end

        for column = 1:Na
            for row = 1:Nb
                for x = xlim1:xlim2
                    for y = 1:Ny
                        distance2(x,y,row,column,ixIRS) = sqrt((IRSx(ixIRS)-x*dx).^2+(IRSy(ixIRS)-(Na/2-column)*Li-y*dy).^2+(-(Nb/2-row)*Li).^2);
                        dist2(x,y)=sqrt(((IRSx(ixIRS)-x*dx)).^2+(IRSy(ixIRS)-y*dy).^2);
                    end
                end
            end
        end

        %compensate for angular response of IRS (independent of final
        %location
        angleIncidence = atand(abs(APy-IRSy(ixIRS))/abs(APx-IRSx(ixIRS)));
        beta(:,:,ixIRS)=(P0/lambda^2).*((Li^2*d0)./(dist1.*dist2(:,:))).^2.*cos(angleIncidence)^2;

    else
        error("Incorrect entered IRS orientation")
    end
end

%IRS phase shifts
pd1=(2*pi/lambda).*distance1;
pd2=(2*pi/lambda).*distance2;
%generate rician channels AP to IRS elements
%[~, h1] = simulate_channels(kfactor, Ni);

%generate rician channels from IRS elements to each position (below IRSy)
%{
h2=zeros(Nx,Ny,Ni);
for ni = 1:Ni
    for y = 1:IRSy
        %generate x columns
        [~, h_rician] = simulate_channels(kfactor, Nx);
        h2(:,y,ni) = h_rician;
    end
end
%}

%generate IRS channels
h1IRS=exp(pd1*1i);
h2IRS=exp(pd2*1i);

%determine the total channel by identify each contribution from elements
hTEMP=ones(Nx,Ny,Nb,Na,ixIRS);

for ixIRS=1:numIRS
    for column=1:Na
        for row=1:Nb
            hTEMP(:,:,column,row,ixIRS) = h2IRS(:,:,column,row,ixIRS).*phi(column,row,ixIRS).*h1IRS(column,row,ixIRS);
        end
    end

    %sum the contributions of each element
    hTEMP2=sum(sum(hTEMP,3),4);
    hIRSIndv(:,:,ixIRS) = sqrt(beta(:,:,ixIRS)).*hTEMP2(:,:,1,1,ixIRS);
    pIRSIndv(:,:,ixIRS) = (Pt).*abs(hIRSIndv(:,:,ixIRS)).^2;
end

hIRS=sum(hIRSIndv,3);
pIRS=(Pt).*abs(hIRS).^2;

end
function [hIRS,hIRSIndv,pIRS,pIRSIndv] = simulate_IRS_single(phi,APxy,STAxy,IRSxy,orientationIRS,lambda,P0,d0,Na,Nb,Li,Pt)

%Simulate the channel conditions introduced by multiple square IRS from a single source to single destination. 
%
%Inputs:
%IRS phase elements (√NI x √NI x numIRS), AP locations (1 x 2) [m], User location (1 x 2) [m], IRS
%locations (numIRS x 2) [m], IRS orientations (numIRS x 1), carrier wavelength [m], reference power [watts], 
%reference distance [m], number of elements per IRS, %size width of element
%on IRS [m], transmit power [watts].
%
%Outputs:
%Channel coefficient for combined IRS [complex], channel coefficients from each IRS (numIRS x 1) [complex], 
%received power [Watts], each power contribution (numIRS x 1) [Watts].
%
%Credit: (2019) Intelligent Reflecting Surfaces: Physics, Propagation, and
%Pathloss Modeling (Emil Bjornson)

APx=APxy(1);
APy=APxy(2);

STAx=STAxy(1);
STAy=STAxy(2);

IRSx=IRSxy(:,1);
IRSy=IRSxy(:,2);

numIRS = size(IRSx,1);

hIRSIndv=ones(numIRS,1);
pIRSIndv=ones(numIRS,1);


%for converting the phase shift to polar
phi=exp(phi.*1i);

%AP to IRS elements distance (distance1)
distance1=ones(Nb,Na,numIRS);

%IRS elements to pos distance (distance2)
distance2=ones(Nb,Na,numIRS);

%path loss of IRS
beta=zeros(numIRS,1);

for ixIRS=1:numIRS
    dist1=sqrt(((IRSx(ixIRS)-APx)).^2+(IRSy(ixIRS)-APy).^2);
    dist2=sqrt(((IRSx(ixIRS)-STAx)).^2+(IRSy(ixIRS)-STAy).^2);

    %horizontal
    if orientationIRS(ixIRS)=="horizontal"
        for column = 1:Na
            for row = 1:Nb
                distance1(row,column,ixIRS) = sqrt((IRSx(ixIRS)-(Na/2-column)*Li-APx).^2+(IRSy(ixIRS)-APy).^2+(-(Nb/2-row)*Li).^2);
                distance2(row,column,ixIRS) = sqrt(((IRSx(ixIRS)-(Na/2-column)*Li-STAx)).^2+(IRSy(ixIRS)-STAy).^2+(-(Nb/2-row)*Li).^2);
            end
        end
        
        angleIncidence = atand(abs(APx-IRSx(ixIRS))/abs(APy-IRSy(ixIRS)));
        beta(ixIRS)=(P0/lambda^2).*((Li^2*d0)./(dist1.*dist2)).^2.*cos(angleIncidence)^2;
    
    %vertical
    elseif orientationIRS(ixIRS)=="vertical"
        for column = 1:Na
            for row = 1:Nb
                 distance1(row,column,ixIRS) = sqrt(((IRSx(ixIRS)-APx)).^2+(IRSy(ixIRS)-(Na/2-column)*Li-APy).^2+(-(Nb/2-row)*Li).^2);
                 distance2(row,column,ixIRS) = sqrt(((IRSx(ixIRS)-STAx)).^2+((IRSy(ixIRS)-(Na/2-column)*Li-STAy)).^2+(-(Nb/2-row)*Li).^2);
            end
        end
        %compensate for angular response of IRS
        angleIncidence = atand(abs(APy-IRSy(ixIRS))/abs(APx-IRSx(ixIRS)));
        beta(ixIRS)=(P0/lambda^2).*((Li^2*d0)./(dist1.*dist2)).^2.*cos(angleIncidence)^2;
    else
        error("Incorrect entered IRS orientation")
    end
end

%IRS phase shifts
pd1=(2*pi/lambda)*distance1;
pd2=(2*pi/lambda)*distance2;

%generate rician channels from IRS elements to each position (below IRSy)
%{
h2=zeros(Nx,Ny,Ni);
for ni = 1:Ni
    for y = 1:IRSy
        %generate x columns
        [~, h_rician] = simulate_channels(kfactor, Nx);
        h2(:,y,ni) = h_rician;
    end
end
%}

%generate IRS channels

h1IRS2=exp((pd1+pd2)*1i);

%determine the total channel by identify each contribution from elements

hTEMP=ones(Nb,Na,ixIRS);

for ixIRS=1:numIRS
    for column=1:Na
        for row=1:Nb
            hTEMP(column,row,ixIRS) = phi(column,row,ixIRS).*h1IRS2(column,row,ixIRS);
        end
    end

    %sum the effects of columns and rows
    hTEMP2=sum(sum(hTEMP,1),2);
    hIRSIndv(ixIRS) = sqrt(beta(ixIRS))*hTEMP2(1,1,ixIRS);
    pIRSIndv(ixIRS) = Pt.*abs(hIRSIndv(ixIRS)).^2;
end

hIRS=sum(hIRSIndv);
pIRS=Pt.*abs(hIRS).^2;

end
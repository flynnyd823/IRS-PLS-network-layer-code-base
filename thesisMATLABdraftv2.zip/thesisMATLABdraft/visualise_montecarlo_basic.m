%test scenario
numAP=3;
numIRS=0;
close all;
[eveArea, STAxy, APxy, IRSxy,orientationIRS] = monte_carlo_scen(Sx,Sy,percentEve,numAP,numIRS, minDistanceSTA,distanceBorder,minDistanceAP,minDistanceIRS);

figure(5)
scatter(APxy(:,1),APxy(:,2),105,'k','^',"filled");
hold all;
scatter(STAxy(:,1),STAxy(:,2),90,'b',"o","filled");
scatter(IRSxy(:,1),IRSxy(:,2),130,'m','+','LineWidth', 5);

%mark unprotected zone
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,1) eveArea(2,1)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,2) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,1)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,2) eveArea(1,2)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
te = text((eveArea(1,2)+eveArea(1,1))/2-(Sx/10),(eveArea(2,2)+eveArea(2,1))/2,'Eaves','HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
te.FontSize=20;
te.Color='Red';
axis square
legend(["Access points" "User" "IRS"],'fontsize', 14)
box on;
xlim([0 Sx]);
ylim([0 Sy]);

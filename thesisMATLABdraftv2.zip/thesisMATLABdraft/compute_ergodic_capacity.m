% Function to compute ergodic capacities for Rayleigh and Rician channels
function [C_rayleigh_erg, C_rician_erg, C_rician_erg_std] = compute_ergodic_capacity(SNR, h_rayleigh, h_rician)
    C_rayleigh_erg = zeros(size(SNR));
    C_rician_erg = zeros(size(SNR));
    % Loop through SNR values to compute ergodic capacity
    for i = 1:length(SNR)
        C_rayleigh_erg(i) = mean(log2(1 + SNR(i) * abs(h_rayleigh).^2));
        C_rician_erg(i) = mean(log2(1 + SNR(i) * abs(h_rician).^2));
        C_rician_erg_std(i) = std(log2(1 + SNR(i) * abs(h_rician).^2));
    end
end
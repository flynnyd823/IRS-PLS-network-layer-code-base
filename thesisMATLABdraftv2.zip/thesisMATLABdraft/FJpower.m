function [p_k] = FJpower(d_m_u, d_m_k, d_m_exy, d_mn_u ,d_mn_k ,d_mn_exy ,d_k_u ,d_k_exy, angleIncidence,phiAligned,ptmax,transmitAP, Li,lambda,W,alpha,N0,pjmax)

%Derive the friendly jamming powers numerically.

%inputs: transmit power of active AP (Watt), index transmitAP of active transmitter,
%user location, AP positions, IRS positions, IRS phases, number element, element size, wavelength, bandwidth,
%eavesdropper area, maximum jammer power.
%
%outputs: friendly jamming power for all AP (excluding transmitter=pt)

K=size(d_m_k,2);
M=size(d_m_k,1);

X=size(d_k_exy,2);
Y=size(d_k_exy,3);

p_k=zeros(size(d_m_k,2),1); %all powers must initially be zero

phi_k_u=(2*pi/lambda)*d_k_u;
phi_k_exy=(2*pi/lambda).*d_k_exy;

if K>1 %there are jammers present
    
    %generate a terms
    a_k_u = lambda.*(exp(1i.*(phi_k_u)))./d_k_u; %k
    a_k_exy=lambda.*(exp(1i.*(phi_k_exy)))./d_k_exy; %k, X,Y
    
    %generated according phase differences
    phi_mn_k=(2*pi/lambda).*d_mn_k;
    phi_mn_u=(2*pi/lambda).*d_mn_u;
    phi_mn_exy=(2*pi/lambda).*d_mn_exy;
    
    if M>0
        if M>1
            tempu=squeeze(sum(sum(exp(1i*(phi_mn_k+repmat(phi_mn_u,[1,1,1,K])+repmat(phiAligned,[1,1,1,K]))),1),2)); %Nb Na M K
            tempe=squeeze(sum(sum(exp(1i*(permute(repmat(phi_mn_k,[1 1 1 1 X Y]),[1 2 3 5 6 4])+repmat(phi_mn_exy,[1,1,1,1,1,K])+repmat(phiAligned,[1,1,1,X,Y,K]))),1),2)); %Nb Na M X Y K
        else
            tempu=permute(squeeze(sum(sum(exp(1i*(phi_mn_k+repmat(phi_mn_u,[1,1,1,K])+repmat(phiAligned,[1,1,1,K]))),1),2)),[2 1]); %Nb Na M K
            tempe=permute(squeeze(sum(sum(exp(1i*(permute(repmat(phi_mn_k,[1 1 1 1 X Y]),[1 2 3 5 6 4])+repmat(phi_mn_exy,[1,1,1,1,1,K])+repmat(phiAligned,[1,1,1,X,Y,K]))),1),2)),[4,1,2,3]); %Nb Na M K X Y
        end
        
        %sum each IRS contribution
        b_k_u= squeeze(sum(Li^2.*(cos(angleIncidence./(d_m_k.*repmat(d_m_u,[1,K])))).*tempu,1)); %k
        b_k_exy=squeeze(sum(Li^2.*(cos(permute(repmat(angleIncidence,[1 1 X Y]),[1 3 4 2])./permute(repmat(d_m_k,[1 1 X Y]),[1 3 4 2]).*repmat(d_m_exy,[1,1,1,K]))).*tempe,1)); %x,y,k
    
    else%no IRS
        b_k_u=zeros(1,K);
        b_k_exy=zeros(X,Y,K);
    end

    A_k_u=abs(a_k_u+permute(b_k_u,[2 1])).^2; %k
    A_k_exy=abs(permute(a_k_exy,[2 3 1])+b_k_exy).^2; %x,y,k
    A_k_exy=permute(A_k_exy,[3 1 2]);%k,x,y
    
    %normalized noise term
    Npiu=4*pi*W*N0;
    Npi=repmat(4*pi*W*N0,[1,X,Y]);
    
    %create priority index
    Pri_k=ones(K,1);
    
    for k =1:K
        Pri_k(k)=A_k_u(k)+sum(sum(A_k_exy(k,:,:),2),3)./(X*Y);
    end
    
    [~,pri]=sort(Pri_k,'ascend');
    
    %remove the transmitter index
    fjpri = pri(setdiff(1:K, transmitAP));
    
    A_t_u=A_k_u(transmitAP); 
    A_t_exy=A_k_exy(transmitAP,:,:);
    
    for si=1:K-1
        s = fjpri(si); %take the priority
        
        %remove selected AP from B calculation
        A_k_u_s=A_k_u(setdiff(1:K, s));
        A_k_exy_s=A_k_exy(setdiff(1:K, s), :, :); 
        p_k_s=p_k(setdiff(1:K, s));
    
        %other AP
        B_s_u=sum(p_k_s.*A_k_u_s); %powers included 
        B_s_exy=sum(repmat(p_k_s,[1,X,Y]).*A_k_exy_s,1); %powers included %1,x,y
        
        %isolate the selected AP
        A_s_u=A_k_u(s);
        A_s_exy=A_k_exy(s,:,:);
    
        C_s_u=A_t_u.*A_s_u;
        C_s_exy=A_t_exy.*A_s_exy;
        
        D_s_u=2*(A_s_u.*B_s_u+A_s_u.*Npiu)+ptmax.*A_t_u.*A_s_u;
        D_s_exy=2.*(A_s_exy.*B_s_exy+A_s_exy.*Npi)+ptmax.*A_t_exy.*A_s_exy;
        
        E_s_u=(B_s_u+Npiu).^2+Npiu.*B_s_u+ptmax.*A_t_u.*(Npiu+B_s_u);
        E_s_exy=(B_s_exy+Npi).^2+Npi.*B_s_exy+ptmax.*A_t_exy.*(Npi+B_s_exy);
        
        F=squeeze(sum(sum(((repmat(A_s_u,[1 X Y])).^2).*C_s_exy-alpha.*((A_s_exy.^2).*repmat(C_s_u,[1 X Y])),2),3));
        G=squeeze(sum(sum(C_s_exy.*repmat(D_s_u,[1 X Y])-alpha.*repmat(C_s_u,[1 X Y]).*D_s_exy,2),3));
        H=squeeze(sum(sum(C_s_exy.*repmat(E_s_u,[1 X Y])-alpha.*repmat(C_s_u,[1 X Y]).*E_s_exy,2),3));
       
        r=roots([F G H]);
        
        if size(r)==1
            rConstraint1 = max(min(real(r(1)),pjmax),0);
            rsols = unique([0 pjmax rConstraint1],'stable');
        else
            rConstraint1 = max(min(real(r(1)),pjmax),0);
            rConstraint2 = max(min(real(r(2)),pjmax),0);
            rsols = unique([0 pjmax rConstraint1 rConstraint2],'stable');
        end
    
        obj = zeros(size(rsols,2),1);
    
        for p = 1:size(rsols,2)
            SINRu=repmat((ptmax.*A_t_u)./(Npiu+B_s_u+rsols(p).*A_s_u),[1,X,Y]); %1 x y
            SINRexy=(ptmax.*A_t_exy)./(Npi+B_s_exy+rsols(p).*A_s_exy); %1 x y
            obj(p)=squeeze(sum(sum(log2(((ones(1,X,Y)+SINRu)./((ones(1,X,Y)+SINRexy).^(alpha)))),2),3)); %m,k
            
        end
        
        [~, ind]=max(obj);
        
        p_k(s)= rsols(ind);
    end


end
    
    p_k(transmitAP)=ptmax; %set initial transmitting power

end



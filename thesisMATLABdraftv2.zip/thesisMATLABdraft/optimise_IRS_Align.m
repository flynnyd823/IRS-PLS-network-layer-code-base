function phiAligned = optimise_IRS_Align(d_m_u, d_m_k, d_m_exy, d_mn_u ,d_mn_k ,d_mn_exy ,d_k_u ,d_k_exy, angleIncidence,lambda,Na,Nb,Li,W,N0,pjmax,ptmax,transmitAP,alpha)

%Optimise the phase shifts for multiple square IRS using the phase align technique. 
% 
%Inputs: 

% 
%Outputs:
%Aligned element phases (√NI x √NI x numIRS) [rads].


K=size(d_m_k,2);
M=size(d_m_k,1);

X=size(d_k_exy,2);
Y=size(d_k_exy,3);

if M>0

    Npi=4*pi*W*N0;

    phiAligned=ones(Nb,Na,M);
    
    %distance from irs elements to centre of eavesdropper position (row, col,
    %m, xc, yc)
    xc=floor(size(d_mn_exy,4)/2);
    yc=floor(size(d_mn_exy,5)/2);
    d_mn_exyc=d_mn_exy(:,:,:,xc,yc);
    d_k_exyc=d_k_exy(:,xc,yc);
    
    %calculate the phases
    
    coeff=(2*pi/lambda);
    phi_k_u=coeff*d_k_u;
    phi_k_exy=coeff.*d_k_exy;
    phi_k_exyc=coeff.*d_k_exyc;
    
    phi_mn_k=coeff.*d_mn_k;
    phi_mn_u=coeff.*d_mn_u;
    phi_mn_exy=coeff.*d_mn_exy;
    phi_mn_exyc=coeff.*d_mn_exyc;
    
    phiAlignedK=zeros(Nb,Na,M,K);
    
    for m=1:M %isolate IRS
        for k=1:K
            if k==transmitAP
                %align to user
                phiAlignedK(:,:,m,k) = repmat(phi_k_u(k),[Nb,Na])-(phi_mn_u(:,:,m)+phi_mn_k(:,:,m,k));
            else
                %align to centre of eavesdropper area
                phiAlignedK(:,:,m,k) = repmat(phi_k_exyc(k),[Nb,Na])-(phi_mn_exyc(:,:,m)+phi_mn_k(:,:,m,k));
            end
        end
    end
    
    phiAlignedK = mod(phiAlignedK,2*pi); %in rads
    
    a_k_u = lambda.*(exp(1i.*(phi_k_u)))./d_k_u; %K,1
    a_k_exy=lambda.*(exp(1i.*(phi_k_exy)))./d_k_exy; %K,x,y
        
    rd_m_k=permute(repmat(d_m_k,[1,1,X,Y]),[1,3,4,2]);
    rphi_mn_k=permute(repmat(phi_mn_k,[1,1,1,1,X,Y]),[1,2,3,5,6,4]);
    
    rphiAligned=permute(repmat(phiAlignedK,[1,1,1,1,X,Y]),[1,2,3,5,6,4]);
    rangleIncidence=permute(repmat(angleIncidence,[1,1,X,Y]),[1,3,4,2]);
    
    obj=zeros(M,K);
    %calculate contributions to all AP given alignment to one AP
    for kSel=1:K

        if M>1   
            tempe=squeeze(sum(sum(exp(1i*(rphi_mn_k+repmat(phi_mn_exy,[1,1,1,1,1,K])+repmat(rphiAligned(:,:,:,:,:,kSel),[1,1,1,1,1,K]))),1),2));
            tempu=squeeze(sum(sum(exp(1i*(phi_mn_k+repmat(phi_mn_u,[1,1,1,K])+repmat(phiAlignedK(:,:,:,kSel),[1,1,1,K]))),1),2)); %m,k always
        else
            tempe=permute(squeeze(sum(sum(exp(1i*(rphi_mn_k+repmat(phi_mn_exy,[1,1,1,1,1,K])+repmat(rphiAligned(:,:,:,:,:,kSel),[1,1,1,1,1,K]))),1),2)),[4,1,2,3]); %m x y k
            tempu=permute(squeeze(sum(sum(exp(1i*(phi_mn_k+repmat(phi_mn_u,[1,1,1,K])+repmat(phiAlignedK(:,:,:,kSel),[1,1,1,K]))),1),2)),[2 1]); %m,k always
        end
        
        %do not sum yet - isolate individual contribution
        b_k_u= Li^2.*(cos(angleIncidence./(d_m_k.*repmat(d_m_u,[1,K])))).*tempu; %m,k
        b_k_exy=Li^2.*(cos(rangleIncidence./(rd_m_k.*repmat(d_m_exy,[1,1,1,K])))).*tempe; %m,x,y,k
        
        A_k_u=abs(permute(repmat(a_k_u,[1,M]),[2,1])+b_k_u).^2; %m,k
        A_k_exy=abs(permute(repmat(a_k_exy,[1,1,1,M]),[4,2,3,1])+b_k_exy).^2; %m,x,y,k
    
        A_k_exy=permute(A_k_exy,[1,4,2,3]);%m,k,x,y
    
        %transmit AP
        A_t_u=A_k_u(:,transmitAP); %m,1
        
        
        %the jammers
        A_j_u=A_k_u(:,setdiff(1:K, transmitAP)); %(m,k-1)
        A_j_exy=A_k_exy(:, setdiff(1:K, transmitAP), :,:); %(m,k-1,x,y)
        %objective function
        
        if M>1
            A_t_exy=squeeze(A_k_exy(:,transmitAP,:,:)); %m, x,y
            SINRu=(ptmax*repmat(A_t_u,[1,X,Y]))./(repmat(Npi,[M,X,Y])+pjmax.*repmat(squeeze(sum(A_j_u,2)),[1,X,Y])); %m,x,y
            SINRexy=(ptmax*A_t_exy)./(repmat(Npi,[M,X,Y])+pjmax.*squeeze(sum(A_j_exy,2))); %m,x,y
        else
            A_t_exy=permute(squeeze(A_k_exy(:,transmitAP,:,:)),[3 1 2]); %m, x,y
            SINRu=(ptmax*repmat(A_t_u,[1,X,Y]))./(repmat(Npi,[M,X,Y])+pjmax.*repmat(permute(squeeze(sum(A_j_u,2)),[3 1 2]),[1,X,Y])); %m,x,y
            SINRexy=(ptmax*A_t_exy)./(repmat(Npi,[M,X,Y])+pjmax.*permute(squeeze(sum(A_j_exy,2)),[3 1 2])); %m,x,y
            
        end

        obj(:,kSel)=squeeze(sum(sum(log2(((ones(M,X,Y)+SINRu)./((ones(M,X,Y)+SINRexy).^(alpha)))),2),3)); %m,k  
    
    end
    
    I=ones(M,1); %index array
    for m=1:M
        [~,I(m)]=max(obj(m,:)); %find the AP
        phiAligned(:,:,m)=phiAlignedK(:,:,m,I(m)); %set the AP
    end

else %no IRS ins scenario
    phiAligned=zeros(Nb,Na);
end

end
function d = divisors(n)
    % Find divisors of a number n
    d = [];
    for i = 1:sqrt(n)
        if mod(n,i) == 0
            d = [d i n/i];
        end
    end
    d = unique(sort(d)); % Sort and remove duplicates
end
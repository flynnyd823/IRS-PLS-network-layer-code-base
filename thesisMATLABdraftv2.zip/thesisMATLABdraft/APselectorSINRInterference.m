function [selectedAP,SINRdiff,userSOP] = APselectorSINRInterference(APxy,STAxy,eveArea,lambda,dx,dy,IRSxy,orientationIRS,Ni,Li,phi,N,W)

%Determine the access point connections based on signal to noise advantage
%over average eavesdropper area (including the mutual interference on same
%channel).
%
%Inputs: 
%AP locations (numAP x 2) [m], User location (numUser x 2) [m], eavesdropper location border (4 x 1) [m],
%carrier wavelength [m], spatial resolution [1/m], IRS locations (numIRS x 2) [m], 
%IRS orientations (numIRS x 1), number of elements per IRS, size width of
%element on IRS [m], IRS phases (√NI x √NI x numIRS) [rads], noise floor
%[lin.], bandwidth [Hz]
% 
%Outputs:
%Return recommended connections (numUser x 1), maximum SINR advantage (numUser x 1), user secrecy
%outage probability (numUser x 1) [%].


%uniform power across all AP d0=1

P0=((lambda/(4*pi))^2);

%total eavesdropper samples
Ne = (1/dx)*(1/dy)*(eveArea(2,2)-eveArea(2,1))*(eveArea(1,2)-eveArea(1,1));

%set up arrays
selectedAP = ones(size(STAxy,1),1);

hUser = ones(size(STAxy,1),size(APxy,1));
hEaves = ones(Ne,size(APxy,1));

%find all channel coefficients between user to AP
for k=1:size(STAxy,1)
    %user location k
    STAs=STAxy(k,:);

    for j=1:size(APxy,1)
        %AP location j
        APs=APxy(j,:);

        hLOSUser = simulate_LOSnoRic_SISO(APs,STAs,lambda,P0,d0);
        hIRSUser = simulate_IRS_SISO(phi,APs,STAs,IRSxy,orientationIRS,lambda,P0,d0,Ni,Li);
        
        hUser(k,j)=hLOSUser+hIRSUser;
    end
end

i=0;

%calculate eavesdropper channels
for j=1:size(APxy,1)

        %AP location j
        APs=APxy(j,:);

        for ex=(eveArea(1,1)/dx):(eveArea(1,2)/dx)-1
            for ey=(eveArea(2,1)/dy):(eveArea(2,2)/dy)-1
                i=i+1;
                %apply desired resolution
                EVEx=ex*dx;
                EVEy=ey*dx;

                EVExy=[EVEx, EVEy];

                hLOSeve = simulate_LOSnoRic_SISO(APs,EVExy,lambda,P0,d0);
                hIRSeve = simulate_IRS_SISO(phi,APs,EVExy,IRSxy,orientationIRS,lambda,P0,d0,Ni,Li);
                
                hEaves(i,j)=hLOSeve+hIRSeve;
                
            end
        end
        i=0;
end

%transform to power
pUser=P0.*abs(hUser).^2;
pEaves=P0.*abs(hEaves).^2;

%interference calculations
pUserInt = zeros(size(STAxy,1),size(APxy,1));
pEavesInt = zeros(Ne,size(APxy,1));

for k = 1:size(STAxy,1)
    for jconnected=1:size(APxy,1)
        for jinterference=1:size(APxy,1)
            if jinterference~=jconnected
                pUserInt(k,jconnected)=pUserInt(k,jconnected)+pUser(k,jinterference);
            end
        end
    end
end

for e = 1:Ne
    for jconnected=1:size(APxy,1)
        for jinterference=1:size(APxy,1)
            if jinterference~=jconnected
                pEavesInt(e,jconnected)=pEavesInt(e,jconnected)+pEaves(e,jinterference);
            end
        end
    end
end

%calculate SINR
SINRUser = pUser./(W*N+pUserInt);
SINREaves = pEaves./(W*N+pEavesInt);

%average SINR of eavesdroppers
SINREavesAve = sum(SINREaves,1)./Ne; 

%SINRUser has dimensions users x AP
%SINREavesAve has dimensions 1 x AP

SINRdiff = ones(size(STAxy,1),1);

for user=1:size(STAxy,1)
   SINRadvantage = SINRUser(user,:)-SINREavesAve;
   [M,I]=max(SINRadvantage);
   SINRdiff(user)=M;
   %take the index (best AP)
   selectedAP(user)=I;
end


%for eavesdropper only capable of connecting to one AP at a time
%{
%access points decided
availableAP = unique(selectedAP(:).');

eavSINRdiff=zeros(Ne,1);
eveConnectionMap=zeros(Ne,1);
tempSINR = ones(size(availableAP));

for e=1:Ne %for each eavesdropper location
    for ja = 1:size(availableAP) %and for each available access point
        tempSINR(e,ja)=SINREaves(e,ja);
    end
    [eavSINRdiff(e), eveConnectionMap(e)]= max(tempSINR(e,:)); %indicate channel wiretap and strength
end

userSINR2=zeros(size(STAxy,1));

for k=1:size(STAxy,1) %for each user get the SINR
    userSINR2(k)=SINRUser(k,selectedAP(k));
end

eavCAPMax = W.*log2(eavSINRdiff+1); %strongest eavesdropper capacity Ne x 1 matrix to AP defined by eveConnectionMap
userCAPMax = W.*log2(userSINR2+1); %user capacity according to selectedAP

%for every user calculate the SOP given that eavesdropper only associate
%with strongest AP
userSOP=zeros(size(STAxy,1),1);
tempSOP =0;

for k=1:size(STAxy,1)
    for e=1:Ne
        if(eveConnectionMap(e)==selectedAP(k)) %if the eavesdropper is connected to the same AP as the user
            if(eavCAPMax(e)>userCAPMax(k)/2) %define the condition for SOP threshold
                tempSOP=tempSOP+1;
            end
        end
    end
    userSOP(k)=tempSOP/Ne;
    tempSOP=0;
end
%}

%eaves connects to all AP simultaneously
userSINR2=zeros(size(STAxy,1));

for k=1:size(STAxy,1) %for each user get the SINR
    userSINR2(k)=SINRUser(k,selectedAP(k));
end

eavCAPMax = W.*log2(SINREaves+1); %eavesdropper capacity Ne x j matrix
userCAPMax = W.*log2(userSINR2+1); %user capacity according to selectedAP

%for every user calculate the SOP given that eavesdropper can associate
%with any AP
userSOP=zeros(size(STAxy,1),1);
tempSOP =0;

for k=1:size(STAxy,1)
    for e=1:Ne
        if(eavCAPMax(e,selectedAP(k))>userCAPMax(k)/2) %define the condition for SOP threshold being more than half the user capacity
            tempSOP=tempSOP+1;
        end
    end
    userSOP(k)=tempSOP/Ne;
    tempSOP=0;
end


end


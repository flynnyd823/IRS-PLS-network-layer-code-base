function plot_statistics(ixMin,ixMax,SOA_mean,SOA_std,Cap_u_mean,Cap_u_std,samples)


figure(1)
yyaxis left;
plot(ixMin:1:ixMax,SOA_mean.','r-*');
xlabel("Number of IRS");
ylabel("Mean (%)");
xlim([ixMin ixMax]);
hold on;
yyaxis right;
plot(ixMin:1:ixMax,SOA_std.', 'b-o');
ylabel("Standard deviation")
grid on;
grid minor;
title(sprintf('Secrecy outage area, samples= %d', samples));
%legend('show');

figure(2)
yyaxis left;
plot(ixMin:1:ixMax,(Cap_u_mean.'./1e6),'r-*');
xlabel("Number of IRS");
ylabel("Mean (Mbit/s)");
xlim([ixMin ixMax]);
hold on;
grid on;
grid minor;
yyaxis right;
plot(ixMin:1:ixMax,Cap_u_std.'./1e6, 'b-o');
ylabel("Standard deviation")
title(sprintf('User throughput, samples= %d', samples));

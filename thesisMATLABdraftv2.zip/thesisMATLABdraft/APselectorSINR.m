function [selectedAP,SINRdiff,userSOP] = APselectorSINR(APxy,STAxy,eveArea,lambda,dx,dy,xIRS,yIRS,Ni,Li,phi,kfactor,N,B)

%Determine the access point connections based on signal to noise advantage
%over eavesdropper. Return connections, maximum SINR advantage and user secrecy
%outage probability

%uniform power across all AP d0=1
P0=((lambda/(4*pi))^2);

%total eavesdropper samples
Ne = (1/dx)*(1/dy)*(eveArea(2,2)-eveArea(2,1))*(eveArea(1,2)-eveArea(1,1));

%set up arrays. zero for fault testing
selectedAP = zeros(size(STAxy,1),1);

%size user x ap
hUser = ones(size(STAxy,1),size(APxy,1));
hEaves = ones(Ne,size(APxy,1));

%find all channel coefficients between user to AP
for k=1:size(STAxy,1)
    %user location k
    STAx=STAxy(k,1);
    STAy=STAxy(k,2);

    for j=1:size(APxy,1)
        %AP location j
        APx=APxy(j,1);
        APy=APxy(j,2);

        hLOSUser = simulate_LOSnoRic_SISO(APx,APy,STAx,STAy,lambda);
        hIRSUser = simulate_IRS_SISO(phi,APx,APy,STAx,STAy,xIRS,yIRS,lambda,Ni,Li);
        
        hUser(k,j)=hLOSUser+hIRSUser;
    end
end

i=0;

%calculate eavesdropper channels
for j=1:size(APxy,1)

        %AP location j
        APx=APxy(j,1);
        APy=APxy(j,2);

        for ex=(eveArea(1,1)/dx):(eveArea(1,2)/dx)-1
            for ey=(eveArea(2,1)/dy):(eveArea(2,2)/dy)-1
                i=i+1;
                %apply desired resolution
                eveX=ex*dx;
                eveY=ey*dx;

                hLOSeve = simulate_LOSnoRic_SISO(APx,APy,eveX,eveY,lambda);
                hIRSeve = simulate_IRS_SISO(phi,APx,APy,eveX,eveY,xIRS,yIRS,lambda,Ni,Li);
                
                hEaves(i,j)=hLOSeve+hIRSeve;
                
            end
        end
        i=0;
end


%transform to power
pUser=P0.*abs(hUser).^2;
pEaves=P0.*abs(hEaves).^2;

%calculate SINR
SINRUser = pUser./(B*N);
SINREaves = pEaves./(B*N);

%average SINR of eavesdroppers
SINREavesAve = sum(SINREaves,1)./Ne; 

%SINRUser has dimensions users x AP
%SINREavesAve has dimensions 1 x AP

SINRdiff = ones(size(STAxy,1),1);

for user=1:size(STAxy,1)
   SINRadvantage = SINRUser(user,:)-SINREavesAve;
   [M,I]=max(SINRadvantage);
   SINRdiff(user)=M;
   %take the index (best AP)
   selectedAP(user)=I;
end

%eaves connects to all AP simultaneously
userSINR2=zeros(size(STAxy,1));

for k=1:size(STAxy,1) %for each user get the SINR
    userSINR2(k)=SINRUser(k,selectedAP(k));
end

eavCAPMax = B.*log2(SINREaves+1); %eavesdropper capacity Ne x j matrix
userCAPMax = B.*log2(userSINR2+1); %user capacity according to selectedAP

%for every user calculate the SOP given that eavesdropper can associate
%with any AP
userSOP=zeros(size(STAxy,1),1);
tempSOP =0;

for k=1:size(STAxy,1)
    for e=1:Ne
        if(eavCAPMax(e,selectedAP(k))>userCAPMax(k)/2) %define the condition for SOP threshold being more than half the user capacity
            tempSOP=tempSOP+1;
        end
    end
    userSOP(k)=tempSOP/Ne;
    tempSOP=0;
end

end

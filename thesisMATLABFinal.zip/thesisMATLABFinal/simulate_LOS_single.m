function [hLOS, pLOS] = simulate_LOS_single(APxy,STAxy,lambda,Pt,Gk,GSTA)

%Simulate the channel conditions for line of sight from a single source to single destination. 
%
%Inputs:
%AP location (1 x 2) [m], User location (1 x 2) [m], carrier wavelength [m], reference power [watts], 
%reference distance [m], transmit power [watts], gain of transmitter [lin.], gain of receivers [lin.].
%
%Outputs:
%Channel coefficient for LOS [complex], received power [Watts].

APx=APxy(1);
APy=APxy(2);

STAx=STAxy(1);
STAy=STAxy(2);

%LOS distance
distance = sqrt(((STAx-(APx))).^2+((STAy-(APy))).^2);

%LOS phase shifts
pdLOS=(2*pi/lambda)*distance;

%generate LOS channel
hLOS = sqrt(Gk*GSTA*(lambda/(4*pi))^2).*(1./distance).*exp(pdLOS*-1i);
pLOS= Pt.*abs(hLOS).^2;
end
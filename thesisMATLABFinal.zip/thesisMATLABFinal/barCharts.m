close all;

%% Data labels
scenarios = {'Scenario 1','Scenario 2','Scenario 3'};
schemes = {'Smart \sigma=0', 'Smart \sigma=1', 'Smart+IRS \sigma=1', 'Smart+FJ+IRS \sigma=1'};

%% EASOR and UCAP data 
%(including Smart+IRS)
%{
STRONGEASOR = [42.5979 41.66 21.1644];
SMARTEASOR = [43.2172 33.784 20.504];
SMARTIRSEASOR = [39.19 10.8975 3.5321];
SMARTFJIRSEASOR = [39.17 10.7397 3.3169];

STRONGCAP = [1.0172e6 9.5303e5 1.033e6];
SMARTCAP  = [1.0152e6 9.0702e5 1.033e6];
SMARTIRSCAP = [1.0669e6 9.9749e6 1.3394e6];
SMARTFJIRSCAP = [1.0665e6 9.9678e6 1.3394e6];
%}

%scen 1 scen 2 scen 3
%secrecy
STRONGEASOR = [42.5979 41.66 21.1644];
SMARTEASOR = [43.2172 33.784 20.504];

SMARTFJEASOR = [43.1087 33.63 20.4566];
SMARTIRSEASOR=[39.19 10.8975 3.5321];

SMARTFJIRSEASOR = [39.17 10.7397 3.3169];

%User throughput
STRONGCAP = [1.0172e6 9.5303e5 1.033e6];
SMARTCAP  = [1.0152e6 9.0702e5 1.033e6];

SMARTFJCAP  = [1.0150e6 9.0692e5 1.0325e6];
SMARTIRSCAP =[1.0669e6 9.9749e5 1.3394e6];

SMARTFJIRSCAP  = [1.0665e6 9.9678e5 1.3394e6];

% EASOR percentage change from STRONG
EASORData = [SMARTEASOR; SMARTIRSEASOR; SMARTFJIRSEASOR];
EASORPercentageChange = (EASORData - STRONGEASOR) ./ STRONGEASOR * 100;

% UCAP percentage change from STRONG
UCAPData = [SMARTCAP; SMARTIRSCAP; SMARTFJIRSCAP];
UCAPPercentageChange = (UCAPData - STRONGCAP) ./ STRONGCAP * 100;

X = categorical(scenarios);
X = reordercats(X, scenarios);

% Bar width adjustment for more spacing between bars
barWidth = 0.4;  % Reduced width for increased spacing
groupSpacing = 0.6; % Increase spacing between groups

%% EASOR Bar Pot

figure(1);
barsEASOR = bar(X, [STRONGEASOR; SMARTEASOR; SMARTIRSEASOR; SMARTFJIRSEASOR].', 'grouped', 'BarWidth', barWidth);
ylabel('$\overline{\textrm{EASOR}}$ [\%]', 'Interpreter', 'latex');
legend(schemes, 'Location', 'northeast', 'FontSize', 10);
grid on;
set(gca, 'XTickLabelRotation', 0);

% Adjust position of bars for better spacing
for k = 1:length(barsEASOR)
    barsEASOR(k).XOffset = barsEASOR(k).XOffset * groupSpacing;
end

% Add percentage change labels for EASOR
for schemeIdx = 2:length(schemes)
    for scenarioIdx = 1:length(scenarios)
        % Get the y-position of the current bar
        y = EASORData(schemeIdx-1, scenarioIdx);
        
        % Get the position of the current bar
        x = barsEASOR(schemeIdx).XEndPoints(scenarioIdx);
        
        % Shift the far left dataset label to the right to avoid overlap
        if schemeIdx==4
            x=x+0.08;
        end
        
        % Display the percentage change above the bar with a small offset
        text(x, y + 2, sprintf('%.2g%%', EASORPercentageChange(schemeIdx-1, scenarioIdx)), ...
            'HorizontalAlignment', 'center', 'FontSize', 9, 'Color', 'k');
    end
end
ylim([0 50]);  % Set y-axis limits for UCAP

%% User throughput bar plot

figure(2);
barsUCAP = bar(X, [STRONGCAP; SMARTCAP; SMARTIRSCAP; SMARTFJIRSCAP].' ./ 1e6, 'grouped', 'BarWidth', barWidth);
set(gca, 'YScale', 'log');  % Keep the y-axis logarithmic
ylabel('$\overline{R_u}$ [Mbit/s]', 'Interpreter', 'latex');
legend(schemes, 'Location', 'northwest', 'FontSize', 10);
grid on;
ylim([0.85 1.4]);  % Set y-axis limits for UCAP

% Adjust position of bars for better spacing
for k = 1:length(barsUCAP)
    barsUCAP(k).XOffset = barsUCAP(k).XOffset * groupSpacing;
end

% Add percentage change labels for UCAP
for schemeIdx = 2:length(schemes)
    for scenarioIdx = 1:length(scenarios)
        % Get the y-position of the current bar
        y = UCAPData(schemeIdx-1, scenarioIdx) / 1e6;
        
        % Get the position of the current bar
        x = barsUCAP(schemeIdx).XEndPoints(scenarioIdx);
        if schemeIdx==4
            x=x+0.08;
        end
        % Display the percentage change above the bar with a small offset
        text(x, y * 1.03, sprintf('%.2g%%', UCAPPercentageChange(schemeIdx-1, scenarioIdx)), ...
            'HorizontalAlignment', 'center', 'FontSize', 9, 'Color', 'k');
    end
end
function [SOA_mean, SOA_std, Cap_u_mean, Cap_u_std] = change_sigma(sigmaDiscrete,samples,percentEve,eveDiscrete,numIRS, numAP,minDistanceAPB,minDistanceUB,minDistanceAP,minDistanceIRS,lambda,Sx,Sy,Na,Nb,Le,W,N0,pjmax,ptmax,Gk,GSTA)

Cap_u_results=ones(samples,sigmaDiscrete+1);
SOA_results=ones(samples,sigmaDiscrete+1);

for sigmaI=0:1:sigmaDiscrete
    sigma=sigmaI/sigmaDiscrete;
    fprintf('Currently on trial %d', sigma);
    fprintf('\n');
    for s=1:samples
        if mod(s,50)==0
            fprintf('Currently on sample %d', s);
            fprintf('\n');
        end
        [eveArea, STAxy, APxy, IRSxy,orientationIRS] = generate_random_scen(Sx,Sy,percentEve,numAP,numIRS,minDistanceAPB,minDistanceUB,minDistanceAP,minDistanceIRS);
        [d_m_u, d_m_k, d_m_exy, d_mn_u ,d_mn_k ,d_mn_exy ,d_k_u ,d_k_exy, angleIncidence]=quickCompute_d(APxy,STAxy,eveArea,IRSxy,orientationIRS,Na,Nb,Le);
        
        transmitAP=APselect_noIRS(d_k_u,d_k_exy,lambda,sigma,N0,W,ptmax,pjmax,Gk,GSTA);
        
        phiAligned = optimise_IRS_Align(d_m_u, d_m_k, d_m_exy, d_mn_u ,d_mn_k ,d_mn_exy ,d_k_u ,d_k_exy, angleIncidence,lambda,Na,Nb,Le,W,N0,pjmax,ptmax,transmitAP,sigma,Gk,GSTA);
        
        p_k=FJpower(d_m_u, d_m_k, d_m_exy, d_mn_u ,d_mn_k ,d_mn_exy ,d_k_u ,d_k_exy, ...
            angleIncidence,phiAligned,ptmax,transmitAP, Le,lambda,W,sigma,N0,pjmax,Gk,GSTA);
    
        Cap_u=calculate_user_cap(APxy, STAxy,IRSxy,orientationIRS,transmitAP, lambda,W, N0,ptmax,p_k,Na,Nb,Le,phiAligned,Gk,GSTA);
        eveCap=calculate_eaves_cap(APxy, IRSxy,orientationIRS,transmitAP, eveArea, eveDiscrete, lambda,W, N0,ptmax,p_k,Na,Nb,Le,phiAligned,Gk,GSTA);
        
        sCAP=repmat(Cap_u,size(eveCap,1),size(eveCap,2))-eveCap;
        
        ratio = 100*sum(sCAP<(1/2*Cap_u),"all")/numel(sCAP);
        
        SOA_results(s,sigmaI+1)=ratio;
        Cap_u_results(s,sigmaI+1)=Cap_u;
    
    end
end

SOA_mean=mean(SOA_results,1);
SOA_std=std(SOA_results,1);

Cap_u_mean=mean(Cap_u_results,1);
Cap_u_std=std(Cap_u_results,1);

end

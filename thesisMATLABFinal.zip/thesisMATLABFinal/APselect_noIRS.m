function [selectedAP] = APselect_noIRS(d_k_u,d_k_exy,lambda,sigma,N0,W,ptmax,pjmax,Gk,GSTA)

%Determine the access point connections based on signal to noise advantage
%over average eavesdropper area (including the mutual interference on same
%channel).
%
%Inputs: 
%AP locations (numAP x 2) [m], User location (numUser x 2) [m], eavesdropper location border (4 x 1) [m],
%carrier wavelength [m], spatial resolution [1/m], IRS locations (numIRS x 2) [m], 
%IRS orientations (numIRS x 1), number of elements per IRS, size width of
%element on IRS [m], IRS phases (√NI x √NI x numIRS) [rads], noise floor
%[lin.], bandwidth [Hz]
% 
%Outputs:
%Return recommended connections (numUser x 1), maximum SINR advantage (numUser x 1), user secrecy
%outage probability (numUser x 1) [%].

numAP=size(d_k_u,1);

X=size(d_k_exy,2);
Y=size(d_k_exy,3);

%find all channel coefficients between user to AP and eaves to AP

if numAP>1
    phi_k_u=(2*pi/lambda)*d_k_u;
    phi_k_exy=(2*pi/lambda).*d_k_exy;
    
    a_k_u = sqrt(Gk*GSTA)*lambda.*(exp(-1i.*(phi_k_u)))./d_k_u; 
    a_k_exy = sqrt(Gk*GSTA)*lambda.*(exp(-1i.*(phi_k_exy)))./d_k_exy;
    
    %all AP
    A_k_u=abs(a_k_u).^2;
    A_k_exy=abs(a_k_exy).^2;
    
    %jamming effect
    A_j_u=ones(numAP,1);
    A_j_exy=ones(numAP,X,Y);
    
    for kconnected = 1:numAP
        for kinterference=1:numAP
            if kinterference~=kconnected
                A_j_u(kconnected)=A_j_u(kconnected)+A_k_u(kinterference);
                A_j_exy(kconnected)=A_j_exy(kconnected)+A_k_exy(kinterference);
            end
        end
    end
    
    %normalized noise term
    Npi=16*(pi^2)*W*N0;
    
    %calculate SINR
    SINRu = repmat(ptmax.*A_k_u./(Npi+pjmax.*A_j_u),[1,X,Y]);
    SINRexy = ptmax.*A_k_exy./(Npi+pjmax.*A_j_exy);
   
    %calculate the objective function
    obj=squeeze(sum(sum(log2(((ones(1,X,Y)+SINRu)./((ones(1,X,Y)+SINRexy).^(sigma)))),2),3)); %k   
    
    [~,I]=max(obj);
    %take the index (best AP)
    selectedAP=I;
    
else
    selectedAP=1;
end


end


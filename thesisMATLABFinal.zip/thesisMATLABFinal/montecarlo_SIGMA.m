%perform monte carlo simulation of environment with changing eavesdropper
%area

close all;
clear all;

%number of independent samples to be run
samples=1;


%% network parameters
%security bias
sigma=1;

f=2.4*10^9;
c=3*10^8;
lambda = c/f;

ptmax = 1;
pjmax = 1;
N0 = 10^-12;

Gk=1;
GSTA=1;

W = 20*10^6;

Na=12; %number of IRS elements on the width
Nb=Na; %default to square configuration
Le=lambda/2; %element size [m]i

%environment size
Sx = 80;
Sy = 80;

percentEve=10;
eveDiscrete=1; %resolution for SOA calculation

%proximity conditions
minDistanceAP = 10; %metres
minDistanceIRS=10; %metres
minDistanceAPB=10; %metres

farfieldrelax = 3*sqrt(Na*Nb*Le^2);
minDistanceUB=farfieldrelax; %metres


sigmaDiscrete=0.2; %resolution of sigma, decrease for better resolution

numIRSMax=5;
numIRSMin=0;

numAP=2;

SIGMAresults=zeros(1/sigmaDiscrete+1,numIRSMax-numIRSMin+1,4);

for numIRS=numIRSMin:numIRSMax
    sigmaDiscrete2=1/sigmaDiscrete;
    fprintf('Currently on IRS %d', numIRS);
    fprintf('\n');
    [SOA_mean, SOA_std, Cap_u_mean, Cap_u_std] = change_sigma(sigmaDiscrete2,samples,percentEve,eveDiscrete,numIRS, numAP,minDistanceAPB,minDistanceUB,minDistanceAP,minDistanceIRS,lambda,Sx,Sy,Na,Nb,Le,W,N0,pjmax,ptmax,Gk,GSTA);
    SIGMAresults(:,numIRS+1,1)=SOA_mean.';
    SIGMAresults(:,numIRS+1,2)=SOA_std.';
    SIGMAresults(:,numIRS+1,3)=Cap_u_mean.';
    SIGMAresults(:,numIRS+1,4)=Cap_u_std.';
end


%% plot


close all;

for numIRS=numIRSMin:numIRSMax
    i=numIRS-numIRSMin+1;

    figure(i)
    sigma_values = linspace(0, 1, length(SIGMAresults(:,i,3))); % Generate sigma values from 0 to 1

    x = SIGMAresults(:,i,3)./1e6;  % X-axis data
    y = SIGMAresults(:,i,1);       % Y-axis data
    
    x_range = max(x) - min(x);
    y_range = max(y) - min(y);
    
    x_margin = 0.1 * x_range;  % 5% margin for x-axis
    y_margin = 0.1 * y_range;  % 5% margin for y-axis


    plot(SIGMAresults(:,i,3)./1e6, SIGMAresults(:,i,1),['-' 'o']);

    
    % Add text labels for each point
    for i = 1:length(x)
        text(x(i), y(i), ['\sigma = ' num2str(sigma_values(i), '%.2f')], ...
            'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');
    end
    xlabel('$\overline{R_u}$ [Mbit/s]', 'Interpreter', 'latex');
    ylabel('$\overline{\textrm{EASOR}}$ [\%]', 'Interpreter', 'latex');
    grid on;
    grid minor;
    xlim([min(x) - x_margin, max(x) + x_margin]);
    ylim([min(y) - y_margin, max(y) + y_margin]);
    title(sprintf('IRS_%d', numIRS), 'FontSize', 16);
end
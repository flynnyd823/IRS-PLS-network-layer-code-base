%all colour maps

close all;
xlabpos=ones(numAP+numIRS+1,1);
ylabpos=ones(numAP+numIRS+1,1);
labels=cell(numAP+numIRS+1,1);

for k=1:numAP
    xlabpos(k)=APxy(k,1);
    ylabpos(k)=APxy(k,2);
    labels{k}=sprintf('AP_%d', k);
end

for m=1:numIRS
    xlabpos(numAP+m)=IRSxy(m,1);
    ylabpos(numAP+m)=IRSxy(m,2);
    labels{numAP+m}=sprintf('');
end
xlabpos = xlabpos-10.25;
ylabpos = ylabpos-10.25;

%manually IRS positions (2X2)
xlabpos(3)=xlabpos(3)+2.5;
xlabpos(4)=xlabpos(4)+10;
xlabpos(5)=xlabpos(5)-5;
ylabpos(3)=ylabpos(3)-5;
ylabpos(4)=ylabpos(4)+10;
ylabpos(5)=ylabpos(5)+15;

STAx=STAxy(1);
STAy=STAxy(2);

xlabpos(end)=STAx-10.25;
ylabpos(end)=STAy-10.25;
labels{end}='User';

IRSx=IRSxy(:,1);
IRSy=IRSxy(:,2);

APx=APxy(:,1);
APy=APxy(:,2);

textFontMinor=8;
titleFontSize=14;

%% Signal to noise ratio

figure(1)
imagesc(xa, ya, 10.*log10(SINRmap).');
a=colorbar();
colormap(turbo);
axis equal tight;
set(gca,'FontSize',12,'LineWidth',2);
set(gca,'ColorScale','lin');
set(gca,'YDir','normal')
a.Label.String = 'SINR (dB)';
xlabel('x position [m]')
ylabel('y position [m]')
hold on;
%plot((APx),(APy), 'p', 'LineWidth', 2, 'Color', 'w', 'MarkerSize', 2,'MarkerFaceColor','k');
plot((IRSx),(IRSy), 'p', 'LineWidth', 2, 'Color', 'w', 'MarkerSize', 3,'MarkerFaceColor','k');
%plot((APx2*dx)-1,(APy2*dy)-1, 'p', 'LineWidth', 2, 'Color', 'w', 'MarkerSize', 10,'MarkerFaceColor','k')
%plot((STAx),(STAy), 'p', 'LineWidth', 2, 'Color', 'w', 'MarkerSize', 1,'MarkerFaceColor','k');

t = text(xlabpos,ylabpos,labels,'HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
te = text((eveArea(1,2)+eveArea(1,1))/2-(Sx/10),(eveArea(2,2)+eveArea(2,1))/2,'Eaves','HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
for ti=1:size(xlabpos)
    t(ti).FontSize = textFontMinor;
    t(ti).Color = 'black';
end

te.FontSize=20;
te.Color = 'black';
scatter(APxy(:,1),APxy(:,2),105,'k','^',"filled");
scatter(STAxy(1),STAxy(2),90,'b',"o","filled");
%mark unprotected zone
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,1) eveArea(2,1)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,2) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,1)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,2) eveArea(1,2)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
axis square
box on;
xlim([0 Sx]);
ylim([0 Sy]);
%legend(["Access points" "User STAxy"],'fontsize', 10)
title("SINR");
hold off;


%% IRS to transmit AP
figure(2);
colormap(turbo);
for i =1:numIRS
    pToPlot=pIRSIndv(:,:,i);
    %handles maximum 6 irs
    if numIRS==1
        imagesc(xa, ya, -10.*log10(pToPlot.'));
    elseif numIRS==2
        subplot(1,2,i)
    elseif numIRS==3
        subplot(2,2,i)
    elseif numIRS==4
        subplot(2,2,i)
    elseif numIRS==5
        subplot(2,3,i)
    elseif numIRS==6
        subnplot(2,3,i)
    else
        error("Too many IRS to plot maps");
    end
imagesc(xa, ya, -10.*log10(pToPlot.'));
clim([70 180]);
axis equal tight;
set(gca,'FontSize',12,'LineWidth',2);
box on;
xlim([0 Sx]);
ylim([0 Sy]);
set(gca,'ColorScale','lin');
set(gca,'YDir','normal')
a.Label.String = 'Pathloss (dB)';
xlabel('x position [m]')
ylabel('y position [m]')
hold on;
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,1) eveArea(2,1)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,2) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,1)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,2) eveArea(1,2)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');

%plot((IRSx),(IRSy), 'p', 'LineWidth', 2, 'Color', 'w', 'MarkerSize', 3,'MarkerFaceColor','k');
scatter(APxy(transmitAP,1),APxy(transmitAP,2),105,'k','^',"filled");
scatter(STAxy(:,1),STAxy(:,2),70,'b',"o","filled");
scatter(IRSx,IRSy,105,'m','+','LineWidth', 5);
te = text((eveArea(1,2)+eveArea(1,1))/2-(Sx/10),(eveArea(2,2)+eveArea(2,1))/2,'A_e','HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
xticks([0 20 40 60 80]);

% Set the y-axis ticks with the specified step size
yticks([0 20 40 60 80]);

% Optionally, customize the labels for both axes if needed
xticklabels({'0', '20', '40', '60', '80'});
yticklabels({'0', '20', '40', '60', '80'});
t = text(xlabpos,ylabpos,labels,'HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');

for ti=1:size(xlabpos)
    t(ti).FontSize = textFontMinor;
    t(ti).Color = 'black';
end
t(1).Visible = 'off';
hold off;
title(sprintf('IRS_%d', i), 'FontSize', titleFontSize);
end
%title("IRS " + num2str(i));
% Add a horizontal colorbar after all subplots
a = colorbar('southoutside'); % Horizontal colorbar below the subplots

% Set the colorbar label
a.Label.String = 'Pathloss [dB]';

% Adjust the colorbar position to ensure it's visible and higher up
a.Position = [0.2, 0.10, 0.6, 0.03]; % Shifted down by 0.05 units
%sgtitle('Individual IRS patterns transmitter');

%% transmit pathloss
figure(3);
colormap(turbo);
imagesc(xa, ya, -10.*log10(pLOSIRS).');
a=colorbar();
axis equal tight;
set(gca,'FontSize',12,'LineWidth',2);
set(gca,'ColorScale','lin');
set(gca,'YDir','normal')
a.Label.String = 'Pathloss Transmit (dB)';
xlabel('x position [m]')
ylabel('y position [m]')
hold on;
plot((IRSx),(IRSy), 'p', 'LineWidth', 2, 'Color', 'w', 'MarkerSize', 3,'MarkerFaceColor','k');

t = text(xlabpos,ylabpos,labels,'HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
te = text((eveArea(1,2)+eveArea(1,1))/2-(Sx/10),(eveArea(2,2)+eveArea(2,1))/2,'Eaves','HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
for ti=1:size(xlabpos)
    t(ti).FontSize = textFontMinor;
    t(ti).Color = 'black';
end

te.FontSize=20;
te.Color = 'black';
scatter(APxy(:,1),APxy(:,2),105,'k','^',"filled");
scatter(STAxy(:,1),STAxy(:,2),90,'b',"o","filled");
%mark unprotected zone
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,1) eveArea(2,1)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,2) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,1)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,2) eveArea(1,2)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
axis square
box on;
xlim([0 Sx]);
ylim([0 Sy]);
hold off;


%% path loss jammers (all)
figure(4);
imagesc(xa, ya, -10.*log10(pLOSIRSj).');
a=colorbar();
colormap(turbo);
axis equal tight;
set(gca,'FontSize',12,'LineWidth',2);
set(gca,'ColorScale','lin');
set(gca,'YDir','normal')
a.Label.String = 'Pathloss Jammer (dB)';
xlabel('x position [m]')
ylabel('y position [m]')
hold on;
%plot((APx),(APy), 'p', 'LineWidth', 2, 'Color', 'w', 'MarkerSize', 2,'MarkerFaceColor','k');
plot((IRSx),(IRSy), 'p', 'LineWidth', 2, 'Color', 'w', 'MarkerSize', 3,'MarkerFaceColor','k');
%plot((STAx),(STAy), 'p', 'LineWidth', 2, 'Color', 'w', 'MarkerSize', 1,'MarkerFaceColor','k');
%labels (with normalized ratio to the 20x20 scenario)

t = text(xlabpos,ylabpos,labels,'HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
te = text((eveArea(1,2)+eveArea(1,1))/2-(Sx/10),(eveArea(2,2)+eveArea(2,1))/2,'Eaves','HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
for ti=1:size(xlabpos)
    t(ti).FontSize = textFontMinor;
    t(ti).Color = 'black';
end

te.FontSize=20;
te.Color = 'black';
scatter(APxy(:,1),APxy(:,2),105,'k','^',"filled");
scatter(STAxy(:,1),STAxy(:,2),90,'b',"o","filled");
%mark unprotected zone
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,1) eveArea(2,1)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,2) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,1)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,2) eveArea(1,2)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
axis square
%legend(["Access points" "User STAxy"],'fontsize', 10)
box on;
xlim([0 Sx]);
ylim([0 Sy]);
hold off;

%% the scenario

figure(5)
scatter(APxy(:,1),APxy(:,2),105,'k','^',"filled");
hold all;
scatter(STAxy(:,1),STAxy(:,2),90,'b',"o","filled");
scatter(IRSx,IRSy,130,'m','+','LineWidth', 5);

%mark unprotected zone
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,1) eveArea(2,1)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,2) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,1)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,2) eveArea(1,2)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
te = text((eveArea(1,2)+eveArea(1,1))/2-(Sx/10),(eveArea(2,2)+eveArea(2,1))/2,'Eaves','HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
te.FontSize=20;
te.Color='Red';
axis square
legend(["Access points" "User STAxy" "IRS"],'fontsize', 14)
box on;
xlim([0 Sx]);
ylim([0 Sy]);
%title('Scenario')

%% phase shifts
figure(6)

climVals = [0 1]; 
colormap(gray); 

for i = 1:numIRS
    if numIRS == 1
        imagesc(1:Na, 1:Nb, phiAligned(:,:,i)./(2*pi));
    elseif numIRS == 2
        subplot(1,2,i);
    elseif numIRS == 3
        subplot(2,2,i);
    elseif numIRS == 4
        subplot(2,2,i);
    elseif numIRS == 5
        subplot(2,3,i);
    elseif numIRS == 6
        subplot(2,3,i);
    else
        error("Too many IRS to plot phases");
    end
    
    hold on;

    % Plot the phase data
    imagesc(1:Na, 1:Nb, phiAligned(:,:,i)./(2*pi)); 

    % Set consistent color axis for all subplots
    clim(climVals); % Use global color limits
    %axes('Position', pos(i,:)); % Manually set position for each subplot
    axis equal tight;


    title(sprintf('IRS_%d', i), 'FontSize', 14);



    % Adjust axes properties
    set(gca, 'FontSize', 6, 'LineWidth', 2);
    set(gca, 'ColorScale', 'linear');
    set(gca, 'YDir', 'normal');
    %xlim([1 Na]); % Set x-axis limits
    %ylim([1 Nb]); % Set y-axis limits
    xlabel('Element columns');
    ylabel('Element rows');

end

% Add a single colorbar for all subplots
a = colorbar('southoutside'); % Adjust position as needed
a.Position = [0.2, 0.10, 0.6, 0.03]; % Shifted down by 0.05 units
a.Label.String = 'Phase shifts (\times 2\pi) [rad]';

% Set consistent color axis for all subplots
clim(climVals); % Apply global color limits again to ensure consistency
hold off;
%%
figure(7);
colormap(turbo);
for i =1:numIRS
    pToPlot=pIRSIndvj(:,:,i);
    %handles maximum 6 irs
    if numIRS==1
        imagesc(xa, ya, -10.*log10(pToPlot.'));
    elseif numIRS==2
        subplot(1,2,i)
    elseif numIRS==3
        subplot(2,2,i)
    elseif numIRS==4
        subplot(2,2,i)
    elseif numIRS==5
        subplot(2,3,i)
    elseif numIRS==6
        subnplot(2,3,i)
    else
        error("Too many IRS to plot maps");
    end
imagesc(xa, ya, -10.*log10(pToPlot.'));
clim([60 180]);
set(gca,'ColorScale','lin');
set(gca,'YDir','normal')
axis equal tight;
set(gca,'FontSize',12,'LineWidth',2);
box on;
xlim([0 Sx]);
ylim([0 Sy]);

xlabel('x position [m]')
ylabel('y position [m]')
hold on;
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,1) eveArea(2,1)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,2) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,1)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,2) eveArea(1,2)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');

scatter(APxy(:,1),APxy(:,2),105,'k','^',"filled");
scatter(STAxy(:,1),STAxy(:,2),70,'b',"o","filled");
scatter(IRSx,IRSy,105,'m','+','LineWidth', 5);

xticks([0 20 40 60 80]);

% Set the y-axis ticks with the specified step size
yticks([0 20 40 60 80]);

% Optionally, customize the labels for both axes if needed
xticklabels({'0', '20', '40', '60', '80'});
yticklabels({'0', '20', '40', '60', '80'});
%labels (with normalized ratio to the 20x20 scenario)
te = text((eveArea(1,2)+eveArea(1,1))/2-(Sx/10),(eveArea(2,2)+eveArea(2,1))/2,'A_e','HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');

t = text(xlabpos,ylabpos,labels,'HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');

for ti=1:size(xlabpos)
    t(ti).FontSize = textFontMinor;
    t(ti).Color = 'black';
end

t(transmitAP).Visible = 'off';
hold off;
title(sprintf('IRS_%d', i), 'FontSize', titleFontSize);
end
a = colorbar('southoutside'); % Horizontal colorbar below the subplots

% Set the colorbar label
a.Label.String = 'Pathloss [dB]';

% Adjust the colorbar position to ensure it's visible and higher up
a.Position = [0.2, 0.10, 0.6, 0.03]; % Shifted down by 0.05 units
%sgtitle('Individual IRS patterns Jammer');
%Generates the first example scenario used to show IRS beam patterns

Sx = 80;
Sy = 80;

numIRS=2;
numAP=2;

%user (x,y)
STAxy = [16 16];

%access point (x,y)\120
APxy=[60 64;
24	32];

%IRS locations (x,y)
IRSxy=[round(Sx/2) Sy
    Sx round(Sy/2);
    ];

orientationIRS=["horizontal","vertical"];

% eavesdropper area x1 x2 y1 y2
eveArea=[round(Sx/2),Sx;0,round(Sy/2)];

%throw error messages (do not delete)
if size(eveArea,1)~=2||size(eveArea,2)~=2
    error("Incorrectly defined eavesdropper area");
elseif size(orientationIRS)~=size(IRSxy,1)
    error("Sumber of IRS positions does not match number of IRS orientations");
end
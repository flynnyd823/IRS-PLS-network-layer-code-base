function [phiAligned, I] = optimise_IRS_Align(d_m_u, d_m_k, d_m_exy, d_mn_u ,d_mn_k ,d_mn_exy ,d_k_u ,d_k_exy, angleIncidence,lambda,Na,Nb,Li,W,N0,pjmax,ptmax,transmitAP,sigma,Gk,GSTA)

%Optimise the phase shifts for multiple square IRS using the phase align technique. 
% 
%Inputs: 

% 
%Outputs:
%Aligned element phases (nb x na x numIRS) [rads].

%k=transmitAP

K=size(d_m_k,2);
M=size(d_m_k,1);

if M>0
    X=size(d_k_exy,2);
    Y=size(d_k_exy,3);
    
    Npi=(4*pi^2)*W*N0;
    
    phiAligned=ones(Nb,Na,M);
    
    %distance from irs elements to centre of eavesdropper position (row, col,
    %m, xc, yc)
    xc=floor(size(d_mn_exy,4)/2);
    yc=floor(size(d_mn_exy,5)/2);
    d_mn_exyc=d_mn_exy(:,:,:,xc,yc);
    d_k_exyc=d_k_exy(:,xc,yc);
    
    %calculate the phases
    
    coeff=(2*pi/lambda);
    phi_k_u=coeff*d_k_u;
    phi_k_exy=coeff.*d_k_exy;
    phi_k_exyc=coeff.*d_k_exyc;
    
    phi_mn_k=coeff.*d_mn_k;
    phi_mn_u=coeff.*d_mn_u;
    phi_mn_exy=coeff.*d_mn_exy;
    phi_mn_exyc=coeff.*d_mn_exyc;
    
    
    %set index to K+1 for null AP
    phiAlignedK=zeros(Nb,Na,M,K+1);
    
    for m=1:M %isolate IRS
        for k=1:K
            if k==transmitAP
                %align to user
                phiAlignedK(:,:,m,k) = repmat(phi_k_u(k),[Nb,Na])-(phi_mn_u(:,:,m)+phi_mn_k(:,:,m,k));
            else
                %align to centre of eavesdropper area
                phiAlignedK(:,:,m,k) = repmat(phi_k_exyc(k),[Nb,Na])-(phi_mn_exyc(:,:,m)+phi_mn_k(:,:,m,k));
            end
        end
    end
    
   
    phiAlignedK = mod(phiAlignedK,2*pi); %in rads
    
    a_k_u = sqrt(Gk*GSTA)*lambda.*(exp(-1i.*(phi_k_u)))./d_k_u; %K,1
    a_k_exy = sqrt(Gk*GSTA)*lambda.*(exp(-1i.*(phi_k_exy)))./d_k_exy; %K,x,y
        
    rd_m_k=permute(repmat(d_m_k,[1,1,X,Y]),[1,3,4,2]); %m x y K
    rphi_mn_k=permute(repmat(phi_mn_k,[1,1,1,1,X,Y]),[1,2,3,5,6,4]); %nb na m x y k
    
    rphiAligned=permute(repmat(phiAlignedK,[1,1,1,1,X,Y]),[1,2,3,5,6,4]); %nb na m x y k
    rangleIncidence=permute(repmat(angleIncidence,[1,1,X,Y]),[1,3,4,2]); %m x y k
    
    obj=zeros(M,K);
    %calculate contributions to all AP given alignment to one AP

    for kSel=1:K+1
    
        %irs contribution (no summation since IRS are isolated at this point
        %push k to the outside
    
        if M>1
            tempu=squeeze(sum(sum(exp(-1i*(phi_mn_k+repmat(phi_mn_u,[1,1,1,K])+repmat(phiAlignedK(:,:,:,kSel),[1,1,1,K]))),1),2)); %m,k
            tempe=squeeze(sum(sum(exp(-1i*(rphi_mn_k+repmat(phi_mn_exy,[1,1,1,1,1,K])+repmat(rphiAligned(:,:,:,:,:,kSel),[1,1,1,1,1,K]))),1),2)); %m x y k
        else
            tempu=squeeze(sum(sum(exp(-1i*(phi_mn_k+repmat(phi_mn_u,[1,1,1,K])+repmat(phiAlignedK(:,:,:,kSel),[1,1,1,K]))),1),2)).'; %1 k
            tempe=permute(squeeze(sum(sum(exp(-1i*(rphi_mn_k+repmat(phi_mn_exy,[1,1,1,1,1,K])+repmat(rphiAligned(:,:,:,:,:,kSel),[1,1,1,1,1,K]))),1),2)),[4,1,2,3]); % 1 x y k
        end
        
        %do not sum yet - isolate individual contribution
        b_k_u= sqrt(Gk*GSTA).*(Li^2).*(cos(angleIncidence)./(d_m_k.*repmat(d_m_u,[1,K]) ) ).*tempu; %m,k
        b_k_exy = sqrt(Gk*GSTA).*(Li^2).*(cos(rangleIncidence)./(rd_m_k.*repmat(d_m_exy,[1,1,1,K]) ) ).*tempe; %m,x,y,k
    
        A_k_u=abs(repmat(a_k_u,[1,M]).'+b_k_u).^2; %m,k
        A_k_exy=abs(permute(repmat(a_k_exy,[1,1,1,M]),[4,2,3,1])+b_k_exy).^2; %m,x,y,k

        A_k_exy=permute(A_k_exy,[1,4,2,3]);%m,k,x,y
    
        %transmit AP
        A_t_u=A_k_u(:,transmitAP); %m,1
        
        %the jammers
        A_j_u=A_k_u(:,setdiff(1:K, transmitAP)); %(m,k-1)
        A_j_exy=A_k_exy(:, setdiff(1:K, transmitAP), :,:); %(m,k-1,x,y)
        %objective function
        
        if M>1
            A_t_exy=squeeze(A_k_exy(:,transmitAP,:,:)); %m, x,y
            SINRu=(ptmax*repmat(A_t_u,[1,X,Y]))./(repmat(Npi,[M,X,Y])+pjmax.*repmat(squeeze(sum(A_j_u,2)),[1,X,Y])); %m,x,y
            SINRexy=(ptmax*A_t_exy)./(repmat(Npi,[M,X,Y])+pjmax.*squeeze(sum(A_j_exy,2))); %m,x,y
            obj(:,kSel)=squeeze(sum(sum(log2(((ones(M,X,Y)+SINRu)./((ones(M,X,Y)+SINRexy).^(sigma)))),2),3)); %m,k
        else
            A_t_exy=squeeze(A_k_exy(1,transmitAP,:,:)); %x,y
            SINRu=(ptmax*repmat(A_t_u,[X,Y]))./(repmat(Npi,[X,Y])+pjmax.*repmat(sum(A_j_u,2),[X,Y])); %x,y
            SINRexy=(ptmax*A_t_exy)./(repmat(Npi,[X,Y])+pjmax.*squeeze(sum(A_j_exy,2))); %x,y
            obj(kSel)=sum(sum(log2(((ones(X,Y)+SINRu)./((ones(X,Y)+SINRexy).^(sigma)))),1),2); %k    
        end
    
    end
    
        if M>1
            I=ones(M,1); %index array
            for m=1:M
                
                [~,I(m)]=max(obj(m,:)); %find the AP
                phiAligned(:,:,m)=phiAlignedK(:,:,m,I(m)); %set the AP
                if I(m)==K+1 %not in use
                    I(m)=0;
                end
            end
        else
            [~,I]=max(obj(:)); %find the AP
            phiAligned=phiAlignedK(:,:,1,I); %set the AP
            if I==K+1 %not in use
                I=0;
            end
        end
else
    phiAligned=zeros(Nb,Na,M);
    I=0;
end
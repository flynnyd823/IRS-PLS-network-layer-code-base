function [hIRS,hIRSIndv,pIRS,pIRSIndv] = simulate_IRS_map(phiAligned,dx,dy,Nx,Ny,APs,IRSxy,orientationIRS,lambda,Na,Nb,Li,ptmax,Gk,GSTA)

%Simulate the channel conditions introduced by multiple square IRS from a single source to a square map. 
%
%Inputs:
%IRS phase elements (Nb x Na x numIRS), x resolution, y resolution, grid x, grid y, 
%AP location (1 x 2) [m], IRS locations (numIRS x 2) [m], IRS orientations (numIRS x 1), 
%carrier wavelength [m], number of elements along IRS width, num elements IRS height, size of element [m], 
%transmit power [watts],gain of transmitter [lin.], gain of receivers [lin.].
%
%Outputs:
%Channel coefficient for combined IRS [complex], channel coefficients from each IRS (numIRS x 1) [complex], 
%received power [Watts], each power contribution (numIRS x 1) [Watts].

M = size(IRSxy,1);

hIRSIndv=ones(Nx,Ny,M);
pIRSIndv=ones(Nx,Ny,M);

if M>0

    APx=APs(1);
    APy=APs(2);
    
    IRSx=IRSxy(:,1);
    IRSy=IRSxy(:,2);
    
    phi=exp(phiAligned*-1i);
    
    %AP to IRS elements distance (distance1)
    distance1=ones(Nb,Na,M);
    
    %IRS elements to pos distance (distance2)
    distance2=ones(Nx,Ny,Nb,Na,M);
    
    %path loss of IRS
    beta=zeros(Nx,Ny,M);
    dist2=ones(Nx,Ny);
    
    for ixIRS=1:M
    
        dist1=sqrt(((IRSx(ixIRS)-APx)).^2+(IRSy(ixIRS)-APy).^2);
    
        %horizontal IRS
        if orientationIRS(ixIRS)=="horizontal"
            
            
            %check the 'dark side' of IRS along y axis
            if(IRSy(ixIRS)<APy)
                ylim1=IRSy(ixIRS)/dy+1;
                ylim2=Ny;
            else
                ylim1=1;
                ylim2=IRSy(ixIRS)/dy;
            end
    
            for column = 1:Na
                for row = 1:Nb
                    distance1(row,column,ixIRS) = sqrt((IRSx(ixIRS)-(Na/2-column)*Li-APx).^2+(IRSy(ixIRS)-APy).^2+(-(Nb/2-row)*Li).^2);
                end
            end
            
        
            for column = 1:Na
                for row = 1:Nb
                    for x = 1:Nx
                        for y = ylim1:ylim2
                            distance2(x,y,row,column,ixIRS) = sqrt((IRSx(ixIRS)-(Na/2-column)*Li-x*dx).^2+(IRSy(ixIRS)-y*dy).^2+(-(Nb/2-row)*Li).^2);
                            dist2(x,y)=sqrt(((IRSx(ixIRS)-x*dx)).^2+(IRSy(ixIRS)-y*dy).^2);
                        end
                    end
                end
            end
    
            %compensate for angular response of IRS
            angleIncidence = atand(abs(APx-IRSx(ixIRS))/abs(APy-IRSy(ixIRS)));
            beta(:,:,ixIRS)=Gk*GSTA*(1/(4*pi^2)).*((Li^2)./(dist1.*dist2(:,:))).^2.*cos(angleIncidence)^2;
        
    
        elseif orientationIRS(ixIRS)=="vertical"
            %check the 'dark side' of IRS along x axis
            
            
            if(IRSx(ixIRS)<APx)
                xlim1=IRSx(ixIRS)/dx+1;
                xlim2=Nx;
            else
                xlim1=1;
                xlim2=IRSx(ixIRS)/dx;
            end
            
    
            for column = 1:Na
                for row = 1:Nb
                    distance1(row,column,ixIRS) = sqrt(((IRSx(ixIRS)-APx)).^2+(IRSy(ixIRS)-(Na/2-column)*Li-APy).^2+(-(Nb/2-row)*Li).^2);
                end
            end
    
            for column = 1:Na
                for row = 1:Nb
                    for x = xlim1:xlim2
                        for y = 1:Ny
                            distance2(x,y,row,column,ixIRS) = sqrt((IRSx(ixIRS)-x*dx).^2+(IRSy(ixIRS)-(Na/2-column)*Li-y*dy).^2+(-(Nb/2-row)*Li).^2);
                            dist2(x,y)=sqrt(((IRSx(ixIRS)-x*dx)).^2+(IRSy(ixIRS)-y*dy).^2);
                        end
                    end
                end
            end
    
            %compensate for angular response of IRS (independent of final
            %location
            angleIncidence = atand(abs(APy-IRSy(ixIRS))/abs(APx-IRSx(ixIRS)));
            beta(:,:,ixIRS)=Gk*GSTA*(1/(4*pi)^2).*((Li^2)./(dist1.*dist2(:,:))).^2.*cos(angleIncidence)^2;
    
        else
            error("Incorrect entered IRS orientation")
        end
    end
    
    %IRS phase shifts
    pd1=(2*pi/lambda).*distance1;
    pd2=(2*pi/lambda).*distance2;
    
    %generate IRS channels
    h1IRS=exp(pd1*-1i);
    h2IRS=exp(pd2*-1i);
    
    %determine the total channel by identify each contribution from elements
    hTEMP=ones(Nx,Ny,Nb,Na,ixIRS);
    
    for ixIRS=1:M
        for column=1:Na
            for row=1:Nb
                hTEMP(:,:,row,column,ixIRS) = h2IRS(:,:,row,column,ixIRS).*phi(row,column,ixIRS).*h1IRS(row,column,ixIRS);
            end
        end
    
        %sum the contributions of each element
        hTEMP2=sum(sum(hTEMP,3),4);
        hIRSIndv(:,:,ixIRS) = sqrt(beta(:,:,ixIRS)).*hTEMP2(:,:,1,1,ixIRS);
        pIRSIndv(:,:,ixIRS) = (ptmax).*abs(hIRSIndv(:,:,ixIRS)).^2;
    end
    
    hIRS=sum(hIRSIndv,3);
    pIRS=(ptmax).*abs(hIRS).^2;
else
    hIRS=0;
    pIRS=0;
    hIRSIndv=0;
    pIRSIndv=0;

end
function phiAligned = IRS_simple_beamform(APxy,STAxy,IRSxy,orientationIRS,lambda,Ni,Li,pdLOS)

%Optimise the phase shifts for multiple square IRS using the phase align technique. 
% 
%Inputs: 
%AP locations (numAP x 2) [m], User location (1 x 2) [m], IRS
%locations (numIRS x 2) [m], IRS orientations (numIRS x 1), carrier wavelength [m], 
%number of elements per IRS, size width of element on IRS [m], path difference 
%on line of sight [rads].
% 
%Outputs:
%Aligned element phases (√NI x √NI x numIRS) [rads].

APx=APxy(1);
APy=APxy(2);

STAx=STAxy(1);
STAy=STAxy(2);

IRSx=IRSxy(:,1);
IRSy=IRSxy(:,2);

numIRS = size(IRSx,1);

NL=sqrt(Ni);

%AP to IRS elements distance (distance1)
distance1=ones(NL,NL,numIRS);

%IRS elements to pos distance (distance2)
distance2=ones(NL,NL,numIRS);

for ixIRS=1:numIRS
    %horizontal
    if orientationIRS(ixIRS)=="horizontal"
        for column = 1:NL
            for row = 1:NL
                distance1(row,column,ixIRS) = sqrt((IRSx(ixIRS)-(NL/2-column)*Li-APx).^2+(IRSy(ixIRS)-APy).^2+(-(NL/2-row)*Li).^2);
                distance2(row,column,ixIRS) = sqrt(((IRSx(ixIRS)-(NL/2-column)*Li-STAx)).^2+(IRSy(ixIRS)-STAy).^2+(-(NL/2-row)*Li).^2);
            end
        end
    end
    
    %vertical
    if orientationIRS(ixIRS)=="vertical"
        for column = 1:NL
            for row = 1:NL
                distance1(row,column,ixIRS) = sqrt(((IRSx(ixIRS)-APx)).^2+(IRSy(ixIRS)-(NL/2-column)*Li-APy).^2+(-(NL/2-row)*Li).^2);
                distance2(row,column,ixIRS) = sqrt(((IRSx(ixIRS)-STAx)).^2+((IRSy(ixIRS)-(NL/2-column)*Li-STAy)).^2+(-(NL/2-row)*Li).^2);
            end
        end
    end


end

%calculate total path loss
totalIRSpd = mod((2*pi/lambda)*(distance1+distance2),2*pi); %in rads

%make up for the lost phase difference
phiAligned = repmat(pdLOS,NL,NL,numIRS)-totalIRSpd;
phiAligned = mod(phiAligned,2*pi);

%create destructive beam?
%phiAligned = -repmat(pdLOS,NL,NL,numIRS)-totalIRSpd;

%create null beam
%phiAligned = -repmat(0,NL,NL,numIRS);

%%
%beamform testing
%{
%beamforming equation (no beamforming)
boreangle=5; %degrees
boreangle=boreangle*pi/180; %deg to rad
phi=repmat(linspace(0,NL-1,NL)*2*Li*pi*sin(boreangle)/lambda,NL,1);
%}


end
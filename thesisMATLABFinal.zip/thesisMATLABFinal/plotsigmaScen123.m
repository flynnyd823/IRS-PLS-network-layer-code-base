

markers = {'o', 's', '^', 'd', 'x','p','h'};
close all;
%scen 1
%sec=[37.9550 38.1265 38.2794 38.5196 38.833 39.16];
%cap=[1.07e6 1.0697e6 1.0693e6 1.0687e6 1.0676e6 1.0665e6];

%scen 2
sec=[34.9656 21.7091 15.3450 12.6371 11.3621 10.87397];
cap=[1.0488e6 1.0511e6 1.0354e6 1.0181e6 1.0067e6 9.9687e5];

%scen 3
%sec=[4.0382 3.9386 3.8040 3.7130 3.6188 3.3169];
%cap=[1.3396e6 1.3398e6 1.3399e6 1.3399e6 1.3396e6 1.3394e6];


figure(1)
sigma_values = 0:0.2:1; % Generate sigma values from 0 to 1
x = cap./1e6;  % X-axis data
y = sec;       % Y-axis data

x_range = max(x) - min(x);
y_range = max(y) - min(y);

x_margin = 0.1 * x_range;  % 5% margin for x-axis
y_margin = 0.1 * y_range;  % 5% margin for y-axis


% Plot each series with a unique marker
plot(x,y, ['-' markers{1}]);
hold on;


% Add text labels for each point
for i = 1:length(x)
    text(x(i), y(i), ['\sigma = ' num2str(sigma_values(i), '%.2f')], ...
        'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');
end
xlabel('User Capacity [Mbit/s]');
ylabel('EASOR [%]');
grid on;
grid minor;
%   lgd = legend('N=0'); %,'N=1','N=2','N=3','N=4','N=5','N=6','N=7'
%title(lgd, 'Number of IRS');
% Set new axis limits with 5% buffer
xlim([min(x) - x_margin, max(x) + x_margin]);
ylim([min(y) - y_margin, max(y) + y_margin]);
%title('Secrecy outage area');

%visualize a random scenario based on proximity restrictions, eavesdropper
%area size and number of IRS/AP
clear all;
close all;

%number of AP and IRS
numAP=2;
numIRS=4;

%size of environment
Sx=80;
Sy=80;

percentEve=25;

%proximity restrictions
minDistanceAP = 10; %metres
minDistanceIRS=10; %metres
minDistanceAPB=10; %metres
minDistanceUB=3; %metres

%randomly generate a scenario
%[eveArea, STAxy, APxy, IRSxy,orientationIRS] = monte_carlo_scen(Sx,Sy,percentEve,numAP,numIRS,minDistanceAPB,minDistanceUB,minDistanceAP,minDistanceIRS);

%save and load scenarios if necessary
load("Scenario2.mat");
%save('Scenario.mat','Sx','Sy','APxy','STAxy','IRSxy','orientationIRS','eveArea','numAP','numIRS','points');


textFontMinor=12;


figure(1)
scatter(APxy(:,1),APxy(:,2),105,'k','^',"filled");
hold all;
scatter(IRSxy(:,1),IRSxy(:,2),130,'m','+','LineWidth', 5);
scatter(STAxy(:,1),STAxy(:,2),90,'b',"o","filled");

xlabpos=ones(numAP+numIRS,1);
ylabpos=ones(numAP+numIRS,1);
labels=cell(numAP+numIRS,1);

for k=1:numAP
    xlabpos(k)=APxy(k,1)-6.25*Sx/80;
    ylabpos(k)=APxy(k,2)-6.25*Sx/80;
    labels{k}=sprintf('AP_%d', k);
end

for m=1:numIRS
    if(IRSxy(m,2)==0) %on bottom of scenario
        xlabpos(numAP+m)=IRSxy(m,1)-1*Sx/80;
        ylabpos(numAP+m)=IRSxy(m,2)+3.25*Sx/80;
    elseif(IRSxy(m,2)==Sy)
        xlabpos(numAP+m)=IRSxy(m,1)-2*Sx/80;
        ylabpos(numAP+m)=IRSxy(m,2)-8.25*Sx/80;
    elseif(IRSxy(m,1)==Sx) %on left of scenario
        xlabpos(numAP+m)=IRSxy(m,1)-10.25*Sx/80;
        ylabpos(numAP+m)=IRSxy(m,2)-2*Sx/80;
    else
        xlabpos(numAP+m)=IRSxy(m,1)+3.25*Sx/80;
        ylabpos(numAP+m)=IRSxy(m,2) -1*Sx/80;
    end

    labels{numAP+m}=sprintf('IRS_%d',m);
end


%mark unprotected zone
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,1) eveArea(2,1)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,2)],[eveArea(2,2) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,1) eveArea(1,1)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
line([eveArea(1,2) eveArea(1,2)],[eveArea(2,1) eveArea(2,2)],'LineWidth',2,'Color','r');
te = text((eveArea(1,2)+eveArea(1,1))/2-(Sx/10),(eveArea(2,2)+eveArea(2,1))/2,'A_e','HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
te.FontSize=20;
t = text(xlabpos,ylabpos,labels,'HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');
for ti=1:size(xlabpos)
    t(ti).FontSize = textFontMinor;
    t(ti).Color = 'black';
end
te.Color='Red';
axis square
legend(["Access points" "IRS" "User"],'fontsize', 14)
box on;
xlim([0 Sx]);
ylim([0 Sy]);
xlabel("x position [m]");
ylabel("y position [m]");
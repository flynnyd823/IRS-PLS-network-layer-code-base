function [eveCAP] = calculate_eaves_cap(APxy, IRSxy,orientationIRS,transmitAP, eveArea, eveDiscrete, lambda,W, N0,ptmax,p_k,Na,Nb,Le,phiAligned,Gk,GSTA)

%Calculate the secrecy outage area as a ratio of compromised positions to
%total positions available to the eveesdropper.

eveX = eveArea(1,:);
eveY = eveArea(2,:);

numAP=size(APxy,1);

%number of eve x positions to be recorded
eveXpos=floor((eveX(2)-eveX(1))*eveDiscrete);

%number of eve y positions to be recorded
eveYpos=floor((eveY(2)-eveY(1))*eveDiscrete);

eveCAP = zeros(eveXpos,eveYpos);

for x = 1:eveXpos
    for y = 1:eveYpos
        xD=eveX(1)+x/eveDiscrete;
        yD=eveY(1)+y/eveDiscrete;

        hLOS=simulate_LOS_single(APxy(transmitAP,:),[xD, yD],lambda,ptmax,Gk,GSTA);
        hIRS = simulate_IRS_single(phiAligned,APxy(transmitAP,:),[xD, yD],IRSxy,orientationIRS,lambda,Na,Nb,Le,ptmax,Gk,GSTA);
        hLOSIRS_e=hLOS+hIRS;
        pLOSIRS_e=ptmax*abs(hLOSIRS_e).^2;

        pLOSIRSj_e=0;

        for k=1:numAP
            if k~=transmitAP
                pj=p_k(k);
                [hLOSj] = simulate_LOS_single(APxy(k,:),[xD, yD],lambda,pj,Gk,GSTA);
                [hIRSj] = simulate_IRS_single(phiAligned,APxy(k,:),[xD, yD],IRSxy,orientationIRS,lambda,Na,Nb,Le,pj,Gk,GSTA);
                hLOSIRSj_e=hLOSj+hIRSj;
                pLOSIRSj_e=pLOSIRSj_e+pj*abs(hLOSIRSj_e).^2;
            end
        end

        eveCAP(x,y)=W*log2(1+(pLOSIRS_e/(W*N0+pLOSIRSj_e)));
    end
end

end


